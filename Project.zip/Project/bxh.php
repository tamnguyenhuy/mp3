<?php include'include/header.php' ?>
    
        

<div id="zone-ads-billboard"><div id="_mp3_adsZoneBillboard" class="_bannerAds"></div></div>
        <div class="wrapper-page"> 
            <div class="wrap-body group page-bxh container ">
    <div class="wrap-content">
        <div class="section">
            <div class="title-filter group">
    <div class="pull-left">
        <h1 class="title-section">#ZINGCHART TUẦN</h1>                    
    </div>
    <div class="weekly-show">
        <p class="pull-left">
            <strong>Tuần 44:</strong>
            <span>29/10 - 04/11</span>
        </p>
        <input type="hidden" name="inputDate" id="inputDate" value="">
        <i class="icon-calendar cur-p" id="btnCalendar"></i>
        <a href="" class="w-nav w-next disabled" ></a>
        <a href="zing-chart-tuan/Bai-hat-Viet-Nam/IWZ9Z08I.html?w=43&y=2018" class="w-nav w-prev "></a>
    </div>
</div>        
            <div class="row">
                <div class="col-12">
                    <div class="intro">
    <p>
       
    </p>
</div>
                    <div class="tab-menu group ">
    <ul>
        
        <li class="active"><a href="zing-chart-tuan/bai-hat-Viet-Nam/IWZ9Z08I.html">Bài Hát</a></li>
        <li class=""><a href="zing-chart-tuan/video-Viet-Nam/IWZ9Z08W.html">MV</a></li>
        <li class=""><a href="zing-chart-tuan/album-Viet-Nam/IWZ9Z08O.html">Album</a></li>
            
            
            
    </ul>
</div>
                    <div class="table-list">    
                        <div class="header-bar ">
                            <h1 class="header-title-small">#ZINGCHART TUẦN</h1>
                            <div class="box-social">
                                <div class="fb-like" data-href="" data-layout="button_count" data-action="like" data-show-faces="false" data-share="true"></div>									
                                <div class="g-plusone" data-size="medium"></div>
                            </div><!-- END .box-social -->
                            
                            
                            <a href="album/zingchart-Tuan-44-2018/ZUI09ZIB.html" class="play-all"><i class="zicon icon-play"></i>Nghe tất cả</a>
                            
                            
                                                        
                        </div><!-- EMD .table-header -->
                        <div class="table-body">
                            
                            
                            











<ul class="tracking-page-session" data-id="160">
    
    <li id="songZW9DC99A" class="po-01 group" data-type="song" data-id="ZW9DC99A" data-code="kmJHyZHsxDviFNztmTFmZHyZWlZzbWgCC" data-sig="cea4ee4d38fe2114ae517f93c57ff245" data-active="show-tool">
    <div class="group po-r">
        <span class="txt-rank">01</span>
        <span id="item-ranking-ZW9DC99A" class="statistics"><i></i></span>
        <div class="e-item">
            <a href="bai-hat/Vo-Tinh-Xesi-Hoaprox/ZW9DC99A.html" title="Bài hát Vô Tình - " class="thumb pull-left _trackLink" tracking="_frombox=chartsong_vietnam_01">
                <img width="60" height="60" src="image/798559c5b7d028c351d34a37c7a598cc.jpg" alt="Bài hát Vô Tình - " />
            </a>
            <h3 class="title-item ellipsis">
                <a href="bai-hat/Vo-Tinh-Xesi-Hoaprox/ZW9DC99A.html" title="Vô Tình" class="txt-primary _trackLink" tracking="_frombox=chartsong_vietnam_01">Vô Tình</a>
            </h3>
            <div class="inblock ellipsis">
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Xesi" title="Nghệ sĩ Xesi">Xesi</a></h4><span class="ft">, </span>
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Hoaprox" title="Nghệ sĩ Hoaprox">Hoaprox</a></h4>
                
            </div>
        </div><!-- END .e-item -->
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#songZW9DC99A" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#songZW9DC99A" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9DC99A" href="bai-hat/Vo-Tinh-Xesi-Hoaprox/ZW9DC99A.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>
        
        <div class="txt-info rank-score pull-right">
            <span id="song-score-ZW9DC99A" class="score fn-number" data-box="#songZW9DC99A .fn-stats"></span>
        </div>
                              
    </div>
</li>
    
    <li id="songZW9DFW9A" class="po-02 group" data-type="song" data-id="ZW9DFW9A" data-code="LmxGtkHNxFBiNsnymtFGLntLpALzvQCCh" data-sig="6a562e72fb457cb5b1c4fc70713d3f55" data-active="show-tool">
    <div class="group po-r">
        <span class="txt-rank">02</span>
        <span id="item-ranking-ZW9DFW9A" class="statistics"><i></i></span>
        <div class="e-item">
            <a href="bai-hat/Thang-Dien-JustaTee-Phuong-Ly/ZW9DFW9A.html#video-clip" title="Bài hát Thằng Điên - " class="thumb pull-left _trackLink" tracking="_frombox=chartsong_vietnam_02">
                <img width="60" height="60" src="image/9d5c56a277a06a48ec7956a4fd17e4c1.jpg" alt="Bài hát Thằng Điên - " />
            </a>
            <h3 class="title-item ellipsis">
                <a href="bai-hat/Thang-Dien-JustaTee-Phuong-Ly/ZW9DFW9A.html#video-clip" title="Thằng Điên" class="txt-primary _trackLink" tracking="_frombox=chartsong_vietnam_02">Thằng Điên</a>
            </h3>
            <div class="inblock ellipsis">
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/JustaTee" title="Nghệ sĩ JustaTee">JustaTee</a></h4><span class="ft">, </span>
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Phuong-Ly" title="Nghệ sĩ Phương Ly">Phương Ly</a></h4>
                
            </div>
        </div><!-- END .e-item -->
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#songZW9DFW9A" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#songZW9DFW9A" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9DFW9A" href="bai-hat/Thang-Dien-JustaTee-Phuong-Ly/ZW9DFW9A.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>
        
        <div class="txt-info rank-score pull-right">
            <span id="song-score-ZW9DFW9A" class="score fn-number" data-box="#songZW9DFW9A .fn-stats"></span>
        </div>
                              
    </div>
</li>
    
    <li id="songZW9DCEE6" class="po-03 group" data-type="song" data-id="ZW9DCEE6" data-code="ZHJmykmsxFdnCdmynyFmLmyZpSLzbWhXC" data-sig="8c1e52c8ee18481317133f300b2da47b" data-active="show-tool">
    <div class="group po-r">
        <span class="txt-rank">03</span>
        <span id="item-ranking-ZW9DCEE6" class="statistics"><i></i></span>
        <div class="e-item">
            <a href="bai-hat/Cang-Niu-Giu-Cang-De-Mat-Mr-Siro/ZW9DCEE6.html#video-clip" title="Bài hát Càng Níu Giữ Càng Dễ Mất - " class="thumb pull-left _trackLink" tracking="_frombox=chartsong_vietnam_03">
                <img width="60" height="60" src="image/997250daaebfe5c1a8f29a5fce90248a.jpg" alt="Bài hát Càng Níu Giữ Càng Dễ Mất - " />
            </a>
            <h3 class="title-item ellipsis">
                <a href="bai-hat/Cang-Niu-Giu-Cang-De-Mat-Mr-Siro/ZW9DCEE6.html#video-clip" title="Càng Níu Giữ Càng Dễ Mất" class="txt-primary _trackLink" tracking="_frombox=chartsong_vietnam_03">Càng Níu Giữ Càng Dễ Mất</a>
            </h3>
            <div class="inblock ellipsis">
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Mr-Siro" title="Nghệ sĩ Mr Siro">Mr Siro</a></h4>
                
            </div>
        </div><!-- END .e-item -->
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#songZW9DCEE6" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#songZW9DCEE6" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9DCEE6" href="bai-hat/Cang-Niu-Giu-Cang-De-Mat-Mr-Siro/ZW9DCEE6.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>
        
        <div class="txt-info rank-score pull-right">
            <span id="song-score-ZW9DCEE6" class="score fn-number" data-box="#songZW9DCEE6 .fn-stats"></span>
        </div>
                              
    </div>
</li>
    
    <li id="songZW9DFW8O" class="po-04 group" data-type="song" data-id="ZW9DFW8O" data-code="kHcntLHNcvBRsSNymTbmZGTkpSkAbQXgh" data-sig="6b08d5e32accb8693f13ca8908fe0f68" data-active="show-tool">
    <div class="group po-r">
        <span class="txt-rank">04</span>
        <span id="item-ranking-ZW9DFW8O" class="statistics"><i></i></span>
        <div class="e-item">
            <a href="bai-hat/Hongkong1-Official-Version-Nguyen-Trong-Tai-San-Ji-Double-X/ZW9DFW8O.html#video-clip" title="Bài hát Hongkong1 (Official Version) - " class="thumb pull-left _trackLink" tracking="_frombox=chartsong_vietnam_04">
                <img width="60" height="60" src="image/2436b0b8130f7c2199d9803c0b85d57d.jpg" alt="Bài hát Hongkong1 (Official Version) - " />
            </a>
            <h3 class="title-item ellipsis">
                <a href="bai-hat/Hongkong1-Official-Version-Nguyen-Trong-Tai-San-Ji-Double-X/ZW9DFW8O.html#video-clip" title="Hongkong1 (Official Version)" class="txt-primary _trackLink" tracking="_frombox=chartsong_vietnam_04">Hongkong1 (Official Version)</a>
            </h3>
            <div class="inblock ellipsis">
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Nguyen-Trong-Tai" title="Nghệ sĩ Nguyễn Trọng Tài">Nguyễn Trọng Tài</a></h4><span class="ft">, </span>
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Sang-Vo" title="Nghệ sĩ San Ji">San Ji</a></h4><span class="ft">, </span>
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Double-X" title="Nghệ sĩ Double X">Double X</a></h4>
                
            </div>
        </div><!-- END .e-item -->
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#songZW9DFW8O" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#songZW9DFW8O" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9DFW8O" href="bai-hat/Hongkong1-Official-Version-Nguyen-Trong-Tai-San-Ji-Double-X/ZW9DFW8O.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>
        
        <div class="txt-info rank-score pull-right">
            <span id="song-score-ZW9DFW8O" class="score fn-number" data-box="#songZW9DFW8O .fn-stats"></span>
        </div>
                              
    </div>
</li>
    
    <li id="songZW9EAI76" class="po-05 group" data-type="song" data-id="ZW9EAI76" data-code="LnJGyZnNJFJSpdATmyDmkHyLQAZzFQhhh" data-sig="d600ed0ec25bd30c039e173b19693391" data-active="show-tool">
    <div class="group po-r">
        <span class="txt-rank">05</span>
        <span id="item-ranking-ZW9EAI76" class="statistics"><i></i></span>
        <div class="e-item">
            <a href="bai-hat/Chap-Nhan-Hoa-Minzy/ZW9EAI76.html#video-clip" title="Bài hát Chấp Nhận - " class="thumb pull-left _trackLink" tracking="_frombox=chartsong_vietnam_05">
                <img width="60" height="60" src="w94h94_jpeg/cover/b/1/f/d/b1fd458008d15ffad79303adbb1a46c1.jpg" alt="Bài hát Chấp Nhận - " />
            </a>
            <h3 class="title-item ellipsis">
                <a href="bai-hat/Chap-Nhan-Hoa-Minzy/ZW9EAI76.html#video-clip" title="Chấp Nhận" class="txt-primary _trackLink" tracking="_frombox=chartsong_vietnam_05">Chấp Nhận</a>
            </h3>
            <div class="inblock ellipsis">
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Hoa-Minzy" title="Nghệ sĩ Hòa Minzy">Hòa Minzy</a></h4>
                
            </div>
        </div><!-- END .e-item -->
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#songZW9EAI76" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#songZW9EAI76" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EAI76" href="bai-hat/Chap-Nhan-Hoa-Minzy/ZW9EAI76.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>
        
        <div class="txt-info rank-score pull-right">
            <span id="song-score-ZW9EAI76" class="score fn-number" data-box="#songZW9EAI76 .fn-stats"></span>
        </div>
                              
    </div>
</li>
    
    <li id="songZW9E86WA" class="po-06 group" data-type="song" data-id="ZW9E86WA" data-code="LmcHyknscFNsWzhtHyDHLmykplLzDWCXh" data-sig="44fef2c10fa3ef2b0633cf58de580d3f" data-active="show-tool">
    <div class="group po-r">
        <span class="txt-rank">06</span>
        <span id="item-ranking-ZW9E86WA" class="statistics"><i></i></span>
        <div class="e-item">
            <a href="bai-hat/Em-Khong-The-Tien-Tien-Touliver/ZW9E86WA.html#video-clip" title="Bài hát Em Không Thể - " class="thumb pull-left _trackLink" tracking="_frombox=chartsong_vietnam_06">
                <img width="60" height="60" src="image/f8f2cd19c3e2e48603a510888807c363.jpg" alt="Bài hát Em Không Thể - " />
            </a>
            <h3 class="title-item ellipsis">
                <a href="bai-hat/Em-Khong-The-Tien-Tien-Touliver/ZW9E86WA.html#video-clip" title="Em Không Thể" class="txt-primary _trackLink" tracking="_frombox=chartsong_vietnam_06">Em Không Thể</a>
            </h3>
            <div class="inblock ellipsis">
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Tien-Tien" title="Nghệ sĩ Tiên Tiên">Tiên Tiên</a></h4><span class="ft">, </span>
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Touliver" title="Nghệ sĩ Touliver">Touliver</a></h4>
                
            </div>
        </div><!-- END .e-item -->
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#songZW9E86WA" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#songZW9E86WA" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E86WA" href="bai-hat/Em-Khong-The-Tien-Tien-Touliver/ZW9E86WA.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>
        
        <div class="txt-info rank-score pull-right">
            <span id="song-score-ZW9E86WA" class="score fn-number" data-box="#songZW9E86WA .fn-stats"></span>
        </div>
                              
    </div>
</li>
    
    <li id="songZW9E8U8W" class="po-07 group" data-type="song" data-id="ZW9E8U8W" data-code="ZGJHTZHscbNsZbFtmtvHZHtLQlkzbQhhh" data-sig="002e2ff042d840d3ea07c62360ab0737" data-active="show-tool">
    <div class="group po-r">
        <span class="txt-rank">07</span>
        <span id="item-ranking-ZW9E8U8W" class="statistics"><i></i></span>
        <div class="e-item">
            <a href="bai-hat/Nguoi-La-Thoang-Qua-Khoi-My/ZW9E8U8W.html" title="Bài hát Người Lạ Thoáng Qua - " class="thumb pull-left _trackLink" tracking="_frombox=chartsong_vietnam_07">
                <img width="60" height="60" src="w94h94_jpeg/cover/4/1/8/b/418b2a3ada550ed8a42f363194a12f45.jpg" alt="Bài hát Người Lạ Thoáng Qua - " />
            </a>
            <h3 class="title-item ellipsis">
                <a href="bai-hat/Nguoi-La-Thoang-Qua-Khoi-My/ZW9E8U8W.html" title="Người Lạ Thoáng Qua" class="txt-primary _trackLink" tracking="_frombox=chartsong_vietnam_07">Người Lạ Thoáng Qua</a>
            </h3>
            <div class="inblock ellipsis">
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Khoi-My" title="Nghệ sĩ Khởi My">Khởi My</a></h4>
                
            </div>
        </div><!-- END .e-item -->
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#songZW9E8U8W" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#songZW9E8U8W" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E8U8W" href="bai-hat/Nguoi-La-Thoang-Qua-Khoi-My/ZW9E8U8W.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>
        
        <div class="txt-info rank-score pull-right">
            <span id="song-score-ZW9E8U8W" class="score fn-number" data-box="#songZW9E8U8W .fn-stats"></span>
        </div>
                              
    </div>
</li>
    
    <li id="songZW9DAB0O" class="po-08 group" data-type="song" data-id="ZW9DAB0O" data-code="ZmxGtLGacbDLzSBtGyFnZmyLWAklbpghC" data-sig="9ee9f12aba381f146b776da14939ed9f" data-active="show-tool">
    <div class="group po-r">
        <span class="txt-rank">08</span>
        <span id="item-ranking-ZW9DAB0O" class="statistics"><i></i></span>
        <div class="e-item">
            <a href="bai-hat/Chuyen-Tinh-Toi-Kay-Tran-Nguyen-Khoa-Kass/ZW9DAB0O.html#video-clip" title="Bài hát Chuyện Tình Tôi - " class="thumb pull-left _trackLink" tracking="_frombox=chartsong_vietnam_08">
                <img width="60" height="60" src="image/fb02af43541ac3442301b5da01f8404a.jpg" alt="Bài hát Chuyện Tình Tôi - " />
            </a>
            <h3 class="title-item ellipsis">
                <a href="bai-hat/Chuyen-Tinh-Toi-Kay-Tran-Nguyen-Khoa-Kass/ZW9DAB0O.html#video-clip" title="Chuyện Tình Tôi" class="txt-primary _trackLink" tracking="_frombox=chartsong_vietnam_08">Chuyện Tình Tôi</a>
            </h3>
            <div class="inblock ellipsis">
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Kay-Tran" title="Nghệ sĩ Kay Trần">Kay Trần</a></h4><span class="ft">, </span>
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/nguyenkhoa" title="Nghệ sĩ Nguyễn Khoa">Nguyễn Khoa</a></h4><span class="ft">, </span>
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Kass" title="Nghệ sĩ Kass">Kass</a></h4>
                
            </div>
        </div><!-- END .e-item -->
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#songZW9DAB0O" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#songZW9DAB0O" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9DAB0O" href="bai-hat/Chuyen-Tinh-Toi-Kay-Tran-Nguyen-Khoa-Kass/ZW9DAB0O.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>
        
        <div class="txt-info rank-score pull-right">
            <span id="song-score-ZW9DAB0O" class="score fn-number" data-box="#songZW9DAB0O .fn-stats"></span>
        </div>
                              
    </div>
</li>
    
    <li id="songZW9EO8WO" class="po-09 group" data-type="song" data-id="ZW9EO8WO" data-code="ZmcmyLmaxbQaWskyGtFGZHyLpzkzDWhCh" data-sig="d495fce0bcb03f0d263b6057a1fd6448" data-active="show-tool">
    <div class="group po-r">
        <span class="txt-rank">09</span>
        <span id="item-ranking-ZW9EO8WO" class="statistics"><i></i></span>
        <div class="e-item">
            <a href="bai-hat/Dung-Noi-Toi-Dien-Hien-Ho/ZW9EO8WO.html#video-clip" title="Bài hát Đừng Nói Tôi Điên - " class="thumb pull-left _trackLink" tracking="_frombox=chartsong_vietnam_09">
                <img width="60" height="60" src="w94h94_jpeg/cover/1/2/b/8/12b88922410ad579dce22031b12c05ca.jpg" alt="Bài hát Đừng Nói Tôi Điên - " />
            </a>
            <h3 class="title-item ellipsis">
                <a href="bai-hat/Dung-Noi-Toi-Dien-Hien-Ho/ZW9EO8WO.html#video-clip" title="Đừng Nói Tôi Điên" class="txt-primary _trackLink" tracking="_frombox=chartsong_vietnam_09">Đừng Nói Tôi Điên</a>
            </h3>
            <div class="inblock ellipsis">
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Hien-Ho" title="Nghệ sĩ Hiền Hồ">Hiền Hồ</a></h4>
                
            </div>
        </div><!-- END .e-item -->
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#songZW9EO8WO" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#songZW9EO8WO" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EO8WO" href="bai-hat/Dung-Noi-Toi-Dien-Hien-Ho/ZW9EO8WO.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>
        
        <div class="txt-info rank-score pull-right">
            <span id="song-score-ZW9EO8WO" class="score fn-number" data-box="#songZW9EO8WO .fn-stats"></span>
        </div>
                              
    </div>
</li>
    
    <li id="songZW9DODFI" class="po-10 group" data-type="song" data-id="ZW9DODFI" data-code="kncHtZGscZRBWbZtHybmLHtZQzkzDphCh" data-sig="6bc262e2d9ebe1a6a45f52b7a29023b0" data-active="show-tool">
    <div class="group po-r">
        <span class="txt-rank">10</span>
        <span id="item-ranking-ZW9DODFI" class="statistics"><i></i></span>
        <div class="e-item">
            <a href="bai-hat/Tan-Cung-Noi-Nho-Will/ZW9DODFI.html#video-clip" title="Bài hát Tận Cùng Nỗi Nhớ - " class="thumb pull-left _trackLink" tracking="_frombox=chartsong_vietnam_10">
                <img width="60" height="60" src="image/3bcd4a21a806a35f4b54f600b818faac.jpg" alt="Bài hát Tận Cùng Nỗi Nhớ - " />
            </a>
            <h3 class="title-item ellipsis">
                <a href="bai-hat/Tan-Cung-Noi-Nho-Will/ZW9DODFI.html#video-clip" title="Tận Cùng Nỗi Nhớ" class="txt-primary _trackLink" tracking="_frombox=chartsong_vietnam_10">Tận Cùng Nỗi Nhớ</a>
            </h3>
            <div class="inblock ellipsis">
                
                <h4 class="title-sd-item txt-info"><a href="nghe-si/Will-365DaBand" title="Nghệ sĩ Will">Will</a></h4>
                
            </div>
        </div><!-- END .e-item -->
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#songZW9DODFI" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#songZW9DODFI" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9DODFI" href="bai-hat/Tan-Cung-Noi-Nho-Will/ZW9DODFI.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>
        
        <div class="txt-info rank-score pull-right">
            <span id="song-score-ZW9DODFI" class="score fn-number" data-box="#songZW9DODFI .fn-stats"></span>
        </div>
                              
    </div>
</li>
     
</ul>







    

                            
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- END .section -->
    </div><!-- END .wrap-content -->
    <div class="wrap-sidebar">
    <div id="zmp3Ads"></div>
    
    <div id="widget-chart-am" class="widget widget-tab ">
        <h2 class="title-section sz-title-sm">
            <a id="detail-link-am" class="fn-detail_link" href="zing-chart-tuan/Bai-hat-US-UK/IWZ9Z0BW.html">US-UK Chart<i class="icon-arrow"></i></a>
            <a title="Nghe tất cả" href="#" class="none icon-play-all pull-right fn-play_link"></a>
        </h2>
        <ul class="tab-nav">
            <li><a title="Zing Chart US-UK Chart" id="switch-tab-audio" class="active fn-switch-tab fn-switch-tab-audio" data-show="#chart_song_IWZ9Z0B6" data-id="IWZ9Z0B6" data-type="song" data-genre="am" data-link="zing-chart-tuan/Bai-hat-US-UK/IWZ9Z0BW.html" data-playlistLink="album/Bang-Xep-Hang-Bai-Hat-Au-My-Tuan-43-2018/ZU0ZIEDA.html" data-hide=".chart-IWZ9Z0B6">Bài hát</a></li>
            <li><a title="Zing Chart US-UK Chart" class=" fn-switch-tab fn-switch-tab-video" data-show="#chart_video_IWZ9Z0B6" data-id="IWZ9Z0B6" data-type="video" data-genre="am" data-link="zing-chart-tuan/MV-US-UK/IWZ9Z0BU.html" data-playlistLink="" data-hide=".chart-IWZ9Z0B6">MV</a></li>            
            <li><a title="Zing Chart US-UK Chart" class=" fn-switch-tab fn-switch-tab-album" data-show="#chart_album_IWZ9Z0B6" data-id="IWZ9Z0B6" data-type="album" data-genre="am" data-link="zing-chart-tuan/Album-US-UK/IWZ9Z0B6.html" data-playlistLink="" data-hide=".chart-IWZ9Z0B6">Album</a></li>
        </ul>
        <div>
            <div id="chart_song_IWZ9Z0B6" class="chart-IWZ9Z0B6 tab-pane widget-song-countdown ">
                <div class="widget-content no-padding no-border">
                    
                    












<ul class="fn-list">
    
    <li class="fn-item fn-first first-item fn-song" data-type="song" data-id="ZW9C6C8W" data-code="ZHxHyLmNcLdRRnhTHTFmLGyLQzkSDpCXC"  data-active="show-tool" id="chartitemsongZW9C6C8W">
    
    <a class="zthumb fn-link" href="bai-hat/Girls-Like-You-Maroon-5-Cardi-B/ZW9C6C8W.html#video-clip">
        <img class="fn-thumb" src="banner/c/7/6/5/c7658ec705f570353c4f349f96fc1f6b.jpg" alt="Bài hát Girls Like You - Maroon 5, Cardi B">
    </a>
    
    <div class="w260 des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Girls-Like-You-Maroon-5-Cardi-B/ZW9C6C8W.html#video-clip" title="Girls Like You" class="txt-primary _trackLink" tracking="_frombox=">Girls Like You</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Maroon-5" title="Nghệ sĩ Maroon 5">Maroon 5</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Cardi-B" title="Nghệ sĩ Cardi B">Cardi B</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9C6C8W" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9C6C8W" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9C6C8W" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9C6C8W" href="bai-hat/Girls-Like-You-Maroon-5-Cardi-B/ZW9C6C8W.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    <span class="item-mask"></span>
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DWC9C" data-code="knxHyZmNckxEmJlyGyFHZnyLpSLzvWgXX"  data-active="show-tool" id="chartitemsongZW9DWC9C">
    
    <div class="w260 ">
        <span class="rank fn-order">02</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/SICKO-MODE-Travis-Scott/ZW9DWC9C.html" title="SICKO MODE" class="txt-primary _trackLink" tracking="_frombox=">SICKO MODE</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Travis-Scott" title="Nghệ sĩ Travis Scott">Travis Scott</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DWC9C" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DWC9C" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DWC9C" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DWC9C" href="bai-hat/SICKO-MODE-Travis-Scott/ZW9DWC9C.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9CIF69" data-code="LHJHyLmaxkFmZhRtHtbmkGyZWzLzFpCXg"  data-active="show-tool" id="chartitemsongZW9CIF69">
    
    <div class="w260 ">
        <span class="rank fn-order">03</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Lucid-Dreams-Juice-Wrld/ZW9CIF69.html" title="Lucid Dreams" class="txt-primary _trackLink" tracking="_frombox=">Lucid Dreams</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Juice Wrld" title="Nghệ sĩ Juice Wrld">Juice Wrld</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9CIF69" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9CIF69" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9CIF69" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9CIF69" href="bai-hat/Lucid-Dreams-Juice-Wrld/ZW9CIF69.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DZOOB" data-code="ZHJGtkmNcZRcRakTGtDnkmyZpzLSbQhXh"  data-active="show-tool" id="chartitemsongZW9DZOOB">
    
    <div class="w260 ">
        <span class="rank fn-order">04</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Happier-Marshmello-Bastille/ZW9DZOOB.html#video-clip" title="Happier" class="txt-primary _trackLink" tracking="_frombox=">Happier</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Marshmello" title="Nghệ sĩ Marshmello">Marshmello</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Bastille" title="Nghệ sĩ Bastille">Bastille</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DZOOB" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DZOOB" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DZOOB" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DZOOB" href="bai-hat/Happier-Marshmello-Bastille/ZW9DZOOB.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9C07C6" data-code="LHJntkGsxZkSLLxymTFHLmtZpSkSvpghC"  data-active="show-tool" id="chartitemsongZW9C07C6">
    
    <div class="w260 ">
        <span class="rank fn-order">05</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Better-Now-Post-Malone/ZW9C07C6.html" title="Better Now" class="txt-primary _trackLink" tracking="_frombox=">Better Now</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Post-Malone" title="Nghệ sĩ Post Malone">Post Malone</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9C07C6" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9C07C6" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9C07C6" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9C07C6" href="bai-hat/Better-Now-Post-Malone/ZW9C07C6.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9EWB6Z" data-code="ZmxHykHsxbpSBmRTHtDHZmykWALzDpXXC"  data-active="show-tool" id="chartitemsongZW9EWB6Z">
    
    <div class="w260 ">
        <span class="rank fn-order">06</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/ZEZE-Kodak-Black-Travis-Scott-Offset/ZW9EWB6Z.html" title="ZEZE" class="txt-primary _trackLink" tracking="_frombox=">ZEZE</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Kodak-Black" title="Nghệ sĩ Kodak Black">Kodak Black</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Travis-Scott" title="Nghệ sĩ Travis Scott">Travis Scott</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Offset" title="Nghệ sĩ Offset">Offset</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9EWB6Z" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9EWB6Z" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9EWB6Z" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9EWB6Z" href="bai-hat/ZEZE-Kodak-Black-Travis-Scott-Offset/ZW9EWB6Z.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9BC7C0" data-code="kGJGyZHNcmRsNbxyHyDmLmTZQlZzbQXgh"  data-active="show-tool" id="chartitemsongZW9BC7C0">
    
    <div class="w260 ">
        <span class="rank fn-order">07</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Youngblood-5-Seconds-Of-Summer/ZW9BC7C0.html#video-clip" title="Youngblood" class="txt-primary _trackLink" tracking="_frombox=">Youngblood</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/5-Seconds-Of-Summer" title="Nghệ sĩ 5 Seconds Of Summer">5 Seconds Of Summer</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9BC7C0" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9BC7C0" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9BC7C0" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9BC7C0" href="bai-hat/Youngblood-5-Seconds-Of-Summer/ZW9BC7C0.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DAD6D" data-code="LnxGykHsxDDFGhkyHyvGkHtLWlkAFpCXC"  data-active="show-tool" id="chartitemsongZW9DAD6D">
    
    <div class="w260 ">
        <span class="rank fn-order">08</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Drip-Too-Hard-Lil-Baby-Gunna/ZW9DAD6D.html" title="Drip Too Hard" class="txt-primary _trackLink" tracking="_frombox=">Drip Too Hard</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Lil-Baby" title="Nghệ sĩ Lil Baby">Lil Baby</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Gunna" title="Nghệ sĩ Gunna">Gunna</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DAD6D" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DAD6D" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DAD6D" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DAD6D" href="bai-hat/Drip-Too-Hard-Lil-Baby-Gunna/ZW9DAD6D.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9EZIZ7" data-code="ZGcGyZGNJbXSHDdymTvnZHtZWSkzbQhhg"  data-active="show-tool" id="chartitemsongZW9EZIZ7">
    
    <div class="w260 ">
        <span class="rank fn-order">09</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Sunflower-Spider-Man-Into-The-Spider-Verse-Post-Malone-Swae-Lee/ZW9EZIZ7.html" title="Sunflower (Spider-Man: Into The Spider-Verse)" class="txt-primary _trackLink" tracking="_frombox=">Sunflower (Spider-Man: Into The Spider-Verse)</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Post-Malone" title="Nghệ sĩ Post Malone">Post Malone</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Swae-Lee" title="Nghệ sĩ Swae Lee">Swae Lee</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9EZIZ7" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9EZIZ7" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9EZIZ7" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9EZIZ7" href="bai-hat/Sunflower-Spider-Man-Into-The-Spider-Verse-Post-Malone-Swae-Lee/ZW9EZIZ7.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9BW0DA" data-code="ZmxHtLmsJGpQmnFTmyFGZmtkpAklbphgg"  data-active="show-tool" id="chartitemsongZW9BW0DA">
    
    <div class="w260 ">
        <span class="rank fn-order">10</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Love-Lies-Khalid-Normani/ZW9BW0DA.html#video-clip" title="Love Lies" class="txt-primary _trackLink" tracking="_frombox=">Love Lies</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Khalid" title="Nghệ sĩ Khalid">Khalid</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Normani" title="Nghệ sĩ Normani">Normani</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9BW0DA" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9BW0DA" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9BW0DA" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9BW0DA" href="bai-hat/Love-Lies-Khalid-Normani/ZW9BW0DA.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
</ul>






    

                           
                </div>
            </div>
            <div id="chart_video_IWZ9Z0B6" class="chart-IWZ9Z0B6 tab-pane widget-thumb-countdown widget-mv-countdown none">
                <div class="widget-content no-padding no-border">
                    
                    







<ul>
    
    
<li class="fn-first first-item fn-item chart-video-sidebar">
    <a class="zthumb fn-link" href="video-clip/Taki-Taki-DJ-Snake-Selena-Gomez-Ozuna-Cardi-B/ZW9DD9D0.html">
        <img class="fn-thumb" src="banner/c/c/5/e/cc5ece1a04d7e53577409e3f70c4052f.jpg" alt="Bài hát Taki Taki - DJ Snake, Selena Gomez, Ozuna, Cardi B">
    </a>
    <div class="des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="video-clip/Taki-Taki-DJ-Snake-Selena-Gomez-Ozuna-Cardi-B/ZW9DD9D0.html" title="Taki Taki" class="txt-primary _trackLink" tracking="_frombox=">Taki Taki</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/DJ-Snake" title="Nghệ sĩ Nhiều nghệ sĩ">Nhiều nghệ sĩ</a></h4>
            
        </div>
        
        <i id="video-score-ZW9DD9D0" class="txt-info pull-right view-stas fn-score"></i>
        
    </div><!-- /.des -->
    <span class="item-mask"></span>
</li>


    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/Girls-Like-You-Maroon-5-Cardi-B/ZW9C6C8W.html">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/e/f/3/9/ef39edf6d8a7a9e09a212de6dddd49e6.jpg" alt="Bài hát Girls Like You - Maroon 5, Cardi B" />
        <span class="rank fn-order">02</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/Girls-Like-You-Maroon-5-Cardi-B/ZW9C6C8W.html" title="Girls Like You" class="txt-primary _trackLink" tracking="_frombox=">Girls Like You</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Maroon-5" title="Nghệ sĩ Maroon 5">Maroon 5</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Cardi-B" title="Nghệ sĩ Cardi B">Cardi B</a></h4>
        
    </div>
    
    <h5 id="video-score-ZW9C6C8W" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/Venom-OST-Eminem/ZW9DCC7B.html">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/c/5/4/2/c54215ea44847d5b41f5b1b985c848b0.jpg" alt="Bài hát Venom (OST) - Eminem" />
        <span class="rank fn-order">03</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/Venom-OST-Eminem/ZW9DCC7B.html" title="Venom (OST)" class="txt-primary _trackLink" tracking="_frombox=">Venom (OST)</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Eminem" title="Nghệ sĩ Eminem">Eminem</a></h4>
        
    </div>
    
    <h5 id="video-score-ZW9DCC7B" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/FEFE-6ix9ine-Nicki-Minaj-Murda-Beatz/ZW9D0ABB.html">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/3/7/4/1/3741d40ba940e85ae44207cd6d68d1a6.jpg" alt="Bài hát FEFE - 6ix9ine, Nicki Minaj, Murda Beatz" />
        <span class="rank fn-order">04</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/FEFE-6ix9ine-Nicki-Minaj-Murda-Beatz/ZW9D0ABB.html" title="FEFE" class="txt-primary _trackLink" tracking="_frombox=">FEFE</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/6ix9ine" title="Nghệ sĩ 6ix9ine">6ix9ine</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Nicki-Minaj" title="Nghệ sĩ Nicki Minaj">Nicki Minaj</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Murda-Beatz" title="Nghệ sĩ Murda Beatz">Murda Beatz</a></h4>
        
    </div>
    
    <h5 id="video-score-ZW9D0ABB" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/MIA-Bad-Bunny-Drake/ZW9EICIW.html">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/1/4/8/9/14895c13768ebf7b54d5e0bde869ea24.jpg" alt="Bài hát MIA - Bad Bunny, Drake" />
        <span class="rank fn-order">05</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/MIA-Bad-Bunny-Drake/ZW9EICIW.html" title="MIA" class="txt-primary _trackLink" tracking="_frombox=">MIA</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Bad-Bunny" title="Nghệ sĩ Bad Bunny">Bad Bunny</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Drake" title="Nghệ sĩ Drake">Drake</a></h4>
        
    </div>
    
    <h5 id="video-score-ZW9EICIW" class="txt-info z-point fn-score"></h5>
    
</li>

    
</ul>


    

                    
                </div>
            </div>
            <div id="chart_album_IWZ9Z0B6" class="chart-IWZ9Z0B6 tab-pane widget-thumb-countdown widget-album-countdown none">
                <div class="widget-content no-padding no-border">
                    
                    






<ul>
    
    
<li class="fn-first first-item fn-item">
    <a class="zthumb fn-link" href="album/A-Star-Is-Born-Soundtrack-Lady-Gaga-Bradley-Cooper/ZOECO0EA.html">
        <img class="fn-thumb" src="banner/a/e/f/1/aef1e1f25826168b2f02dcfd0711e31d.jpg" alt="Album A Star Is Born Soundtrack - Lady Gaga, Bradley Cooper">
    </a>
    <div class="des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="album/A-Star-Is-Born-Soundtrack-Lady-Gaga-Bradley-Cooper/ZOECO0EA.html" title="A Star Is Born Soundtrack - Lady Gaga, Bradley Cooper" class="txt-primary _trackLink" tracking="_frombox=">A Star Is Born Soundtrack</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Lady-Gaga" title="Nghệ sĩ Lady Gaga">Lady Gaga</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Bradley Cooper" title="Nghệ sĩ Bradley Cooper">Bradley Cooper</a></h4>
            
        </div>
        
        <i id="album-score-ZOECO0EA" class="txt-info pull-right view-stas fn-score"></i>
        
    </div><!-- /.des -->
    <span class="item-mask"></span>
</li>


    
    

<li class="fn-item">
    <a href="album/Future-Juice-WRLD-Present-WRLD-ON-DRUGS-Future-Juice-Wrld/ZOEFFUAC.html" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/4/c/e/a/4cea411d6ba9284f0ab491703faf31ca.jpg" alt="Bài hát Future & Juice WRLD Present... WRLD ON DRUGS - Future, Juice Wrld" />
        <span class="rank fn-order">02</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Future-Juice-WRLD-Present-WRLD-ON-DRUGS-Future-Juice-Wrld/ZOEFFUAC.html" title="Future & Juice WRLD Present... WRLD ON DRUGS" class="txt-primary _trackLink" tracking="_frombox=">Future & Juice WRLD Present... WRLD ON DRUGS</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Future" title="Nghệ sĩ Future">Future</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Juice Wrld" title="Nghệ sĩ Juice Wrld">Juice Wrld</a></h4>
        
    </div>
    
    <h5 id="album-score-ZOEFFUAC" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item">
    <a href="album/Anthem-Of-The-Peaceful-Army-Greta-Van-Fleet/ZOEFEZDZ.html" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/7/3/5/0/73501a569426bf2dc6f75ad01331d9c5.jpg" alt="Bài hát Anthem Of The Peaceful Army - Greta Van Fleet" />
        <span class="rank fn-order">03</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Anthem-Of-The-Peaceful-Army-Greta-Van-Fleet/ZOEFEZDZ.html" title="Anthem Of The Peaceful Army" class="txt-primary _trackLink" tracking="_frombox=">Anthem Of The Peaceful Army</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Greta Van Fleet" title="Nghệ sĩ Greta Van Fleet">Greta Van Fleet</a></h4>
        
    </div>
    
    <h5 id="album-score-ZOEFEZDZ" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item">
    <a href="album/Tha-Carter-V-Lil-Wayne/ZOEA9UC0.html" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/2/2/8/2/2282c71e12f3c226b2f216bf3b622697.jpg" alt="Bài hát Tha Carter V - Lil Wayne" />
        <span class="rank fn-order">04</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Tha-Carter-V-Lil-Wayne/ZOEA9UC0.html" title="Tha Carter V" class="txt-primary _trackLink" tracking="_frombox=">Tha Carter V</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Lil-Wayne" title="Nghệ sĩ Lil Wayne">Lil Wayne</a></h4>
        
    </div>
    
    <h5 id="album-score-ZOEA9UC0" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item">
    <a href="album/Drip-Harder-Lil-Baby-Gunna/ZOECOI0E.html" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/6/2/6/3/6263a20d11f9f453f803d2c11b146bdb.jpg" alt="Bài hát Drip Harder - Lil Baby, Gunna" />
        <span class="rank fn-order">05</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Drip-Harder-Lil-Baby-Gunna/ZOECOI0E.html" title="Drip Harder" class="txt-primary _trackLink" tracking="_frombox=">Drip Harder</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Lil-Baby" title="Nghệ sĩ Lil Baby">Lil Baby</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Gunna" title="Nghệ sĩ Gunna">Gunna</a></h4>
        
    </div>
    
    <h5 id="album-score-ZOECOI0E" class="txt-info z-point fn-score"></h5>
    
</li>

    
</ul>




             
       
                </div>
            </div>
        </div>
    </div>     
    
    
</div>
</div><!-- END .container -->
<div class="clearfix"></div>                 
        </div>
<?php include 'include/footer.php' ?>