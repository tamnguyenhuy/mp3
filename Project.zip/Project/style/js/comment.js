var zmp3Comment = {
    timer: null,
    delay: 0,
    type: '',
    id: '',
    tpl: null,
    tplRep: null,
    maximumItemPerPage: 20,
    page: 1,
    sortBy: "hot", //sortBy = hot || new
    dynamic: function (el) {
        var args = $(el).data();
        if (args !== undefined) {
            $(el).remove();
            if (args.id && args.type) {
                zmp3Comment.init(args.id, args.type);
            }
        }

    },
    remove: function (item) {
        $.post(MP3.API_COMMENT_URL + '/comment/remove?callback=?', {
            oid: this.id,
            cid: item.data('id'),
            type: this.type
        }, function (rsp) {
            item.remove();
            zmp3UI.showMsg(rsp.note, rsp.err ? 1 : 0);
        }, 'json');
    },
    onChangeCommentSort: function () {
        $(".fn-com-sort").change(function () {
            if ($(this).val() === "new") {
                zmp3Comment.sortBy = "new";
            } else {
                zmp3Comment.sortBy = "hot";
            }
            $('#commentList .fn-page').remove().children().off();
            $("#commentList").off();
            zmp3Comment.page = 1;
            zmp3Comment.load(zmp3Comment.page);
        });
    },
    pagination: function (el) {
        el.removeClass('none');
        var total = parseInt(0.999 + (el.data('total')));
        var cur = parseInt(el.data('page'));
        var page, max = 5;
        $('.fn-page', el).addClass('none');
        if (cur < total) {
            $('.fn-last', el).removeClass('none').data('page', total);
            $('.fn-next', el).removeClass('none').data('page', cur + 1);
        } else {
            cur = total;
        }
        if (cur > 1) {
            max = cur > 2 ? cur + 2 : cur + 3;
            $('.fn-first', el).removeClass('none').data('page', 1);
            $('.fn-prev', el).removeClass('none').data('page', cur - 1);
        }
        page = cur - 2;
        if (total < max) {
            page -= (max - total);
            max = total;
        }
        if (page < 1) {
            page = 1;
        }
        for (var i = 1; i <= 5 & page <= max; i++ , page++) {
            $('.fn-page' + i, el).removeClass('none');
            if (page == cur) {
                $('.fn-page' + i, el).addClass('active').data('page', page).html(page);
                ;
            } else {
                $('.fn-page' + i, el).removeClass('active').data('page', page).html(page);
            }
        }
    },
    init: function (id, t) {
        this.id = id;
        this.type = t;
        if ($('.fn-com-sort').val() === "new") {
            this.sortBy = "new";
        }
        this.onChangeCommentSort();
        tpl = document.getElementById('tplComment').cloneNode(true);
        tplRep = document.getElementById('tplCommentRep').cloneNode(true);
        $(tpl).removeClass('none');
        $('#tplComment').remove();
        $('#pagination .fn-page').click(function () {
            if (!$(this).hasClass('active')) {
                zmp3Comment.load($(this).data('page'));
            }
            return false;
        });

        $('#fn-comment-load-more').click(function () {
            zmp3Comment.page++;
            zmp3Comment.load(zmp3Comment.page);
            return false;
        });

        $('#pagination .fn-page').click(function () {
            if (!$(this).hasClass('active')) {
                zmp3Comment.load($(this).data('page'));
            }
            return false;
        });

        $(".wrapper-page").on("submit", "form.fn-comment", function () {
            zmp3Comment.add(this);
            return false;
        });

        zmp3Comment.load(1);

        if (MP3.ACCOUNT_ID === '' || MP3.ACCOUNT_ID === 0) {
            $('.fn-useravatar').attr('src', 'http://static.mp3.zdn.vn/skins/zmp3-v4.2/images/default2/user_avatar.jpg');
        }
    },
    load: function (page, force) {
        $.getJSON(MP3.API_COMMENT_URL + '/comment/get-comments', {
            op: 'get',
            type: this.type,
            id: this.id.toUpperCase(),
            page: page,
            start: (page - 1) * zmp3Comment.maximumItemPerPage,
            count: zmp3Comment.maximumItemPerPage,
            sort: zmp3Comment.sortBy
        }, function (rs) {
            $('#commentCounter').html(rs.data.total);
            if (Number(rs.data.total) > 0) {
                $(".fn-com-sort").parent().removeClass("none");
            } else {
                $(".frm-comment.fn-comment").css("border-bottom-style", "none");
            }
            if (rs.data && rs.data.comments) {
                setTimeout(function () {
                    zmp3Comment.build(page, rs);
                    if (rs.data.total > page * zmp3Comment.maximumItemPerPage) {
                        $('#fn-comment-load-more').removeClass('none');
                    } else {
                        $('#fn-comment-load-more').addClass('none');
                    }
                }, 200);
            }
        });
        //}
    },
    build: function (page, rs) {
        //$('#commentList .fn-page').addClass('none');
        for (var i in rs.data.comments) {
            var tpl1 = tpl.cloneNode(true);
            var item = rs.data.comments[i];
            var elId = 'zmp3' + item.commentId;
            $('#list-comment-replies', tpl1).addClass('list-comment-replies-' + item.commentId);
            $(tpl1).attr('id', elId).attr('data-userid', item.ownerId);
            $(tpl1).addClass('fn-page fn-page' + page);
            $('.username', tpl1).html(item.username);
            $('.thumb-user img', tpl1).attr("src", item.avatar);
            $('.fn-content', tpl1).html(item.content);
            $('.fn-time', tpl1).html(zmp3DateTime.format(item.time));
            $('.fn-delete', tpl1).data('item', '#' + elId).click(function () {
                zmp3Comment.remove($($(this).data('item')));
                return false;
            });

            $('.fn-totallike', tpl1).html(item.totalLike);
            if (item.totalLike == 0) {
                $('.fn-totallike', tpl1).addClass("none");
            } else {
                $('.fn-totallike', tpl1).removeClass("none");
            }
            $('.fn-like', tpl1).attr('id', 'fn-like-click-' + item.commentId).attr('data-id', item.commentId).attr('data-total-like', item.totalLike).attr('data-total-dlike', item.totalDisLike);
            if (item.isUpVoted == 1) {
                $('.func-comment .fn-up-vote', tpl1).addClass('active');
                $('.func-comment .fn-down-vote', tpl1).removeClass('active');
            }
            $('.fn-totaldislike', tpl1).html(item.totalDisLike);
            if (item.totalDisLike == 0) {
                $('.fn-totaldislike', tpl1).addClass("none");
            } else {
                $('.fn-totaldislike', tpl1).removeClass("none");
            }
            $('.fn-dlike', tpl1).attr('id', 'fn-dlike-click-' + item.commentId).attr('data-id', item.commentId).attr('data-total-like', item.totalLike).attr('data-total-dlike', item.totalDisLike);
            if (item.isDownVoted == 1) {
                $('.func-comment .fn-down-vote', tpl1).addClass('active');
                $('.func-comment .fn-up-vote', tpl1).removeClass('active');
            }

            /*upvote - unupvote*/
            this.voteAction(item.commentId);
            /*downvote - undownvote*/
            this.downVoteAction(item.commentId);

            $('.fn-totalrep', tpl1).html(item.totalReply);
            $('.fn-reply', tpl1).attr('id', 'fn-rep-click-' + item.commentId).attr('data-target', '#fn-rep-show-box-' + item.commentId).attr('data-id', item.commentId);
            $('#comment_reply_wrapper', tpl1).attr('id', 'fn-rep-show-box-' + item.commentId);
            $('#commentList').on("click", '#fn-rep-click-' + item.commentId, function () {
                $("div[id*='fn-rep-show']").addClass('none');
                var listBoxReps = $("div[id*='fn-rep-show']");
                for (var i = 0; i < listBoxReps.length; i++) {
                    if (!$(listBoxReps[i]).hasClass('none')) {
                        $(listBoxReps[i]).addClass('none');
                    }
                }
                var boxRepTarget = $(this).attr('data-target');
                //$("div[id*='fn-rep-show']");
                $('.child-comment').addClass('none');
                $(boxRepTarget).removeClass('none');
                var targetCommentId = $(this).attr('data-id');

                $('#fn-rep-show-box-' + targetCommentId + ' #comment-info').attr('value', targetCommentId);
            });

            if (typeof rs.data.comments[i] != 'undefined' && rs.data.comments[i] != null
                && typeof rs.data.comments[i].replies != 'undefined' && rs.data.comments[i].replies != null
                && typeof rs.data.comments[i].replies.length != 'undefined' && rs.data.comments[i].replies.length > 0) {

                for (var j = 0; j < rs.data.comments[i].replies.length; j++) {
                    var tplRep1 = tplRep.cloneNode(true);
                    var item = rs.data.comments[i].replies[j];
                    $(tplRep1).attr('data-userid', item.ownerId).addClass('item-rep-com-' + item.commentId);
                    $('.fn-reply', tplRep1).attr('id', 'fn-rep-click-' + item.commentId)
                        .attr('data-target', '#fn-rep-show-box-' + item.commentId)
                        .attr('data-id', item.commentId)
                        .addClass('rep-comment-' + item.commentId);

                    $('#comment_reply_reply_wrapper', tplRep1).attr('id', 'fn-rep-show-box-' + item.commentId);

                    $('.fn-totallike', tplRep1).html(item.totalLike);
                    if (item.totalLike == 0) {
                        $('.fn-totallike', tplRep1).addClass("none");
                    } else {
                        $('.fn-totallike', tplRep1).removeClass("none");
                    }
                    $('.fn-like', tplRep1).attr('id', 'fn-like-click-' + item.commentId).attr('data-id', item.commentId).attr('data-total-like', item.totalLike).attr('data-total-dlike', item.totalDisLike);
                    if (item.isUpVoted == 1) {
                        $('.func-comment .fn-up-vote', tplRep1).addClass('active');
                        $('.func-comment .fn-down-vote', tplRep1).removeClass('active');
                    }
                    $('.fn-totaldislike', tplRep1).html(item.totalDisLike);
                    if (item.totalDisLike == 0) {
                        $('.fn-totaldislike', tplRep1).addClass("none");
                    } else {
                        $('.fn-totaldislike', tplRep1).removeClass("none");
                    }
                    $('.fn-dlike', tplRep1).attr('id', 'fn-dlike-click-' + item.commentId).attr('data-id', item.commentId).attr('data-total-like', item.totalLike).attr('data-total-dlike', item.totalDisLike);

                    if (item.isDownVoted == 1) {
                        $('.func-comment .fn-down-vote', tplRep1).addClass('active');
                        $('.func-comment .fn-up-vote', tplRep1).removeClass('active');
                    }

                    /*upvote - unupvote*/
                    zmp3Comment.voteAction(item.commentId);
                    /*downvote - undownvote*/
                    zmp3Comment.downVoteAction(item.commentId);
                    $('.username', tplRep1).html(item.username);
                    $('.thumb-user img', tplRep1).attr("src", item.avatar);            
                    $('.fn-totalrep', tplRep1).html(item.totalReply);
                    $('.fn-content-rep', tplRep1).html(item.content);
                    $('.fn-time', tplRep1).html(zmp3DateTime.format(item.time));

                    $('#commentList').on("click", '#fn-rep-click-' + item.commentId, function () {
                        $("div[id*='fn-rep-show']").addClass('none');
                        var listBoxReps = $("div[id*='fn-rep-show']");
                        for (var i = 0; i < listBoxReps.length; i++) {
                            if (!$(listBoxReps[i]).hasClass('none')) {
                                $(listBoxReps[i]).addClass('none');
                            }
                        }
                        var boxRepTarget = $(this).attr('data-target');
                        $('.child-comment').addClass('none');
                        $(boxRepTarget).removeClass('none');
                        var targetCommentId = $(this).attr('data-id');
                        $(boxRepTarget + ' #comment-info').attr('value', targetCommentId);
                        var displaynameComment = $(this).parent().parent().children('.fn-com-user-name').text();
                        displaynameComment = "<i>@" + displaynameComment + "</i>: ";
                        $(boxRepTarget + ' #comment-reply').attr('value', displaynameComment);

                    });

                    if (j <= 2) {
                        $(tplRep1).removeClass('none');
                    }
                    $('#list-comment-replies', tpl1).append(tplRep1);
                }
                if (rs.data.comments[i].totalReply > 2) {
                    $('.view_all_reply', tpl1).html('Xem tất cả ' + rs.data[i].totalReply + ' câu trả lời').removeClass('none').attr('target', rs.data[i].commentId);
                    $(tpl1).on("click", '.view_all_reply', function () {
                        /* Show all replies of this comment*/
                        var idtarget = $(this).attr('target');
                        $('.item-rep-com-' + idtarget).removeClass('none');
                        $(this).addClass('none');

                        $.getJSON(MP3.API_COMMENT_URL + '/comment/get-comments', {
                            op: 'get',
                            type: this.type,
                            commentId: idtarget,
                            start: 0,
                            length: 10
                        }, function (rs) {
                            if (rs.data !== null && rs.data !== "" && rs.data.comments) {
                                for (var i = rs.data.length - 3; i >= 0; i--) {
                                    var tplRep1 = tplRep.cloneNode(true);
                                    var item = rs.data.comments[i];
                                    $(tplRep1).attr('data-userid', item.ownerId).addClass('item-rep-com-' + idtarget);
                                    $('.fn-reply', tplRep1)
                                        .attr('id', 'fn-rep-click-' + item.commentId)
                                        .attr('data-target', '#fn-rep-show-box-' + item.commentId)
                                        .attr('data-id', idtarget)
                                        .addClass('rep-comment-' + idtarget);
                                    $('#comment_reply_reply_wrapper', tplRep1).attr('id', 'fn-rep-show-box-' + item.commentId);

                                    $('.fn-totallike', tplRep1).html(item.totalLike);
                                    if (item.totalLike == 0) {
                                        $('.fn-totallike', tplRep1).addClass("none");
                                    } else {
                                        $('.fn-totallike', tplRep1).removeClass("none");
                                    }
                                    $('.fn-like', tplRep1).attr('id', 'fn-like-click-' + item.commentId).attr('data-id', item.commentId).attr('data-total-like', item.totalLike).attr('data-total-dlike', item.totalDisLike);
                                    if (item.isUpVoted == 1) {
                                        $('.func-comment .fn-up-vote', tplRep1).addClass('active');
                                    }
                                    $('.fn-totaldislike', tplRep1).html(item.totalDisLike);
                                    if (item.totalDisLike == 0) {
                                        $('.fn-totaldislike', tplRep1).addClass("none");
                                    } else {
                                        $('.fn-totaldislike', tplRep1).removeClass("none");
                                    }

                                    $('.fn-dlike', tplRep1).attr('id', 'fn-dlike-click-' + item.commentId).attr('data-id', item.commentId).attr('data-total-like', item.totalLike).attr('data-total-dlike', item.totalDisLike);
                                    if (item.isDownVoted == 1) {
                                        $('.func-comment .fn-down-vote', tplRep1).addClass('active');
                                    }

                                    $('.fn-totaldislike', tplRep1).html(item.totalDisLike);

                                    /*upvote - unupvote*/
                                    zmp3Comment.voteAction(item.commentId);
                                    /*downvote - undownvote*/
                                    zmp3Comment.downVoteAction(item.commentId);

                                    $('.fn-content-rep', tplRep1).html(item.content);
                                    $('.fn-time', tplRep1).html(zmp3DateTime.format(item.time));
                                    $(tplRep1).removeClass('none');
                                    $('.list-comment-replies-' + idtarget).append(tplRep1);

                                    $('#commentList').on("click", '#fn-rep-click-' + item.commentId, function () {
                                        $("div[id*='fn-rep-show']").addClass('none');
                                        var listBoxReps = $("div[id*='fn-rep-show']");
                                        for (var i = 0; i < listBoxReps.length; i++) {
                                            if (!$(listBoxReps[i]).hasClass('none')) {
                                                $(listBoxReps[i]).addClass('none');
                                            }
                                        }
                                        var boxRepTarget = $(this).attr('data-target');

                                        $('.child-comment').addClass('none');
                                        $(boxRepTarget).removeClass('none');
                                        var targetCommentId = $(this).attr('data-id');
                                        $(boxRepTarget + ' #comment-info').attr('value', targetCommentId);
                                        var displaynameComment = $(this).parent().parent().children('.fn-com-user-name').text();
                                        displaynameComment = "<i>@" + displaynameComment + "</i>: ";
                                        $(boxRepTarget + ' #comment-reply').attr('value', displaynameComment);
                                        $('.fn-useravatar').attr('src', $('.fn-profile .fn-thumb').attr('src'));
                                    });
                                }
                            }
                        });

                        return false;
                    });
                }

            }
            $('#commentList').append(tpl1);
        }

        if (MP3.ACCOUNT_ID === '' || MP3.ACCOUNT_ID === 0) {
            $('.fn-useravatar').attr('src', 'http://static.mp3.zdn.vn/skins/zmp3-v4.2/images/default2/user_avatar.jpg');
        } else {
            $('.fn-useravatar').attr('src', $('.fn-profile .fn-thumb').attr('src'));
        }

        if (rs.total > 10) {
            if (rs.total > 200)
                rs.total = 200;
            $('#pagination').data('total', rs.total / 10).data('page', page);
            this.pagination($('#pagination'));
        }
    },
    buildReplies: function (commentId) {
        $.getJSON(MP3.API_COMMENT_URL + '/comment/get-comments', {
            op: 'get',
            type: this.type,
            commentId: commentId,
            start: 0,
            length: 10
        }, function (rs) {
            if (rs.data !== null && rs.data !== "" && rs.data.comments) {
                var tplRep = document.getElementById('tplCommentRep').cloneNode(true);
                var tplRep1 = tplRep.cloneNode(true);
                for (var i = rs.data.length - 3; i >= 0; i--) {
                    var item = rs.data.comments[i];
                    $(tplRep1).attr('data-userid', item.ownerId).addClass('item-rep-com-' + commentId);
                    $('.fn-reply', tplRep1).attr('id', 'fn-rep-click-' + item.commentId)
                        .attr('data-target', '#fn-rep-show-box-' + commentId)
                        .attr('data-id', commentId)
                        .addClass('rep-comment-' + commentId);
                    $('.fn-totallike', tplRep1).html(item.totalLike);
                    $('.fn-totalrep', tplRep1).html(item.totalReply);
                    $('.fn-content-rep', tplRep1).html(item.content);
                    $('.fn-time', tplRep1).html(zmp3DateTime.format(item.time));
                    $(tplRep1).removeClass('none');
                    var tpl1 = tpl.cloneNode(true);
                    $('#list-comment-replies', tpl1).append(tplRep1);
                }
            }
        });
    },
    voteAction: function (commentId) {
        //$( "p" ).unbind( "click" );
        $('#commentList').on("click", '#fn-like-click-' + commentId, function () {
            if (!MP3.ACCOUNT_ID) {
                zmp3Login.show();
                return false;
            }
            var isUpVote = true;
            var urlRes = MP3.API_COMMENT_URL + '/comment/vote?action=up';
            if ($(this).children('.fn-up-vote.active').length > 0) {
                urlRes = MP3.API_COMMENT_URL + '/comment/vote?action=unup';
                isUpVote = false;
            }
            var thisE = this;
            var commentId = $(this).attr('data-id');

            $.ajax({
                url: urlRes,
                type: 'POST',
                dataType: 'json',
                xhrFields: {
                    withCredentials: true
                },
                crossDomain: true,
                data: {
                    commentId: commentId
                },
                success: function (rs) {
                    if (rs.err === 0) {
                        //update display
                        var totalLike = Number($(thisE).attr('data-total-like'));
                        var totalDisLike = Number($(thisE).attr('data-total-dlike'));
                        if (isUpVote) {
                            totalLike++;
                            $(thisE).children('.fn-totallike').text(totalLike);
                            $(thisE).children('.fn-up-vote').addClass('active');

                            if ($('#fn-dlike-click-' + commentId).children('.fn-down-vote.active').length > 0) {
                                $('#fn-dlike-click-' + commentId).children('.fn-down-vote').removeClass('active');
                                totalDisLike--;
                                $('#fn-dlike-click-' + commentId).children('.fn-totaldislike').text(totalDisLike);
                            }
                        } else {
                            totalLike--;
                            $(thisE).children('.fn-totallike').text(totalLike);
                            $(thisE).children('.fn-up-vote').removeClass('active');
                        }

                        $(thisE).attr('data-total-like', totalLike);
                        $(thisE).attr('data-total-dlike', totalDisLike);
                        $('#fn-dlike-click-' + commentId).attr('data-total-like', totalLike);
                        $('#fn-dlike-click-' + commentId).attr('data-total-dlike', totalDisLike);

                        if (totalLike == 0) {
                            $(thisE).children('.fn-totallike').addClass("none");
                        } else {
                            $(thisE).children('.fn-totallike').removeClass("none");
                        }

                        if (totalDisLike == 0) {
                            $('#fn-dlike-click-' + commentId).children('.fn-totaldislike').addClass("none");
                        } else {
                            $('#fn-dlike-click-' + commentId).children('.fn-totaldislike').removeClass("none");
                        }
                    }
                },
                error: function (xhr, ajaxOptions) {
                    console.log('err ', xhr);
                }
            });
        });
    },
    downVoteAction: function (commentId) {
        $('#commentList').on("click", '#fn-dlike-click-' + commentId, function () {
            if (!MP3.ACCOUNT_ID) {
                zmp3Login.show();
                return false;
            }
            var isDownVote = true;
            var urlRes = MP3.API_COMMENT_URL + '/comment/vote?action=down';
            if ($(this).children('.fn-down-vote.active').length > 0) {
                urlRes = MP3.API_COMMENT_URL + '/comment/vote?actiob=undown';
                isDownVote = false;
            }
            var thisE = this;
            var commentId = $(this).attr('data-id');

            $.ajax({
                url: urlRes,
                type: 'POST',
                dataType: 'json',
                xhrFields: {
                    withCredentials: true
                },
                crossDomain: true,
                data: {
                    commentId: commentId
                },
                success: function (rs) {
                    if (rs.err === 0) {
                        //update display
                        var totalDisLike = Number($(thisE).attr('data-total-dlike'));
                        var totalLike = Number($(thisE).attr('data-total-like'));
                        if (isDownVote) {
                            totalDisLike++;
                            $(thisE).children('.fn-totaldislike').text(totalDisLike)
                            $(thisE).children('.fn-down-vote').addClass('active');

                            if ($('#fn-like-click-' + commentId).children('.fn-up-vote.active').length > 0) {
                                $('#fn-like-click-' + commentId).children('.fn-up-vote').removeClass('active');
                                totalLike--;
                                $('#fn-like-click-' + commentId).children('.fn-totallike').text(totalLike);
                            }
                        } else {
                            totalDisLike--;
                            $(thisE).children('.fn-totaldislike').text(totalDisLike)
                            $(thisE).children('.fn-down-vote').removeClass('active');
                        }

                        $(thisE).attr('data-total-dlike', totalDisLike);
                        $(thisE).attr('data-total-like', totalLike);
                        $('#fn-like-click-' + commentId).attr('data-total-dlike', totalDisLike);
                        $('#fn-like-click-' + commentId).attr('data-total-like', totalLike);

                        if (totalLike == 0) {
                            $('#fn-like-click-' + commentId).children('.fn-totallike').addClass("none");
                        } else {
                            $('#fn-like-click-' + commentId).children('.fn-totallike').removeClass("none");
                        }

                        if (totalDisLike == 0) {
                            $(thisE).children('.fn-totaldislike').addClass("none");
                        } else {
                            $(thisE).children('.fn-totaldislike').removeClass("none");
                        }
                    }
                },
                error: function (xhr, ajaxOptions) {
                    console.log('err ', xhr);
                }
            });
        });
    },
    add: function (frm) {
        if (this.delay > 0)
            return false;
        if (zmp3Login.show()) {
            var content = frm.content.value;
            content = content.trim();
            frm.content.value = content;
            if (content === frm.content.defaultValue) {
                zmp3UI.showMsg('Bạn cần nhập nội dung bình luận.', 1);
            } else if (content.length < 2) {
                $("#box-comment-error").removeClass("none").html("Nội dung bình luận cần ít nhất 2 ký tự.");
                setTimeout(function () {
                    $("#box-comment-error").addClass("none")
                }, 5000);
                //zmp3UI.showMsg('Nội dung bình luận cần ít nhất 2 ký tự.', 1);
            } else if (content.length > 900) {
                //zmp3UI.showMsg('Nội dung bình luận chỉ cho phép tối đa 900 ký tự.', 1);
                $("#box-comment-error").removeClass("none").html("Nội dung bình luận chỉ cho phép tối đa 900 ký tự.");
                setTimeout(function () {
                    $("#box-comment-error").addClass("none")
                }, 5000);
            } else if (!zmp3Comment.loading) {
                zmp3Comment.loading = true;
                $.ajax({
                    url: MP3.API_COMMENT_URL + '/comment/add-comment',
                    type: 'POST',
                    dataType: 'json',
                    xhrFields: {
                        withCredentials: true
                    },
                    crossDomain: true,
                    data: $(frm).serialize(),
                    success: function (rs) {
                        if (!rs.err) {
                            if (rs.data && rs.data.length > 0) {
                                zmp3Comment.build(1, rs);
                            }
                            frm.content.value = '';
                            zmp3Comment.countdown(frm);
                        }
                        zmp3UI.showMsg(rs.msg, rs.err ? 1 : 0);
                    },
                    error: function (xhr, ajaxOptions) {
                        console.log('err ', xhr);
                    }
                });
            }
        }
    },
    harsCounter: function (frm) {
        var len = frm.content.value.length;
        if (len > 0 && frm.content.value.charCodeAt(len - 1) === 32)
            len--;
    },
    countdown: function (frm) {
        this.delay = 15;
        $(frm).addClass('disabled');
        $(frm.btnSubmit).html('Vui lòng chờ 15 giây');
        this.timer = setInterval(function () {
            if (zmp3Comment.delay > 0) {
                $(frm.btnSubmit).html('Vui lòng chờ ' + zmp3Comment.delay + ' giây');
                zmp3Comment.delay--;
            } else {
                $(frm).removeClass('disabled');
                $(frm.btnSubmit).html('Bình luận');
                clearInterval(zmp3Comment.timer);
            }

        }, 1000);
    }
};

$(document).ready(function () {
    zmp3Comment.dynamic()
});