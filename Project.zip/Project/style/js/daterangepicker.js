Calender_Resources = {
    "vi":{
        weekTitle : "Tuần",
        weekDays : ["Hai", "Ba", "Tư", "Năm", "Sáu" ,"Bảy", "CN"],
        preYear : "Năm trước",
        preMonth : "Tháng trước",
        nextYear : "Năm sau",
        nextMonth : "Tháng sau",
        monthArray : ["Th.Giêng","Tháng 2","Tháng 3","Tháng tư",
                      "Tháng 5","Tháng 6","Tháng 7","Tháng 8",
                       "Tháng 9","Tháng 10","Tháng 11","Tháng 12"],
        noSelected : "Chưa chọn",
        selectedSingleDate : "Ngày : ",
        selectedDates : " Ngày"
    }
};
Calender_Config = {
    language : "vi",
    printFormat : "YYYY-MM-DD",
    theme : {
        defaultTheme : {
            css : "daterangepicker",
            topPanel: [  //The top panel's layout and text, Not change id.
                {text : "<", id : "preMonth"},                
                {text : "", id : "thisMonth"},
                {text : "|", id : "separator"},
                {text : "", id : "thisYear"},
                {text : ">", id : "nextMonth"}
     ],
            firstDayInWeek : 0
        }
    },
    dates : { }
};
/**
 * Construct a new PopCalender.
 * @class Represents a PopCalender.
 * @constructor
 * @example 
 * var myCalender = new JSCalender.PopCalender("inputId", "buttonId");
 * @param {String} targetId The id of the Calender's input element.
 * @param {String} onClickElementId The id of the Calender's input element.
 * @return A new instance of a Calender.
 */
JSCalender = {
};
JSCalender.PopCalender = function(targetId, onClickElementId){
   /**
    * The id of input element where calender outputs
    * @type String
    */
    this.targetId = targetId;

    /**
     * The id of the element which be clicked to show calender
     * @type String
     */
    this.onClickElementId = onClickElementId;
};

/**
 * Show the calendar.
 * @public
 */
JSCalender.PopCalender.prototype.show = function(){
    this._initialize();
    if(document.popCalendar){
        if(document.popCalendar.calendarContainerId == this.calendarContainerId){
            this._show();
            return;
        }
        else{
            this._remove();
        }
    }
    this._createCalendarContainer();

    //add event after dom was created.
    this._addDocumentEvent();
    this._addCalendarEvent();
    document.popCalendar = this;
};

/**
* Initialize calendar.
* @private
*/
JSCalender.PopCalender.prototype._initialize = function(){
    /**
     * The id of calender's container
     * @default "fogtower-calendar-calendarcontainer"
     * @type String
     */
    this.calendarContainerId = this.targetId ? this.targetId + "-calendarcontainer" : "fogtower-calendar-calendarcontainer";

    /**
     * The config of calender
     * @type Object
     */
    this.config = Calender_Config;

    /**
     * The theme of calender
     * @default "defaultTheme"
     * @type String
     */
    this.themeName = "defaultTheme";

    /**
     * The resource of calender
     * @type Object
     */
    this.resource = Calender_Resources[(this.config.language 
                    || (navigator.browserLanguage?navigator.browserLanguage:navigator.language)).toLowerCase()];

    /**
     * The first day in week
     * @example 
     * this.firstDayInWeek = 0;
     * The first day in week is Monday.
     * this.firstDayInWeek = 6;
     * The first day in week is Sunday.
     * @type Number
     */
    this.firstDayInWeek = this.config.theme[this.themeName].firstDayInWeek;

    /**
     * The days' number in month
     * @type Array
     */
    this.monthDate = [31,28,31,30,31,30,31,31,30,31,30,31];

    /**
     * Today
     * @type Date
     */
    this.thisDay = new Date();

    /**
     * This year
     * @type Number
     */
    this.year = this.thisDay.getFullYear();

    /**
     * This month
     * @type Number
     */
    this.month = this.thisDay.getMonth();
};


/**
 * Get type of the browser.
 * @namespace The browser's type
 * @public
 */
JSCalender.PopCalender.prototype.Browser = {
    /**
     * Browser is IE
     * @public
     * @type Boolean
     */
    IE : !!(window.attachEvent && !window.opera),

    /**
     * Browser is Firefox
     * @public
     * @type Boolean
     */
    FF : navigator.userAgent.indexOf('Gecko') > -1 && navigator.userAgent.indexOf('KHTML') == -1,

    /**
     * Browser is Opera
     * @public
     * @type Boolean
     */
    Opera : !!window.opera,

    /**
     * Browser is WebKit
     * @public
     * @type Boolean
     */
    WebKit : navigator.userAgent.indexOf('AppleWebKit/') > -1
};



/**
 * Create calendar's container.
 * @private
 */
JSCalender.PopCalender.prototype._createCalendarContainer = function(){
    this.calendarContainer = document.getElementById(this.calendarContainerId);
    if(this.calendarContainer){
        this.calendarContainer.parentNode.removeChild(this.calendarContainer);
    }
    var pos = this._getPosition(document.getElementById(this.onClickElementId));
    this.top = pos.top;
    this.left = pos.left;
    
    this.calendarContainer = document.createElement("div");
    this.calendarContainer.id = this.calendarContainerId;
    this.calendarContainer.className = this.config.theme[this.themeName].css;    
    document.body.appendChild(this.calendarContainer);
    
    this.calendarContainer.innerHTML = this._createCalendarPanel();
    if(this.Browser.IE){
        document.body.appendChild(this._createIframeShim());
    }
    this.calendarContainer.style.left = (this.left - this.calendarContainer.clientWidth + 65) + "px";
    this.calendarContainer.style.top = this.top + "px";
    console.log(this.calendarContainer.clientWidth);
    document.getElementById(this.calendarContainerId + "-thisYear").innerHTML = this.year;
    document.getElementById(this.calendarContainerId + "-thisMonth").innerHTML = this.resource.monthArray[this.month];
};

/**
 * Create a iframe to fix the combobox's bug of IE6.
 * @returns {Object} The created iframe.
 * @private
 */
JSCalender.PopCalender.prototype._createIframeShim = function(){
    var iframe = document.getElementById(this.calendarContainerId + "-iframeshim");
    if(iframe){
        iframe.parentNode.removeChild(iframe);
    }
    iframe = document.createElement("iframe");
    iframe.id = this.calendarContainerId + "-iframeshim";
    iframe.className = this.config.theme[this.themeName].css + "-iframeshim"
    iframe.scrolling = "no";
    iframe.frameBorder = "0";
    iframe.style.position = "absolute";
    iframe.style.left = this.left + "px";
    iframe.style.top = this.top + "px";
    iframe.style.width = this.calendarContainer.offsetWidth + "px";
    iframe.style.height = this.calendarContainer.offsetHeight + "px";
    return iframe;
};

/**
 * Create calendar's panel.
 * @private
 * @returns {String} Create panel of calendar.
*/
JSCalender.PopCalender.prototype._createCalendarPanel = function(){
    var str = "<div class='calendar left' style='display: block;'><table class='table-condensed' cellspacing='0' cellpadding='0'>"
            + this._createCalendarTop()
    + "<tbody id='" + this.calendarContainerId + "-bodypanel'>"
            + this._createCalendarDates()
    +"</tbody>"
            + this._createCalendarBottom()
            + "</table></div>";
    return str; 
};


/**
 * Create calendar's slide panel.
 * @private
 * @returns {String} Create slide panel of calendar.
*/
JSCalender.PopCalender.prototype._createCalendarSlide = function(){
        var str = "<table class='slidepanel' id='"
                    + this.calendarContainerId + "-slidePanel" 
                        + "'><tr><td></td><td class='slidepanel-text'></td></tr><tr><td class='slidepanel-text' colspan='2'></td></tr></table>";
        return str;
};

/**
 * Create calendar's top panel.
 * @private
 * @returns {String} Create top panel of calendar.
*/
JSCalender.PopCalender.prototype._createCalendarTop = function(){
    var str = "<thead class='toppanel'><tr>";
    str+='<th id="'+this.calendarContainerId + '-preMonth" class="prev available">&lt;</th><th colspan="6" style="width: auto"><span id="'+this.calendarContainerId + '-thisMonth"></span> | <span id="'+this.calendarContainerId + '-thisYear"></span></th>';
    str+='<th id="'+this.calendarContainerId + '-nextMonth" class="next available">&gt;</th>';
    return str + "</tr>"+this._createCalendarDays()+"</thead>";
};

/**
 * Create calendar's body panel.
 * @private
 * @returns {String} Create body panel of calendar.
*/
JSCalender.PopCalender.prototype._createCalendarBody = function(){
    var str = "<tbody cellspacing='0' cellpadding='0' class='bodypanel'>"
            + this._createCalendarDates()
            + "</tbody>";
    return str;
};

/**
 * Create calendar's days in body panel.
 * @private
 * @returns {String} Create days in body panel of calendar.
*/
JSCalender.PopCalender.prototype._createCalendarDays = function(){
    var weekTitle = this.resource.weekTitle;
    var weekDays = this.resource.weekDays;
    var firstDayInWeek = this.firstDayInWeek;
    var arr = [];
    if(typeof firstDayInWeek != "number" || firstDayInWeek > 6 || firstDayInWeek < 0){
        firstDayInWeek = 6;
    }
    for(var i = 0; i < 7; i++){
        if(i >= firstDayInWeek){
            arr[i - firstDayInWeek] = weekDays[i];
        }
        else{
            arr[7- firstDayInWeek + i] = weekDays[i];
        }
    }
    var str = "<tr class='bodypanel-headrow'><th class='bodypanel-weekhead'>" + weekTitle + "</th>";
    for(var i = 0;i < 7; i++){
        str += "<th class='bodypanel-dayhead";
        if(arr[i] == weekDays[5] || arr[i] == weekDays[6]){
            str +=" bodypanel-weekendhead";
        }
        str += "'>" + arr[i] + "</th>";
    }
    str += "</tr>";
    return str;
};

/**
 * Create calendar's dates in body panel.
 * @private
 * @returns {String} Create dates in body panel of calendar.
*/
JSCalender.PopCalender.prototype._createCalendarDates = function(){
    var firstDayInWeek = this.firstDayInWeek;
    var preMonthDate = this._getMonthDate((this.month == 0)?11:(this.month-1));
    var thisMonthDate = this._getMonthDate(this.month);
    var weekNumber = this._getYearWeek(new Date(this.year, this.month, 1));
    var _date = new Date(this.year, this.month, 1);
    var weekDay = _date.getDay() - 1 - firstDayInWeek;
    if(weekDay < 0){
        weekDay = weekDay + 7;
    }
    var str = "<tr><td class='available cell-week'>"
        + weekNumber++ 
        + "</td>";

    //create last month dates
    for(var i = 1; i < weekDay + 1; i++){
        var date = preMonthDate - weekDay + i;
        var dateString = "";
            if(this.month == 0){
                dateString = this._getDateString(this.year - 1, 12, date);
            }else{
                dateString = this._getDateString(this.year, this.month, date);
            }
        str += "<td class='available off' date='" + dateString;
        str += "'>" + date + "</td>";
    }

    //create this month dates
    var count = weekDay;
    for(var j = 1; j < thisMonthDate + 1; j++){
        if(count != 0 && count%7 == 0){
            str += "<tr><td class='available cell-week'>"
                + weekNumber++ 
                + "</td>";
        }
        var _day = new Date(this.year, this.month, j).getDay();
        var dateString = this._getDateString(this.year, this.month+1, j);
        str += "<td date='" + dateString + "' class='";
        if(_day == 0 || _day == 6){
            str += "available bodypanel-weekend"
        }
        else{
            str += "available"
        }
        var today = this._getDateString(this.thisDay.getFullYear(), this.thisDay.getMonth() + 1, this.thisDay.getDate());
        if(today == this._getDateString(this.year, this.month+1, j)){
            str += " active start-date"
        }
        if(this.config.dates[dateString] && this.config.dates[dateString].text){
            str += "' title='"  + this.config.dates[dateString].text;
        }
        str += "'>" + j + "</td>";
        count++;
        if(count != 0 && count%7 == 0){
            str += "</tr>";
        }
    }

    //create next month dates
    _date = new Date(this.year, this.month + 1, 1);
    weekDay = _date.getDay();
    if(((weekDay == 0)?6:weekDay - 1) != firstDayInWeek){
        var dayOfMonth = (firstDayInWeek >= 0)?(firstDayInWeek):6
        if(weekDay <= dayOfMonth){
            var nextMonthCount = dayOfMonth - weekDay;
        }
        else{
            var nextMonthCount = dayOfMonth + 7 - weekDay;
        }
        for(var n = 1; n < nextMonthCount + 2; n++){
            var dateString = "";
            if(this.month == 11){
                dateString = this._getDateString(this.year + 1,1, n);
            }else{
                dateString = this._getDateString(this.year, this.month + 2, n);
            }
            str += "<td class='bodypanel-othermonthday' date='"
                + dateString + "'>" + n + "</td>";
        }
    }
    str += "</tr>";
    return str;
}

/**
 * Get the number of dates by month.
 * @param {Number} month The month.
 * @return The number of dates.
 */
JSCalender.PopCalender.prototype._getMonthDate = function(month){
    if(month == 1){
        return (0==this.year%4 && (this.year%100!=0 || this.year%400==0)) ? 29 : 28;
    }
    else{
        return this.monthDate[month];
    }
};

/**
 * Get the index of year's week by date.
 * @param {Date} date The date.
 * @return The index of week.
 */
JSCalender.PopCalender.prototype._getYearWeek = function(date){
    var fistDay = new Date(this.year, 0, 1);
    var d = Math.round((date.valueOf() - fistDay.valueOf()) / 86400000);
    var weekDay = fistDay.getDay() - 1 - this.firstDayInWeek;
    if(weekDay < 0){
        weekDay = weekDay + 7;
    }
    var value;
    if(d==0){
        value = 1;
    }
    else{
        value = (d + weekDay)/7 + 1;
    }
    return parseInt(value, 10);
};

/**
 * Create calendar's bottom panel.
 * @private
 * @returns {String} Create bottom panel of calendar.
 */
JSCalender.PopCalender.prototype._createCalendarBottom = function(){
    return "";
};

/**
 * Add event to calendar.
 * @private
 */
JSCalender.PopCalender.prototype._addCalendarEvent = function(){
    var othis = this;    
    var preMonth = document.getElementById(this.calendarContainerId + "-preMonth");
    preMonth.onclick = function(){
        othis._preMonth(false);
    }
    var nextMonth = document.getElementById(this.calendarContainerId + "-nextMonth");
    nextMonth.onclick = function(){
        othis._nextMonth(false);
    }
//    var rows = document.getElementById(this.calendarContainerId + "-bodypanel").childNodes[0].rows;
    var rows = document.getElementById(this.calendarContainerId + "-bodypanel").childNodes;
    for(var i = 0; i < rows.length; i++){
        var row = rows[i];
        row.onmouseover = function(){
            othis._addClass(this, "bodypanel-daterow-hover");
        }
        row.onmouseout = function(){
            othis._removeClass(this, "bodypanel-daterow-hover");
        }
        var cells = rows[i].cells;
        for(var j = 1; j < cells.length; j++){
            var date = cells[j];
            var dateValue = date.getAttribute("date");
            if(dateValue == this.selectedDateValue){
                this._addClass(date, "bodypanel-date-select");
                othis.selectedDate = date;
            }
            date.onclick = function(){
                if(othis.selectedDate){
                    othis._removeClass(othis.selectedDate, "bodypanel-date-select");
                }
                othis._addClass(this, "bodypanel-date-select");
                othis.selectedDate = this;
                othis.selectedDateValue = this.getAttribute("date");
                var month = parseInt(othis.selectedDateValue.split('-')[1],10);
                var thisMonth = othis.month + 1;
                if(thisMonth == 1 && month == 12){
                    othis._preMonth();
                }
                else if(thisMonth == 12 && month == 1){
                    othis._nextMonth();
                }
                else if(thisMonth > month){
                    othis._preMonth();
                }
                else if(thisMonth < month){
                    othis._nextMonth();
                }
                othis._print(othis.selectedDateValue);
                var dateInfo = othis.config.dates[othis.selectedDateValue];
                var defaultInfo = othis.config.dates["default"];                
            }
            date.ondblclick = function(){
                this.onclick();
                othis._hide();
            }
            date.onmouseover = function(){
                othis._addClass(this, "bodypanel-date-hover");
            }
            date.onmouseout = function(){
                othis._removeClass(this, "bodypanel-date-hover");
            }
        }
    }
};

/**
 * Add event to window.document.
 * @private
 */
JSCalender.PopCalender.prototype._addDocumentEvent = function(){
    if(document.addEventListener){
        document.addEventListener("keypress",this._keyEvent,false);
        document.addEventListener("mousedown",this._clickCheck,false);
    }
    else{
        document.attachEvent("onkeydown",this._keyEvent);
        document.attachEvent("onmousedown",this._clickCheck);
    }
};

/**
 * Hide calendar or combobox when clicked
 * @private
 */
JSCalender.PopCalender.prototype._clickCheck = function(event){
    var calendar = document.popCalendar;
    if (!calendar) {
        return;
    }
    event = window.event || event;
    var element = event.srcElement || event.target;
    var calendarDom = document.getElementById(calendar.calendarContainerId);
    
    for (; element != null && element != calendarDom; element = element.parentNode);
    if (element == null) {
        calendar._hide();
        return;
    }
}

/**
 * Process key event when press keyboard
 * @param {Object} event The event which comes from pressing keyboard.
 * @private
 */
JSCalender.PopCalender.prototype._keyEvent = function(event){
    var othis = document.popCalendar;
    var KEY = {
        LEFT  : 37,
        UP    : 38,
        RIGHT : 39,
        DOWN  : 40,
        ESC   : 27,
        ENTER : 13,
        SPACE : 32
    };
    var code = event.keyCode || event.charCode;
    if(event.ctrlKey){
        switch(code)
        {
            case KEY.LEFT:
                othis._preMonth();
                break;
            case KEY.RIGHT:
                othis._nextMonth();
                break;
            default:
                break;
        }
    }
    else{
        switch(code){
            case KEY.LEFT:
                othis._parseDate(1);
                break;
            case KEY.RIGHT:
                othis._parseDate(-1);
                break;
            case KEY.UP:
                othis._parseDate(7);
                break;
            case KEY.DOWN:
                othis._parseDate(-7);
                break;
            case KEY.ESC:
                othis._hide();
                break;
            case KEY.ENTER:
                othis._print(othis.selectedDateValue)
                othis._hide();
                break;
            case KEY.SPACE:
                othis.selectedDateValue = othis._getDateString(othis.thisDay.getFullYear(),othis.thisDay.getMonth()+1,othis.thisDay.getDate());
                othis.year = othis.thisDay.getFullYear();
                othis.month = othis.thisDay.getMonth();
                document.getElementById(othis.calendarContainerId + "-thisYear").innerHTML = othis.year;
                document.getElementById(othis.calendarContainerId + "-thisMonth").innerHTML = othis.resource.monthArray[othis.month];
                othis._freshDaysPanel();
                othis._print(othis.selectedDateValue);
                break;
            default: 
                break;
        }
    }
    if(othis.Browser.IE){
        return false;
    }
    else{
        event.preventDefault();
    }
};

/**
 * Get last month's calendar
 * @private
 */
JSCalender.PopCalender.prototype._preMonth = function(){
    if(this.month == 0){
        this.month = 11;
        this.year--;
        document.getElementById(this.calendarContainerId + "-thisYear").innerHTML = this.year;
    }
    else{
        this.month--;
    }
    this._freshDaysPanel();
    document.getElementById(this.calendarContainerId + "-thisMonth").innerHTML = this.resource.monthArray[this.month];
};

/**
 * Get next month's calendar
 * @private
 */
JSCalender.PopCalender.prototype._nextMonth = function(){
    if(this.month == 11){
        this.month = 0;
        this.year++;
        document.getElementById(this.calendarContainerId + "-thisYear").innerHTML = this.year;
    }
    else{
        this.month++;
    }
    this._freshDaysPanel();
    document.getElementById(this.calendarContainerId + "-thisMonth").innerHTML = this.resource.monthArray[this.month];
};

/**
 * Fresh calendar when press keyboard
 * @param {Number} step The diff which compares with the selected date.
 * @private
 */
JSCalender.PopCalender.prototype._parseDate = function(step){
    if(this.selectedDateValue){
        var arr = this.selectedDateValue.split('-');
        var date = new Date(new Date(arr[0],arr[1]-1,arr[2]) - 24*60*60*1000*step);
    }
    else{
        var date = new Date(this.thisDay - 24*60*60*1000*step);
    }
    this.year = date.getFullYear();
    this.month = date.getMonth();
    this.date = date.getDate();
    this.selectedDateValue = this._getDateString(this.year,this.month + 1,this.date);
    this._freshDaysPanel();
    document.getElementById(this.calendarContainerId + "-thisYear").innerHTML = this.year;
    document.getElementById(this.calendarContainerId + "-thisMonth").innerHTML = this.resource.monthArray[this.month];
};

/**
 * Convert Date to string
 * @param {Number} year The year.
 * @param {Number} month The month.
 * @param {Date} date The date.
 * @private
 */
JSCalender.PopCalender.prototype._getDateString = function(year,month,date){
    return year + "-" + ((month < 10)?("0" + (month)):month) + "-" + ((date < 10)?("0" + (date)):date)
};


/**
 * Fresh calendar
 * @private
 */
JSCalender.PopCalender.prototype._freshDaysPanel = function(){
    document.getElementById(this.calendarContainerId + "-bodypanel").innerHTML = this._createCalendarDates();
    this._addCalendarEvent();
    document.getElementById(this.calendarContainerId).focus();
};
/**
 * Get left and top of element
 * @param {Object} el The element which will be get left and top.
 * @private
 */
JSCalender.PopCalender.prototype._getPosition = function(el){
    var positionElement = el;
    var positionElementHeight = positionElement.offsetHeight;
    var positionElementWidth = positionElement.offsetWidth;

    var defaultTop = positionElement.offsetTop + positionElement.offsetHeight;
    var defaultLeft = positionElement.offsetLeft;
    while((positionElement = positionElement.offsetParent) != null){
        defaultTop += positionElement.offsetTop;
        defaultLeft += positionElement.offsetLeft;
    }
    var position = this.config.position; 
    var top = 0;
    var left = 0;
    switch(position){
        case "southeast" :
            top = defaultTop;
            left = defaultLeft;
            break;
        case "southwest" :
            top = defaultTop;
            left = defaultLeft + positionElementWidth;
            break;
        case "northeast" :
            top = defaultTop - positionElementHeight;
            left = defaultLeft;
            break;
        case "northwest" :
            top = defaultTop - positionElementHeight;
            left = defaultLeft + positionElementWidth;
            break;
        case "always" :
            break;
        default :
            top = defaultTop;
            left = defaultLeft;
            break;
    }
    return {top:top, left:left};
};

/**
 * Add css class to element.
 * @param {Object} el The element where adds class.
 * @param {String} className The css class which to be added..
 * @private
 */
JSCalender.PopCalender.prototype._addClass = function(el, className) {
    this._removeClass(el, className);
    el.className += " " + className;
};

/**
 * Remove css class of element.
 * @param {Object} el The element where removes class.
 * @param {String} className The css class which to be removed..
 * @private
 */
JSCalender.PopCalender.prototype._removeClass = function(el, className) {
    if (!(el && el.className)) {
        return;
    }
    var cssArr = el.className.split(" ");
    var newArr = new Array();
    for (var i = 0, len = cssArr.length; i< len; i++){
        if (cssArr[i] != className) {
            newArr[newArr.length] = cssArr[i];
        }
    }
    el.className = newArr.join(" ");
};

/**
 * Remove evnent of window.document
 * @private
 */
JSCalender.PopCalender.prototype._removeEvent = function() {
    if(document.removeEventListener){
        document.removeEventListener("keypress",this._keyEvent,false);
        document.removeEventListener("mousedown",this._clickCheck,false);
    }
    else{
        document.detachEvent("onkeydown",this._keyEvent);
        document.detachEvent("onmousedown",this._clickCheck);
    }
};

/**
 * Show calendar
 * @private
 */
JSCalender.PopCalender.prototype._show = function() {
    this._addDocumentEvent();
    var calendar = document.getElementById(this.calendarContainerId);
    if(calendar){
        calendar.style.display = "";
    }
    var iframeShim = document.getElementById(this.calendarContainerId + "-iframeshim");
    if(iframeShim){
        iframeShim.style.display = "";
    }
    //alert("_show  " + document.popCalendar.selectedDateValue)
};

/**
 * Hide calendar
 * @private
 */
JSCalender.PopCalender.prototype._hide = function() {
    this._removeEvent();
    var calendar = document.getElementById(this.calendarContainerId);
    if(calendar){
        calendar.style.display = "none";
    }
    var iframeShim = document.getElementById(this.calendarContainerId + "-iframeshim");
    if(iframeShim){
        iframeShim.style.display = "none";
    }
};

/**
 * Remove calendar
 * @private
 */
JSCalender.PopCalender.prototype._remove = function() {
    this._removeEvent();
    var calendarDom = document.getElementById(document.popCalendar.calendarContainerId);
    calendarDom.parentNode.removeChild(calendarDom);
    document.popCalendar = null;
};

/**
 * Output the selected date
 * @param {String} dateString The format of outputed date
 * @private
 */
JSCalender.PopCalender.prototype._print = function(dateString) {
        if(!dateString){
                return;
        }
    var arr = dateString.split('-');
    var printFormat = (this.config.printFormat || "").toLowerCase();
    printFormat = printFormat.replace("yyyy", arr[0]);
    var _year = arr[0] - parseInt(arr[0]/1000,10)*1000 - parseInt(arr[0]/100,10)*100;
    printFormat = printFormat.replace("yy", _year);
    printFormat = printFormat.replace("mm", arr[1]);
    printFormat = printFormat.replace("dd", arr[2]);
    
    var weekDay = this._getYearWeek(new Date(arr[0], arr[1]-1, arr[2]));
    printFormat = printFormat.replace("ww", weekDay);
     var targetElement = document.getElementById(this.targetId);
     if(targetElement){
         targetElement.value = printFormat;
     }
    if(this.config.callbackFn){
        this.config.callbackFn(printFormat);
    }
};
