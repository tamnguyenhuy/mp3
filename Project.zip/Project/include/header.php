<!DOCTYPE html>
<html lang="vi">
    <head>
        <title>Trang Chủ</title>
<meta name="description" content="Dịch vụ nhạc số với hàng triệu bài hát và MV có bản quyền chất lượng cao, giúp bạn nghe nhạc, tải nhạc, upload và đồng bộ kho nhạc của tôi trên nhiều thiết bị." />
<meta name="keywords" content="Zing MP3, nhac so, nhac cua toi, nghe nhac, tai nhac, tim nhac, nhac chat luong cao, upload nhac" />
<meta name="robots" content="index, follow" />
<meta name="author" content="Zing MP3" />
<link rel="canonical" href="">
<link rel="alternate" media="handheld" href="https://m.mp3.zing.vn">
<link rel="icon" type="image/png" href="style/images/icon_zing_mp3_60.png" />
<meta name="apple-itunes-app" content="app-id=992357547, app-argument=https://itunes.apple.com/vn/app/zing-mp3-lite/id992357547">
<meta name="google-site-verification" content="DAIQ-lQ5duJuduznrAkF5pv4rEgSS8K93Kbb41WUd38">
<meta property="og:title" content="Nghe nhạc hay - Tải nhạc hot - Tìm nhạc vui - Chất lượng cao | Zing MP3" />                
<meta property="og:description" content="Dịch vụ nhạc số với hàng triệu bài hát và MV có bản quyền chất lượng cao, giúp bạn nghe nhạc, tải nhạc, upload và đồng bộ kho nhạc của tôi trên nhiều thiết bị." />        

<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<link rel="stylesheet" href="style/css/style-8.3.6.5.min.css" media="all" type="text/css" />
<link rel="stylesheet" href="style/css/update-0.0.0.4.6.min.css" media="all" type="text/css" />    
        
<script type="text/javascript" src="style/js/jquery-2.1.0.min.js"></script>
<script type="text/javascript" src="style/js/underscore-min.js"></script>
<script async='async' src='https://www.googletagservices.com/tag/js/gpt.js'></script>

        
           
    </head>
    <body>
        <div id="header-version-v5" class="header-version-v5 none">
</div>
<header>
    <div class="container group">
        <div class="logo">
            <a href="" title="Zing MP3 - Đỉnh cao âm nhạc" class="hide-text">
                <img src="style/images/logo.png" alt="Zing MP3 - Đỉnh cao âm nhạc" />
            </a>
        </div>
        <div id="sug" class="section-search">
            <form action="tim-kiem/bai-hat.html" method="get" class="search">
                <input type="text" name="q" placeholder="Nhập nội dung cần tìm" class="input-txt" autocomplete="off">
                <span class="input-btn">
                    <button type="submit" class="zicon btn hide-text">Tìm kiếm</button>
                </span>
            </form>
            <div id="sugResultAll" class="none">                    
                <div class="title-row" style="font-weight: 700;color: gray;float: left;margin: 5px 10px;border: none;">Kết quả gợi ý</div>
                <div style="float: right;margin: 0px 10px;line-height: 30px;">
                    <a class="view-all" style="margin: 5px 10px;cursor: pointer;color: #666;font-size: 0.97em;">
                        Xem tất cả 
                        <i class="icon-arrow" style="background-position: -25px -1934px;top: 3px;right: 0px;width: 25px;height: 25px;position: absolute;"></i>
                    </a>
                </div>
                <div style="clear: both;"></div>
            </div>
            <div id="sugResult" class="fn-result suggestion-2 none">
                <ul id="listSug">
                    <li id="sugTopKeyword" class="none">                    
                        <ul class="fn-list" style="cursor: pointer;">
                            <li id="tplTopKeyword" class="none fn-item">                            
                                <div class="meta-search">                                
                                    <a class="ellipsis pad-top-5">
                                        <span class="fn-name fn-highlight"></span>                                        
                                    </a>
                                </div>                            
                            </li>
                        </ul>
                    </li>
                    <!--<li id="sugResultAll" class="none">                    
                        <div class="title-row" style="float: left;margin: 5px 10px;border: none;">Kết quả gợi ý</div>
                        <div style="float: right;margin: 5px 10px;line-height: 30px;">
                            <a class="view-all" style="margin: 5px 10px;cursor: pointer;color: #666;font-size: 0.97em;">
                                Xem tất cả 
                                <i class="icon-arrow" style="background-position: -25px -1934px;top: 8px;right: 0px;width: 25px;height: 25px;position: absolute;"></i>
                            </a>
                        </div>
                        <div style="clear: both;"></div>
                    </li>-->
                    <li id="sugTop" class="none">                    
                        <div class="title-row"><span class="ics zicon"></span>Nghe Nhiều</div>
                        <ul class="fn-list">                        
                        </ul>
                    </li>
                    <li id="sugVideo"  class="none">
                        <div class="title-row"><span class="ics zicon ics-video"></span>Video</div>
                        <ul class="fn-list">
                            <li id="tplSugVideo" class="none fn-item">
                                <a class="fn-link track-log" href="#">
                                    <div class="meta-search">
                                        <img class="fn-thumb">
                                        <p class="ellipsis pad-top-5">
                                            <span class="fn-name fn-highlight"></span>
                                            <br>
                                            <span class="fn-artist fn-highlight txt-info"></span>
                                        </p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li id="sugSong" class="none">
                        <div class="title-row"><span class="ics zicon ics-song"></span>Bài Hát</div>
                        <ul class="fn-list">
                            <li id="tplSugSong" class="none fn-item">
                                <a class="fn-link track-log" href="#">
                                    <div class="meta-search">                                
                                        <p class="ellipsis pad-top-5">
                                            <span class="fn-name fn-highlight"></span>
                                            <br>
                                            <span class="fn-artist fn-highlight txt-info"></span>
                                        </p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li id="sugAlbum" class="none">
                        <div class="title-row"><span class="ics zicon ics-album"></span>Album</div>
                        <ul class="fn-list">
                            <li id="tplSugAlbum" class="none fn-item">
                                <a class="fn-link track-log" href="#">
                                    <div class="meta-search">
                                        <img class="fn-thumb">
                                        <p class="ellipsis pad-top-5">
                                            <span class="fn-name fn-highlight"></span>
                                            <br>
                                            <span class="fn-artist fn-highlight txt-info"></span>
                                        </p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li id="sugArtist" class="none">
                        <div class="title-row"><span class="ics zicon ics-artist"></span>Nghệ Sĩ</div>
                        <ul class="fn-list">
                            <li id="tplSugArtist" class="none fn-item">
                                <a class="fn-link track-log" href="#">                            
                                    <div class="meta-search">
                                        <img class="fn-thumb">
                                        <span class="fn-name fn-highlight"></span>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
        <div>
            <a href="">Đăng nhập</a>
        </div>
        <!-- <div class="nav-account pull-right none fn-guestbox">
            <a href="">Đăng nhập</a>
            <a class="fn-login" href="#" title="Đăng nhập">Đăng nhập</a>
        </div> -->
        <div id="userBox" class="user-section pull-right none fn-userbox">
            <a href="vip?utm_source=WebZingMP3&utm_medium=popover_account&utm_campaign=buyVIP" class="zicon icon-vip fn-vip none"></a>
            <div class="user-jump">
                <img height="20px" class="fn-thumb" src="">
                <a href="#" class="name-log">
                    Cá nhân 
                    <i class="icon-s-arrow"></i>
                </a>
                <div class="tip-dropdown">
                    <span class="arr-top"></span>
                    <div class="avt-header">
                        <a class="fn-profile" href="mymusic" rel="nofollow" title="Nhạc cá nhân">
                            <img height="80px" class="fn-thumb" src="">
                        </a>
                    </div>
                    <ul>
                        <li>
                            <a class="fn-profile" target="_blank" rel="nofollow" href="mymusic" title="Nhạc cá nhân">
                                <i class="zicon icon-human-round"></i>
                                Nhạc cá nhân
                            </a>
                        </li>  
                        <li>
                            <a class="fn-merge-asset" target="_blank" rel="nofollow" href="http://asset.mp3.zing.vn" title="Chuyển nhạc sang Zalo">
                                <i class="zicon icon-human-round" style="background-position: 3px 6px;background-image: url(style/images/ic-sync.png);"></i>
                                Chuyển nhạc sang Zalo
                            </a>
                        </li>
                        <li>
                            <a class="fn-logout" href="http://id.mp3.zing.vn/logout?f=&cburl=&key=" title="Thoát">
                                <i class="zicon icon-door"></i>
                                Đăng xuất
                            </a>
                        </li>
                        <li>
                            <a href="vip?utm_source=WebZingMP3&utm_medium=popover_account&utm_campaign=buyVIP" target="_blank" class="btn-upgrade-vip1 fn-viprequire" data-step="2">
                                Nâng cấp VIP
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div> 
    </div>
</header>
        <nav>
    <div class="container">
        <ul class="main-nav group">
            <li class="home"><a id="navbar-home" title="Zing MP3" href="">Zing MP3</a></li>
            <li class="home-logo"><a title="Trang chủ" href=""><img src="style/images/logo-gray.png" alt="Zing MP3"></a></li>
            <li class="active"><a id="navbar-mymusic" class="fn-login" href="mymusic" title="Nhạc cá nhân">Nhạc Cá Nhân</a>
                <div class="megamenu submenu menu-col-1 fn-userbox">
                    <div class="subcol menu-col-1-narrow">
                        <div class="subinner_item">
                            <ul>
                                <li><a href="mymusic/favorites-song" title="Yêu thích">Yêu Thích</a></li>
                                <li><a href="mymusic/myplaylist" title="Playlist cá nhân">Playlist Cá Nhân</a></li>
                                <li><a href="mymusic/following-artist" title="Quan tâm">Quan tâm</a></li>
                                <li><a href="mymusic/upload" title="Nhạc upload">Nhạc Upload</a></li>            
                                <li><a href="u/" title="Kênh của tôi" class="fn-my-channel">Kênh của tôi</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->
                </div>
            </li>            
            <li class="separation"></li>
            
            <li><a id="navbar-chart" title="Zing Chart" href="zing-chart/index.html">#zingchart</a>
                <div class="megamenu submenu menu-col-4 menu-bxh">
                    <div class="subcol menu-col-1-narrow w140">
                        <div class="title-menu">#ZINGCHART</div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Bài Hát" href="zing-chart/bai-hat.html">Bài hát</a></li>
                                <!--<li><a title="Album" href="zing-chart-tuan-realtime/album.html">Album</a></li>-->
                                <li><a title="MV" href="zing-chart/video.html">MV</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->
                    <div class="subcol menu-col-1-narrow">
                        <div class="title-menu">Tuần</div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Bài Hát" href="zing-chart-tuan/bai-hat-Viet-Nam/IWZ9Z08I.html">Bài hát</a></li>
                                <li><a title="MV" href="zing-chart-tuan/video-Viet-Nam/IWZ9Z08W.html">MV</a></li>
                                <li><a title="Album" href="zing-chart-tuan/album-Viet-Nam/IWZ9Z08O.html">Album</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->
                    <div class="subcol menu-col-1-narrow w140">
                        <div class="title-menu">US-UK Chart</div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Bài Hát" href="zing-chart-tuan/bai-hat-US-UK/IWZ9Z0BW.html">Bài hát</a></li>
                                <li><a title="MV" href="zing-chart-tuan/video-US-UK/IWZ9Z0BU.html">MV</a></li>
                                <li><a title="Album" href="zing-chart-tuan/album-US-UK/IWZ9Z0B6.html">Album</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->
                    <div class="subcol menu-col-1-narrow w140">
                        <div class="title-menu">Kpop Chart</div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Bài Hát" href="zing-chart-tuan/bai-hat-Kpop/IWZ9Z0BO.html">Bài hát</a></li>
                                <li><a title="MV" href="zing-chart-tuan/video-Kpop/IWZ9Z0BZ.html">MV</a></li>
                                <li><a title="Album" href="zing-chart-tuan/album-Kpop/IWZ9Z0B7.html">Album</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->
                </div>
            </li>
            <li><a id="navbar-top100" title="Top 100" href="top100/Nhac-Tre/IWZ9Z088.html">Top 100</a>
                <div class="megamenu submenu menu-col-1">
                    <div class="subcol menu-col-1-narrow">
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Việt Nam" href="top100/Nhac-Tre/IWZ9Z088.html">Việt Nam</a></li>
                                <li><a title="Âu Mỹ" href="top100/Pop/IWZ9Z097.html">Âu Mỹ</a></li>
                                <li><a title="Châu Á" href="top100/Kpop/IWZ9Z08W.html">Châu Á</a></li>
                                <li><a title="Hòa Tấu" href="top100/Classical/IWZ9Z0BI.html">Hòa Tấu</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->
                </div>
            </li>
            <li><a id="navbar-topic" title="Chủ đề" href="chu-de">Chủ Đề</a>
                <div class="megamenu submenu menu-col-4">
                    <div class="subcol menu-col-1">
                        <div class="title-menu">Đề Xuất</div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Nhạc HOT" href="chu-de/Nhac-Hot/IWZ9Z0C8.html">Nhạc HOT</a></li>
                                <li><a title="Những Bài HITs Mới" href="chu-de/Nhung-Bai-Hit-Moi/IWZ9ZIWD.html">Những Bài HITs Mới</a></li>
                                <!--<li><a title="Nhạc Việt Mới" href="chu-de/Nhac-Viet-Moi/IWZ9Z0ED.html">Nhạc Việt Mới</a></li>-->
                                <li><a title="Nhạc Việt Bất Hủ" href="chu-de/Nhac-Viet-Bat-Hu/IWZ9ZI79.html">Nhạc Việt Bất Hủ</a></li>                                
                                <li><a title="Nhạc Bất Hủ Âu Mỹ" href="chu-de/Nhac-Bat-Hu-US-UK/IWZ9ZI77.html">Nhạc Bất Hủ Âu Mỹ</a></li>
                                <li><a title="K-Pop HITs" href="chu-de/K-Pop-HIT/IWZ9ZI9I.html">K-Pop HITs</a></li>
                                <li><a title="Nhạc Thúy Nga" href="chu-de/Nhac-Thuy-Nga/IWZ9ZIIZ.html">Nhạc Thúy Nga</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="subcol menu-col-1">
                        <div class="title-menu">Thể Loại</div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="EDM" href="chu-de/EDM/IWZ9Z0DU.html">EDM</a></li>
                                <li><a title="Acoustic" href="chu-de/Acoustic/IWZ977C8.html">Acoustic</a></li>                                
                                <li><a title="Audiophile" href="chu-de/Indie/IWZ978WA.html">Indie</a></li>
                                <li><a title="Nhạc Không Lời" href="chu-de/Nhac-Khong-Loi/IWZ9ZIOI.html">Nhạc Không Lời</a></li>
                                <li><a title="Nhạc Trữ Tình & Bolero" href="chu-de/Nhac-Tru-Tinh-Bolero/IWZ9ZI9W.html">Trữ Tình & Bolero</a></li>                        
                            </ul>
                        </div>
                    </div>
                    
                    <div class="subcol menu-col-1">
                        <div class="title-menu">Tâm Trạng</div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Những Ngày Mưa" href="chu-de/Nhung-Ngay-Mua/IWZ9ZIZD.html">Những Ngày Mưa</a></li>
                                <li><a title="Tình Yêu" href="chu-de/Music-For-Love/IWZ9Z0D9.html">Tình Yêu</a></li>
                                <li><a title="Buồn" href="chu-de/Sad-Songs-F-A/IWZ9ZIUI.html">Buồn</a></li>
                                <li><a title="Thư Giãn" href="chu-de/Am-Nhac-Thu-Gian/IWZ9ZIU0.html">Thư Giãn</a></li>
                                <li><a title="Động Lực" href="chu-de/Motivation/IWZ977FE.html">Động Lực</a></li>
                                
                            </ul>
                        </div>
                    </div>
                    
                    <div class="subcol menu-col-1">
                        <div class="title-menu">Hoạt Động</div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Làm Việc" href="chu-de/Lam-Viec/IWZ9ZI9O.html">Làm Việc</a></li>
                                <li><a title="Yoga" href="chu-de/Spa-Yoga/IWZ9ZIZF.html">Yoga</a></li>                                
                                <li><a title="Cà Phê" href="chu-de/Ca-Phe/IWZ9ZI6Z.html">Cà Phê</a></li>
                                <li><a title="Cuối Tuần" href="chu-de/Weekend/IWZ97806.html">Cuối Tuần</a></li>     
                                <li><a title="Tiệc Tùng" href="chu-de/Am-Nhac-Cho-Party/IWZ9ZIZE.html">Tiệc Tùng</a></li>
                                <li><a title="Du Lịch" href="chu-de/Du-Lich/IWZ9ZI6C.html">Du Lịch</a></li>                           
                            </ul>
                        </div>
                    </div><!--End .sub-col -->           
                    
                    
                </div>
            </li>
            <li><a id="navbar-genrevideo" title="Video" href="the-loai-video.html">Video</a>
                <div class="megamenu submenu menu-col-4">
                    <div class="subcol menu-col-1">
                        <div class="title-menu"><a title="Việt Nam" href="the-loai-video/Viet-Nam/IWZ9Z08I.html">Việt Nam</a></div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Nhạc Trẻ" href="the-loai-video/Nhac-Tre/IWZ9Z088.html">Nhạc Trẻ</a></li>
                                <li><a title="Nhạc Trữ Tình" href="the-loai-video/Nhac-Tru-Tinh/IWZ9Z08B.html">Nhạc Trữ Tình</a></li>
                                <li><a title="Nhạc Dance" href="the-loai-video/Nhac-Dance/IWZ9Z0CW.html">Dance Việt</a></li>
                                <li><a title="Rock Việt" href="the-loai-video/Rock-Viet/IWZ9Z08A.html">Rock Việt</a></li>
                                <li><a title="Rap Việt" href="the-loai-video/Rap-Viet/IWZ9Z089.html">Rap / Hip Hop Việt</a></li>
                                <li><a title="Nhạc Trịnh" href="the-loai-video/Nhac-Trinh/IWZ9Z08E.html">Nhạc Trịnh</a></li>
                                <li><a title="Nhạc Thiếu Nhi" href="the-loai-video/Nhac-Thieu-Nhi/IWZ9Z08F.html">Nhạc Thiếu Nhi</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->

                    <div class="subcol menu-col-1">
                        <div class="title-menu"><a title="Âu Mỹ" href="the-loai-video/US-UK/IWZ9Z08O.html">Âu Mỹ</a></div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Pop" href="the-loai-video/Pop/IWZ9Z097.html">Pop</a></li>
                                <li><a title="Rock" href="the-loai-video/Rock/IWZ9Z099.html">Rock</a></li>
                                <li><a title="Rap / Hip Hop" href="the-loai-video/Rap-Hip-Hop/IWZ9Z09B.html">Rap / Hip Hop</a></li>
                                <li><a title="Country" href="the-loai-video/Country/IWZ9Z096.html">Country</a></li>
                                <li><a title="Electronic / Dance" href="the-loai-video/Electronic-Dance/IWZ9Z09A.html">Electronic / Dance</a></li>
                                <li><a title="R&amp;B / Soul" href="the-loai-video/R-B-Soul/IWZ9Z09D.html">R&amp;B / Soul</a></li>
                                <li><a title="Audiophile" href="the-loai-video/Audiophile/IWZ9Z0EO.html">Audiophile</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->

                    <div class="subcol menu-col-1">
                        <div class="title-menu"><a title="Châu Á" href="the-loai-video/Kpop/IWZ9Z08W.html">Châu Á</a></div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Hàn Quốc" href="the-loai-video/Kpop/IWZ9Z08W.html">Hàn Quốc</a></li>
                                <li><a title="Nhật Bản" href="the-loai-video/Viet-Nam/Nhat-Ban/IWZ9Z08Z.html">Nhật Bản</a></li>
                                <li><a title="Hoa Ngữ" href="the-loai-video/Viet-Nam/Hoa-Ngu/IWZ9Z08U.html">Hoa Ngữ</a></li>
                                <li><a title="Thái Lan" href="the-loai-video/Thai-Lan/IWZ9Z0CZ.html">Thái Lan</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->

                    <div class="subcol menu-col-1">
                        <div class="title-menu"><a title="Hòa Tấu" href="the-loai-video/Hoa-Tau/IWZ9Z086.html">Hòa Tấu</a></div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Classical" href="the-loai-video/Classical/IWZ9Z0BI.html">Classical</a></li>
                                <li><a title="Piano" href="the-loai-video/Piano/IWZ9Z0B0.html">Piano</a></li>
                                <li><a title="Guitar" href="the-loai-video/Guitar/IWZ9Z0A9.html">Guitar</a></li>
                                <li><a title="Violin" href="the-loai-video/Violin/IWZ9Z0BU.html">Violin</a></li>
                                <li><a title="Cello" href="the-loai-video/Cello/IWZ9Z0AD.html">Cello</a></li>
                                <li><a title="Saxophone" href="the-loai-video/Saxophone/IWZ9Z0B7.html">Saxophone</a></li>
                                <li><a title="Nhạc Cụ Dân Tộc" href="the-loai-video/Nhac-Cu-Dan-Toc/IWZ9Z0AA.html">Nhạc Cụ Dân Tộc</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->
                </div>
            </li>            
            <li><a id="navbar-genrealbum" title="Album" href="the-loai-album.html">Album</a>
                <div class="megamenu submenu menu-col-4">
                    <div class="subcol menu-col-1">
                        <div class="title-menu"><a href="the-loai-album/Viet-Nam/IWZ9Z08I.html" title="Việt Nam">Việt Nam</a></div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Nhạc Trẻ" href="the-loai-album/Nhac-Tre/IWZ9Z088.html">Nhạc Trẻ</a></li>
                                <li><a title="Nhạc Trữ Tình" href="the-loai-album/Nhac-Tru-Tinh/IWZ9Z08B.html">Nhạc Trữ Tình</a></li>
                                <li><a title="Nhạc Dance" href="the-loai-album/Nhac-Dance/IWZ9Z0CW.html">Dance Việt</a></li>
                                <li><a title="Rock Việt" href="the-loai-album/Rock-Viet/IWZ9Z08A.html">Rock Việt</a></li>
                                <li><a title="Rap Việt" href="the-loai-album/Rap-Viet/IWZ9Z089.html">Rap / Hip Hop Việt</a></li>
                                <li><a title="Nhạc Trịnh" href="the-loai-album/Nhac-Trinh/IWZ9Z08E.html">Nhạc Trịnh</a></li>
                                <li><a title="Nhạc Thiếu Nhi" href="the-loai-album/Nhac-Thieu-Nhi/IWZ9Z08F.html">Nhạc Thiếu Nhi</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="subcol menu-col-1">
                        <div class="title-menu"><a href="the-loai-album/US-UK/IWZ9Z08O.html" title="Âu Mỹ">Âu Mỹ</a></div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Pop" href="the-loai-album/Pop/IWZ9Z097.html">Pop</a></li>
                                <li><a title="Rock" href="the-loai-album/Rock/IWZ9Z099.html">Rock</a></li>
                                <li><a title="Rap / Hip Hop" href="the-loai-album/Rap-Hip-Hop/IWZ9Z09B.html">Rap / Hip Hop</a></li>
                                <li><a title="Country" href="the-loai-album/Country/IWZ9Z096.html">Country</a></li>
                                <li><a title="Electronic / Dance" href="the-loai-album/Electronic-Dance/IWZ9Z09A.html">Electronic / Dance</a></li>
                                <li><a title="R&amp;B / Soul" href="the-loai-album/R-B-Soul/IWZ9Z09D.html">R&amp;B / Soul</a></li>
                                <li><a title="Audiophile" href="the-loai-album/Audiophile/IWZ9Z0EO.html">Audiophile</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="subcol menu-col-1">
                        <div class="title-menu"><a href="the-loai-album/Kpop/IWZ9Z08W.html" title="Châu Á">Châu Á</a></div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Hàn Quốc" href="the-loai-album/Kpop/IWZ9Z08W.html">Hàn Quốc</a></li>
                                <li><a title="Nhật bản" href="the-loai-album/Viet-Nam/Nhat-Ban/IWZ9Z08Z.html">Nhật Bản</a></li>
                                <li><a title="Hoa Ngữ" href="the-loai-album/Viet-Nam/Hoa-Ngu/IWZ9Z08U.html">Hoa Ngữ</a></li>
                                <li><a title="Thái Lan" href="the-loai-album/Thai-Lan/IWZ9ZIUF.html">Thái Lan</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->

                    <div class="subcol menu-col-1">
                        <div class="title-menu"><a title="Hòa Tấu" href="the-loai-album/Hoa-Tau/IWZ9Z086.html">Hòa Tấu</a></div>
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Classical" href="the-loai-album/Classical/IWZ9Z0BI.html">Classical</a></li>
                                <li><a title="Piano" href="the-loai-album/Piano/IWZ9Z0B0.html">Piano</a></li>
                                <li><a title="Guitar" href="the-loai-album/Guitar/IWZ9Z0A9.html">Guitar</a></li>
                                <li><a title="Violin" href="the-loai-album/Violin/IWZ9Z0BU.html">Violin</a></li>
                                <li><a title="Cello" href="the-loai-album/Cello/IWZ9Z0AD.html">Cello</a></li>
                                <li><a title="Saxophone" href="the-loai-album/Saxophone/IWZ9Z0B7.html">Saxophone</a></li>
                                <li><a title="Nhạc Cụ Dân Tộc" href="the-loai-album/Nhac-Cu-Dan-Toc/IWZ9Z0AA.html">Nhạc Cụ Dân Tộc</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->
                </div>
            </li>
            <li><a id="navbar-genreartist" title="Nghệ Sĩ" href="the-loai-nghe-si">Nghệ Sĩ</a>
                <div class="megamenu submenu menu-col-1">
                    <div class="subcol menu-col-1-narrow">
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Việt Nam" href="the-loai-nghe-si/Viet-Nam/IWZ9Z08I.html">Việt Nam</a></li>
                                <li><a title="Âu Mỹ" href="the-loai-nghe-si/US-UK/IWZ9Z08O.html">Âu Mỹ</a></li>
                                <li><a title="Hàn Quốc" href="the-loai-nghe-si/Kpop/IWZ9Z08W.html">Hàn Quốc</a></li>
                                <li><a title="Nhật Bản" href="the-loai-nghe-si/Nhat-Ban/IWZ9Z08Z.html">Nhật Bản</a></li>
                                <li><a title="Hao Ngữ" href="the-loai-nghe-si/Hoa-Ngu/IWZ9Z08U.html">Hoa Ngữ</a></li>
                                <li><a title="Hòa Tấu" href="the-loai-nghe-si/Hoa-Tau/IWZ9Z086.html">Hòa Tấu</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->
                </div>
            </li>
            <li class="none"><a id="navbar-realtime" title="Bảng Xếp Hạng Real-time" href="zing-chart-real-time">Real-time</a></li>
            <li><a id="navbar-vip" title="Zing MP3 VIP" href="http://mp3.zing.vn/vip?utm_source=WebZingMP3&utm_medium=Main_Menu&utm_campaign=buyVIP" target="_blank">VIP</a>
                <div class="megamenu submenu menu-col-1">
                    <div class="subcol menu-col-1-narrow">
                        <div class="subinner_item">
                            <ul>
                                <li><a title="Mua VIP" href="http://mp3.zing.vn/vip?show_popup=true?utm_source=WebZingMP3&utm_medium=Submenu_buyVIP&utm_campaign=buyVIP" target="_blank">Mua VIP</a></li>
                                <li><a title="Giới thiệu VIP" href="http://mp3.zing.vn/vip?utm_source=WebZingMP3&utm_medium=Submenu_intro&utm_campaign=buyVIP" target="_blank">Giới thiệu VIP</a></li>
                            </ul>
                        </div>
                    </div><!--End .sub-col -->
                </div>
                <div id="imageaidac"></div>
            </li>
            <li class="none">
                <a id="" title="Zing Music Awards" href="https://awards.zing.vn#home_box_01" target="_blank">
                    <image src="style/images/zma-full.png" />
                </a>
             </li>
        </ul><!-- END .main-nav -->
        <a title="Bật quảng cáo" href="#" class="toggle-ads fn-banner-off"><i class="zicon icon-power"></i>Tắt quảng cáo</a>
        <a title="Upload" href="upload/song.html" class="zicon icon-cloud fn-login"></a>
    </div><!-- END .container -->
</nav>
