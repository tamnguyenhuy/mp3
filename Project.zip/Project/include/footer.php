<footer style="margin-bottom: 0;">
    <div class="container">
        <div class="row">
            <div class="col-4 copyright">
                <img src="style/images/icon_zing_mp3_60.png" height="56" width="56" alt="Zing MP3 - Đỉnh Cao Âm Nhạc" />
                <p>&copy; 2015 <span>VNG Corporation</span></p>
                <p>Giấy phép MXH số 314/GP-BTTTT.</p>
            </div>
            <div class="col-5">
                <ul class="link-footer">
                    <li><a title="Giới thiệu" rel="nofollow" href="huong-dan/about">Giới thiệu</a></li>
                    <li><a title="Điều khoản" rel="nofollow" href="huong-dan/terms">Điều khoản</a></li>
                    <li><a title="Quảng cáo" rel="nofollow" href="https://adtima.vn/lien-he?utm_source=zingmp3&utm_medium=footer" target="_blank">Quảng cáo</a></li>
                    <li><a title="FAQs" rel="nofollow" href="//mp3.zing.vn/huong-dan/index.html">FAQs</a></li>
                    <li><a title="Copyright" rel="nofollow" href="huong-dan/copyright">Copyright</a></li>
                    <li><a title="Zing MP3 VIP" href="//mp3.zing.vn/vip">Zing MP3 VIP</a></li>
                    <li><a title="Ứng dụng" href="apps">Ứng dụng</a></li>
                    <li><a title="Góp ý/Báo lỗi" rel="nofollow" href="https://docs.google.com/forms/d/e/1FAIpQLSfXs8U-4aOl9Bct-u457bdJ7ryE-Ucl5a3OmtcZSf-syl_x1Q/viewform" target="_blank">Góp ý</a></li>
                    <li><a title="APIs" rel="nofollow" href="huong-dan/developer">APIs</a></li>
                    <li><a title="Liên hệ" rel="nofollow" href="huong-dan/contact">Liên hệ</a></li>
                </ul>
            </div>
            <div class="col-3">
                <ul class="social-sq">
                    <li class="fb-sq"><a title="Zing MP3 trên Facebook" href="https://www.facebook.com/zingmp3" rel="nofollow" target="_blank"></a></li>
                    <li class="zl-sq"><a title="Zing MP3 trên Zalo" class="fn-showhere" data-box="#snZalo" href="#" rel="nofollow" target="_blank"></a></li>
                    <li class="gp-sq"><a title="Zing MP3 trên Google Plus" href="https://plus.google.com/+zingmp3" rel="publisher" target="_blank"></a></li>
                    <li class="yt-sq"><a title="Zing MP3 trên Youtube" href="https://www.youtube.com/c/zingmp3" rel="nofollow" target="_blank"></a></li>
                </ul>
                <div class="clearfix"></div>                
                <a href="//www.dmca.com/Protection/Status.aspx?ID=62f851ba-0cde-4801-8326-68a6d66bf97a" title="DMCA.com Protection Status" class="dmca-badge"> <img src="Badges/dmca_protected_sml_120n.png?ID=62f851ba-0cde-4801-8326-68a6d66bf97a" alt="DMCA.com Protection Status"></a> <script src="style/js/DMCABadgeHelper.min.js"></script>
                <div class="clearfix"></div>  
                <p class="sw-mobile"><a title="Phiên bản Mobile" href="//m.mp3.zing.vn">Phiên bản Mobile</a></p>
            </div>
        </div>
    </div>
    <a href="#" class="back-to-top" style="display: none;" title="Lên đầu trang"></a>
    <div class="switch-v5 none" style="right: 0px; position: fixed; display: inline; bottom: 0px; z-index: 201;">
        <a id="switch-to-v5" href="https://zingmp3.com/" title="Phiên bản hoàn toàn mới">
            <img src="style/event/switchv5/banner-v5.png">
        </a>
    </div>
</footer>
<div id="playlistBox" class="dropdown none playlistbox fn-boxsong" style="top:100px;left:100px">
    <span class="arr-top"><i></i></span>
    <ul>
        <li><span>Thêm vào Playlist</span></li>
        <div class="section-hidden">
            <div class="fn-list">
                <li class="fn-fav none"><a class="fn-add" data-type="song" data-id="0" title="Yêu Thích" href="#"><i class="icon-heart"></i>Yêu Thích</a></li>
                <li class="fn-item none"><a class="fn-add" data-type="song" data-id="0" title="" href="#"><input type="checkbox" /> <label class="fn-name"></label></a></li>
            </div>
            <li class="line-top fn-btnnew"><a class="fn-showhide" data-show="#playlistBox .fn-new" data-hide="#playlistBox .fn-btnnew" href="#">Tạo Playlist mới</a></li>
            <li class="line-top none fn-new">
                <form class="fn-playlist" action="xhr/user/create-playlist" data-playlist-box="#playlistBox">
                    <p>
                        <input name="name" type="text" placeholder="Tên Playlist" />
                        <input name="item_id" type="hidden" value="" />
                        <span class="close fn-showhide" data-show="#playlistBox .fn-btnnew" data-hide="#playlistBox .fn-new" ></span>
                    </p>
                    <button type="submit" class="button btn-dark-blue small-button">Đồng ý</button>
                </form>
            </li>
        </div><!-- END .section-hidden -->
    </ul>
</div>
       
    </body>    
</html>