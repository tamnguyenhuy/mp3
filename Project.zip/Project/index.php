<?php include 'include/header.php'; ?>
<div id="zone-ads-billboard"><div id="_mp3_adsZoneBillboard" class="_bannerAds"></div></div>
        <div class="wrapper-page"> 
            <div class="wrap-body container">
    <div class="wrap-content">
        <div class="tracking-page-session" data-id="0">
            <div id="feature" class="slide fn-slide-show" data-fade="true" data-autoplay="true" data-arrows="false" data-slides-to-show="1" data-slides-to-scroll="1" data-infinite="true" data-speed="1000" data-custom-nav="#feature .dot">
            </div>
        </div>
        <div class="section">
            <div id="home-realtime-chart" class="realtime-chart">
                <iframe src="embed/zing-chart" name="zing-chart" frameborder="0" width="650" height="280"></iframe>
                <div class="body-rc" id="rtsong"></div>
            </div>
        </div>
        
        <div class="mt20- tracking-page-session" data-id="22">
            <h2 class="title-section mb0">Playlist</h2>
            <p class="description-music-theme ellipsis-2"></p>
<div class="row fn-list">
    
    <div class="album-item col-3 fn-item">
    <a href="album/I-Love-Monday-Various-Artists/ZOUZZ8EF.html#home_musictheme_01" title="I Love Monday! - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_musictheme_01">
        <img src="image/dbd68ac2e5d0254568c221f59f90a04e.jpg" alt="I Love Monday! - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/I-Love-Monday-Various-Artists/ZOUZZ8EF.html#home_musictheme_01" title="I Love Monday! - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_musictheme_01">
                I Love Monday!
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Today-s-Folk-Hits-Various-Artists/ZOE06E00.html#home_musictheme_02" title="Today's Folk Hits - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_musictheme_02">
        <img src="w240h240_jpeg/cover/b/5/3/6/b5360c9708689bda7ccd7788b4e16697.jpg" alt="Today's Folk Hits - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Today-s-Folk-Hits-Various-Artists/ZOE06E00.html#home_musictheme_02" title="Today's Folk Hits - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_musictheme_02">
                Today's Folk Hits
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Nhac-Tre-Hay-Nhat-The-He-8X-Various-Artists/ZOEI0CWF.html#home_musictheme_03" title="Nhạc Trẻ Hay Nhất Thế Hệ 8X - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_musictheme_03">
        <img src="w240h240_jpeg/cover/f/0/e/2/f0e2d0fbc15e12341611dbd91d9dae92.jpg" alt="Nhạc Trẻ Hay Nhất Thế Hệ 8X - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Nhac-Tre-Hay-Nhat-The-He-8X-Various-Artists/ZOEI0CWF.html#home_musictheme_03" title="Nhạc Trẻ Hay Nhất Thế Hệ 8X - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_musictheme_03">
                Nhạc Trẻ Hay Nhất Thế Hệ 8X
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Nhung-Bai-Hat-Hoa-Ngu-Kinh-Dien-Various-Artists/ZOE7D8B7.html#home_musictheme_04" title="Những Bài Hát Hoa Ngữ Kinh Điển - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_musictheme_04">
        <img src="w240h240_jpeg/cover/f/9/3/8/f9382543b2a1a8adc878cbfba55b6724.jpg" alt="Những Bài Hát Hoa Ngữ Kinh Điển - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Nhung-Bai-Hat-Hoa-Ngu-Kinh-Dien-Various-Artists/ZOE7D8B7.html#home_musictheme_04" title="Những Bài Hát Hoa Ngữ Kinh Điển - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_musictheme_04">
                Những Bài Hát Hoa Ngữ Kinh Điển
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Vay-Cuoi-Various-Artists/ZOFUECOI.html#home_musictheme_05" title="Váy Cưới - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_musictheme_05">
        <img src="w240h240_jpeg/cover/8/6/1/5/8615bc71e1d0c36904243d5aa5cf4346.jpg" alt="Váy Cưới - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Vay-Cuoi-Various-Artists/ZOFUECOI.html#home_musictheme_05" title="Váy Cưới - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_musictheme_05">
                Váy Cưới
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Dance-Pop-Various-Artists/ZWZCWZEW.html#home_musictheme_06" title="Dance Pop - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_musictheme_06">
        <img src="w240h240_jpeg/cover/a/1/1/d/a11da87b62ad4e8a53ecfb988a2e97cc.jpg" alt="Dance Pop - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Dance-Pop-Various-Artists/ZWZCWZEW.html#home_musictheme_06" title="Dance Pop - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_musictheme_06">
                Dance Pop
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Monday-Coffee-Various-Artists/ZOUUZ0OO.html#home_musictheme_07" title="Monday Coffee - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_musictheme_07">
        <img src="w240h240_jpeg/cover/f/a/f/9/faf9e9b5711eeaed2e2c3c5964d8116b.jpg" alt="Monday Coffee - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Monday-Coffee-Various-Artists/ZOUUZ0OO.html#home_musictheme_07" title="Monday Coffee - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_musictheme_07">
                Monday Coffee
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Nhac-Han-Co-The-Hot-Various-Artists/ZODWZEI6.html#home_musictheme_08" title="Nhạc Hàn Có Thể Hot - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_musictheme_08">
        <img src="w240h240_jpeg/cover/f/d/9/5/fd95478e6068f380e589c0233224fd61.jpg" alt="Nhạc Hàn Có Thể Hot - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Nhac-Han-Co-The-Hot-Various-Artists/ZODWZEI6.html#home_musictheme_08" title="Nhạc Hàn Có Thể Hot - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_musictheme_08">
                Nhạc Hàn Có Thể Hot
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
</div>










        </div>
          

                           
        
        <div class="mt10- tracking-page-session" data-id="3">
            

<h2 class="title-section">
    <a href="the-loai-video.html#home_videohot_title" title="Video hot">Video hot <i class="icon-arrow"></i></a>
</h2>




<div class="row fn-list">
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/De-Anh-Mot-Minh-Ngo-Kien-Huy-BlackBi/ZW9EC0F8.html#home_videohot_01" title="Để Anh Một Mình - Ngô Kiến Huy, BlackBi" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_01">
        <img src="w240h135_jpeg/thumb_video/4/e/9/b/4e9bf9cf8b1bd38661c8d2e46a477053.jpg" alt="Để Anh Một Mình - Ngô Kiến Huy, BlackBi" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/De-Anh-Mot-Minh-Ngo-Kien-Huy-BlackBi/ZW9EC0F8.html#home_videohot_01" title="Để Anh Một Mình - Ngô Kiến Huy, BlackBi" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_01">
            Để Anh Một Mình
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Ngo-Kien-Huy" title="Ngô Kiến Huy">Ngô Kiến Huy</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/BlackBi" title="BlackBi">BlackBi</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/Thang-Dien-JustaTee-Phuong-Ly/ZW9DFW9A.html#home_videohot_02" title="Thằng Điên - JustaTee, Phương Ly" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_02">
        <img src="w240h135_jpeg/thumb_video/d/9/5/9/d9596f1082e736d59d716010bd2d2fb5.jpg" alt="Thằng Điên - JustaTee, Phương Ly" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/Thang-Dien-JustaTee-Phuong-Ly/ZW9DFW9A.html#home_videohot_02" title="Thằng Điên - JustaTee, Phương Ly" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_02">
            Thằng Điên
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/JustaTee" title="JustaTee">JustaTee</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Phuong-Ly" title="Phương Ly">Phương Ly</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/Mai-Mai-Se-Het-Vao-Ngay-Mai-Andiez/ZW9E6908.html#home_videohot_03" title="Mãi Mãi Sẽ Hết Vào Ngày Mai - Andiez" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_03">
        <img src="w240h135_jpeg/thumb_video/9/a/9/6/9a9692679fd267aa20e312d031994dc4.jpg" alt="Mãi Mãi Sẽ Hết Vào Ngày Mai - Andiez" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/Mai-Mai-Se-Het-Vao-Ngay-Mai-Andiez/ZW9E6908.html#home_videohot_03" title="Mãi Mãi Sẽ Hết Vào Ngày Mai - Andiez" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_03">
            Mãi Mãi Sẽ Hết Vào Ngày Mai
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Andiez" title="Andiez">Andiez</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/Yeu-Don-Phuong-OnlyC-Karik/ZW9E0BC0.html#home_videohot_04" title="Yêu Đơn Phương - OnlyC, Karik" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_04">
        <img src="w240h135_jpeg/thumb_video/a/8/3/6/a83606b0e9477205f940c1a3d975fdef.jpg" alt="Yêu Đơn Phương - OnlyC, Karik" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/Yeu-Don-Phuong-OnlyC-Karik/ZW9E0BC0.html#home_videohot_04" title="Yêu Đơn Phương - OnlyC, Karik" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_04">
            Yêu Đơn Phương
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/OnlyC" title="OnlyC">OnlyC</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Karik" title="Karik">Karik</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/Co-Dau-Xa-Gan-Ai-Phuong/ZW9EZ0I7.html#home_videohot_05" title="Có Đâu Xa Gần - Ái Phương" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_05">
        <img src="w240h135_jpeg/thumb_video/9/2/5/f/925f0b4685c0ffe3277071086cde280d.jpg" alt="Có Đâu Xa Gần - Ái Phương" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/Co-Dau-Xa-Gan-Ai-Phuong/ZW9EZ0I7.html#home_videohot_05" title="Có Đâu Xa Gần - Ái Phương" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_05">
            Có Đâu Xa Gần
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Ai-Phuong" title="Ái Phương">Ái Phương</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/Ban-Hien-Hazard-Clique-Dat-Maniac/ZW9EZOI8.html#home_videohot_06" title="Bạn Hiền - Hazard Clique, Đạt Maniac" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_06">
        <img src="w240h135_jpeg/thumb_video/5/1/8/c/518c03d938d919c0a37f6329fdd6cfc5.jpg" alt="Bạn Hiền - Hazard Clique, Đạt Maniac" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/Ban-Hien-Hazard-Clique-Dat-Maniac/ZW9EZOI8.html#home_videohot_06" title="Bạn Hiền - Hazard Clique, Đạt Maniac" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_06">
            Bạn Hiền
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Hazard-Clique" title="Hazard Clique">Hazard Clique</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Đạt Maniac" title="Đạt Maniac">Đạt Maniac</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/Con-La-Gi-Cua-Nhau-Chau-Khai-Phong/ZW9E79F9.html#home_videohot_07" title="Còn Là Gì Của Nhau - Châu Khải Phong" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_07">
        <img src="w240h135_jpeg/thumb_video/d/4/8/1/d481d6e2fd2783cd8d1d747d7e09bec4.jpg" alt="Còn Là Gì Của Nhau - Châu Khải Phong" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/Con-La-Gi-Cua-Nhau-Chau-Khai-Phong/ZW9E79F9.html#home_videohot_07" title="Còn Là Gì Của Nhau - Châu Khải Phong" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_07">
            Còn Là Gì Của Nhau
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Chau-Khai-Phong" title="Châu Khải Phong">Châu Khải Phong</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/Am-No-Doi-Doi-Doan-Thuy-Trang-BigDaddy/ZW9EWBAZ.html#home_videohot_08" title="Ấm No Đời Đời - Đoàn Thúy Trang, BigDaddy" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_08">
        <img src="w240h135_jpeg/thumb_video/2/3/6/8/23686f724ace6ba801a3f83d826a66eb.jpg" alt="Ấm No Đời Đời - Đoàn Thúy Trang, BigDaddy" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/Am-No-Doi-Doi-Doan-Thuy-Trang-BigDaddy/ZW9EWBAZ.html#home_videohot_08" title="Ấm No Đời Đời - Đoàn Thúy Trang, BigDaddy" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_08">
            Ấm No Đời Đời
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Doan-Thuy-Trang" title="Đoàn Thúy Trang">Đoàn Thúy Trang</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/BigDaddy" title="BigDaddy">BigDaddy</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/BBIBBI-IU/ZW9E0E88.html#home_videohot_09" title="BBIBBI - IU" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_09">
        <img src="w240h135_jpeg/thumb_video/3/f/b/7/3fb7826959e91a641deeafa4135400df.jpg" alt="BBIBBI - IU" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/BBIBBI-IU/ZW9E0E88.html#home_videohot_09" title="BBIBBI - IU" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_09">
            BBIBBI
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/IU" title="IU">IU</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/Tempo-EXO/ZW9ECO88.html#home_videohot_10" title="Tempo - EXO" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_10">
        <img src="w240h135_jpeg/thumb_video/5/c/1/d/5c1d5f6464e3bba5ef7e9ed77e9ae039.jpg" alt="Tempo - EXO" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/Tempo-EXO/ZW9ECO88.html#home_videohot_10" title="Tempo - EXO" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_10">
            Tempo
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/EXO" title="EXO">EXO</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/Imposible-Luis-Fonsi-Ozuna/ZW9EZ0EI.html#home_videohot_11" title="Imposible - Luis Fonsi, Ozuna" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_11">
        <img src="w240h135_jpeg/thumb_video/8/3/4/6/8346d03361e0682f2f0efec08eb855d7.jpg" alt="Imposible - Luis Fonsi, Ozuna" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/Imposible-Luis-Fonsi-Ozuna/ZW9EZ0EI.html#home_videohot_11" title="Imposible - Luis Fonsi, Ozuna" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_11">
            Imposible
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Luis-Fonsi" title="Luis Fonsi">Luis Fonsi</a></h4><span class="ft">, </span>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="video-item col-3 fn-item">
    <a href="video-clip/Hi-Lo-Evanescence-Lindsey-Stirling/ZW9E99BA.html#home_videohot_12" title="Hi-Lo - Evanescence, Lindsey Stirling" class="thumb fn-link _trackLink" tracking="_frombox=#home_videohot_12">
        <img src="w240h135_jpeg/thumb_video/7/e/0/a/7e0aa3b8f98e51ce798c85001377048e.jpg" alt="Hi-Lo - Evanescence, Lindsey Stirling" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <h3 class="title-item ellipsis-2">
        <a href="video-clip/Hi-Lo-Evanescence-Lindsey-Stirling/ZW9E99BA.html#home_videohot_12" title="Hi-Lo - Evanescence, Lindsey Stirling" class="txt-primary fn-title fn-link _trackLink" tracking="#home_videohot_12">
            Hi-Lo
        </a>
    </h3>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Evanescence" title="Evanescence">Evanescence</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info fn-artist"><a href="nghe-si/Lindsey-Stirling" title="Lindsey Stirling">Lindsey Stirling</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
</div>








    

        </div>
             
        
        <div class="mt20- tracking-page-session" data-id="1">
            

<h2 class="title-section">
    <a href="the-loai-album.html#home_albumhot_title" title="Album hot">Album hot <i class="icon-arrow"></i></a>
</h2>




<div class="row fn-list">
    
    <div class="album-item col-3 fn-item">
    <a href="album/Khi-Anh-Ben-Em-Single-Sara-Luu/ZU0ZW0AO.html#home_albumhot_01" title="Khi Anh Bên Em (Single) - Sara Luu" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_01">
        <img src="w240h240_jpeg/cover/5/6/d/4/56d47c51b8bbb3a18a3b942e49b8d207.jpg" alt="Khi Anh Bên Em (Single) - Sara Luu" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Khi-Anh-Ben-Em-Single-Sara-Luu/ZU0ZW0AO.html#home_albumhot_01" title="Khi Anh Bên Em (Single) - Sara Luu" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_01">
                Khi Anh Bên Em (Single)
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="singer-name txt-info fn-artist"><a href="nghe-si/Sara-Luu" title="Nghệ sĩ Sara Luu">Sara Luu</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Nguoi-La-Thoang-Qua-Single-Khoi-My/ZOFZ8IOB.html#home_albumhot_02" title="Người Lạ Thoáng Qua (Single) - Khởi My" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_02">
        <img src="w240h240_jpeg/cover/4/1/8/b/418b2a3ada550ed8a42f363194a12f45.jpg" alt="Người Lạ Thoáng Qua (Single) - Khởi My" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Nguoi-La-Thoang-Qua-Single-Khoi-My/ZOFZ8IOB.html#home_albumhot_02" title="Người Lạ Thoáng Qua (Single) - Khởi My" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_02">
                Người Lạ Thoáng Qua (Single)
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="singer-name txt-info fn-artist"><a href="nghe-si/Khoi-My" title="Nghệ sĩ Khởi My">Khởi My</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Chap-Nhan-Single-Hoa-Minzy/ZU006CDZ.html#home_albumhot_03" title="Chấp Nhận (Single) - Hòa Minzy" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_03">
        <img src="w240h240_jpeg/cover/b/1/f/d/b1fd458008d15ffad79303adbb1a46c1.jpg" alt="Chấp Nhận (Single) - Hòa Minzy" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Chap-Nhan-Single-Hoa-Minzy/ZU006CDZ.html#home_albumhot_03" title="Chấp Nhận (Single) - Hòa Minzy" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_03">
                Chấp Nhận (Single)
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="singer-name txt-info fn-artist"><a href="nghe-si/Hoa-Minzy" title="Nghệ sĩ Hòa Minzy">Hòa Minzy</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Duong-Tinh-Chia-Hai-Single-Vy-Oanh/ZU0ZUUZZ.html#home_albumhot_04" title="Đường Tình Chia Hai (Single) - Vy Oanh" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_04">
        <img src="w240h240_jpeg/cover/7/9/d/3/79d3f3ce6d7120b453dc9b161ec03ba2.jpg" alt="Đường Tình Chia Hai (Single) - Vy Oanh" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Duong-Tinh-Chia-Hai-Single-Vy-Oanh/ZU0ZUUZZ.html#home_albumhot_04" title="Đường Tình Chia Hai (Single) - Vy Oanh" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_04">
                Đường Tình Chia Hai (Single)
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="singer-name txt-info fn-artist"><a href="nghe-si/Vy-Oanh" title="Nghệ sĩ Vy Oanh">Vy Oanh</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Xin-Chao-Da-Lau-Khong-Gap-Single-Vu-Khanh-Duong/ZU07IDZZ.html#home_albumhot_05" title="Xin Chào Đã Lâu Không Gặp (Single) - Vũ Khánh Dương" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_05">
        <img src="w240h240_jpeg/cover/2/8/3/d/283d5f1d5d23b8a5b7bb68aad4e56d8d.jpg" alt="Xin Chào Đã Lâu Không Gặp (Single) - Vũ Khánh Dương" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Xin-Chao-Da-Lau-Khong-Gap-Single-Vu-Khanh-Duong/ZU07IDZZ.html#home_albumhot_05" title="Xin Chào Đã Lâu Không Gặp (Single) - Vũ Khánh Dương" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_05">
                Xin Chào Đã Lâu Không Gặp (Single)
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="singer-name txt-info fn-artist"><a href="nghe-si/Khanh-Duong" title="Nghệ sĩ Vũ Khánh Dương">Vũ Khánh Dương</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Nhung-Bai-Hat-Viet-Co-The-Hit-Various-Artists/ZWZCOBEF.html#home_albumhot_06" title="Những Bài Hát Việt Có Thể Hit - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_06">
        <img src="w240h240_jpeg/cover/4/1/1/a/411a7e3bcbc2b41156450d3ad3c541d1.jpg" alt="Những Bài Hát Việt Có Thể Hit - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Nhung-Bai-Hat-Viet-Co-The-Hit-Various-Artists/ZWZCOBEF.html#home_albumhot_06" title="Những Bài Hát Việt Có Thể Hit - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_06">
                Những Bài Hát Việt Có Thể Hit
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Nhac-Han-Hot-Thang-11-2018-Various-Artists/ZOFWOCCB.html#home_albumhot_07" title="Nhạc Hàn Hot Tháng 11/2018 - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_07">
        <img src="w240h240_jpeg/cover/8/5/9/f/859f536ee9f60f4e99fa0b7479894168.jpg" alt="Nhạc Hàn Hot Tháng 11/2018 - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Nhac-Han-Hot-Thang-11-2018-Various-Artists/ZOFWOCCB.html#home_albumhot_07" title="Nhạc Hàn Hot Tháng 11/2018 - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_07">
                Nhạc Hàn Hot Tháng 11/2018
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Nhac-US-UK-Hom-Nay-Nghe-Gi-Various-Artists/ZWZCOE6C.html#home_albumhot_08" title="Nhạc US-UK Hôm Nay Nghe Gì? - Various Artists" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_08">
        <img src="w240h240_jpeg/cover/2/0/7/8/2078be4a1943973b564c117c1d07e55a.jpg" alt="Nhạc US-UK Hôm Nay Nghe Gì? - Various Artists" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Nhac-US-UK-Hom-Nay-Nghe-Gi-Various-Artists/ZWZCOE6C.html#home_albumhot_08" title="Nhạc US-UK Hôm Nay Nghe Gì? - Various Artists" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_08">
                Nhạc US-UK Hôm Nay Nghe Gì?
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/DON-T-MESS-UP-MY-TEMPO-THE-5TH-ALBUM-EXO/ZU07U8IE.html#home_albumhot_09" title="DON'T MESS UP MY TEMPO – THE 5TH ALBUM - EXO" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_09">
        <img src="w240h240_jpeg/cover/f/3/8/c/f38cc4030c21b2eb6617c8fe1bbcc463.jpg" alt="DON'T MESS UP MY TEMPO – THE 5TH ALBUM - EXO" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/DON-T-MESS-UP-MY-TEMPO-THE-5TH-ALBUM-EXO/ZU07U8IE.html#home_albumhot_09" title="DON'T MESS UP MY TEMPO – THE 5TH ALBUM - EXO" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_09">
                DON'T MESS UP MY TEMPO – THE 5TH ALBUM
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="singer-name txt-info fn-artist"><a href="nghe-si/EXO" title="Nghệ sĩ EXO">EXO</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/COLOR-IZ-EP-IZ-ONE/ZU0IWAIW.html#home_albumhot_10" title="COLOR*IZ (EP) - IZ*ONE" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_10">
        <img src="w240h240_jpeg/cover/5/1/4/4/5144b23bcd89d5f5f5d61cc133c32647.jpg" alt="COLOR*IZ (EP) - IZ*ONE" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/COLOR-IZ-EP-IZ-ONE/ZU0IWAIW.html#home_albumhot_10" title="COLOR*IZ (EP) - IZ*ONE" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_10">
                COLOR*IZ (EP)
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="singer-name txt-info fn-artist"><a href="nghe-si/IZONE" title="Nghệ sĩ IZ*ONE">IZ*ONE</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Bohemian-Rhapsody-OST-Queen/ZOF0UBFE.html#home_albumhot_11" title="Bohemian Rhapsody (OST) - Queen" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_11">
        <img src="w240h240_jpeg/cover/5/0/1/7/5017b622671da3c4b951176838b69a60.jpg" alt="Bohemian Rhapsody (OST) - Queen" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Bohemian-Rhapsody-OST-Queen/ZOF0UBFE.html#home_albumhot_11" title="Bohemian Rhapsody (OST) - Queen" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_11">
                Bohemian Rhapsody (OST)
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="singer-name txt-info fn-artist"><a href="nghe-si/Queen" title="Nghệ sĩ Queen">Queen</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
    <div class="album-item col-3 fn-item">
    <a href="album/Songs-from-Primal-Heart-Reimagined-EP-Kimbra/ZOFZAIDI.html#home_albumhot_12" title="Songs from Primal Heart: Reimagined (EP) - Kimbra" class="thumb fn-link _trackLink" tracking="_frombox=#home_albumhot_12">
        <img src="w240h240_jpeg/cover/1/d/6/5/1d653992720e973238fb1a6c397bd824.jpg" alt="Songs from Primal Heart: Reimagined (EP) - Kimbra" class="img-responsive fn-thumb">
        <span class="icon-circle-play otr"></span>
    </a>
    <div class="des">
        <h3 class="title-item ellipsis-2">
            <a href="album/Songs-from-Primal-Heart-Reimagined-EP-Kimbra/ZOFZAIDI.html#home_albumhot_12" title="Songs from Primal Heart: Reimagined (EP) - Kimbra" class="txt-primary fn-name fn-link _trackLink" tracking="_frombox=#home_albumhot_12">
                Songs from Primal Heart: Reimagined (EP)
            </a>
        </h3>
    </div>
    <div class="inblock fn-artist_list ellipsis">
        
        <h4 class="singer-name txt-info fn-artist"><a href="nghe-si/Kimbra" title="Nghệ sĩ Kimbra">Kimbra</a></h4>
        
    </div>
    <span class=" fn-badge"></span>
</div>
    
</div>










        </div>
                
        <div class="mt20-">
            <div class="row">
                
                <div id="viet-hot-song" class="col-6 col-border-left">
                    <div class="list-item tool-song-hover style2 tracking-page-session" data-id="4">
                        

<h2 class="title-section">
    <a href="chu-de/nhac-viet-hot/IWZ9Z0C8.html#home_hotsong_title" title="Nhạc Việt hot">Nhạc Việt hot <i class="icon-arrow"></i></a>
</h2>

















<ul>
    
    <li id="songhotZW9EC0F8" class="fn-song" data-type="song" data-id="ZW9EC0F8" data-code="kmxHyZHNJvRbCHGtnTFGkntkpzZBREhHs" data-sig="68ed91484fa534f9ce8f3442dda1f916" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_hotsong_01_listen" href="bai-hat/De-Anh-Mot-Minh-Ngo-Kien-Huy-BlackBi/ZW9EC0F8.html#video-clip#home_hotsong_01_listen" title="Bài hát Để Anh Một Mình - ">
        <img width="50" alt="Để Anh Một Mình" src="w94h94_jpeg/cover/c/3/f/1/c3f139f60deebf9def539c230c2138b4.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_hotsong_01_listen" href="bai-hat/De-Anh-Mot-Minh-Ngo-Kien-Huy-BlackBi/ZW9EC0F8.html#video-clip#home_hotsong_01_listen" title="Bài hát Để Anh Một Mình - Ngô Kiến Huy, BlackBi">Để Anh Một Mình</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Ngo-Kien-Huy" title="Ngô Kiến Huy">Ngô Kiến Huy</a></h4><span class="ft">,</span><h4 class=""><a href="nghe-si/BlackBi" title="BlackBi">BlackBi</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9EC0F8" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9EC0F8" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EC0F8" href="bai-hat/De-Anh-Mot-Minh-Ngo-Kien-Huy-BlackBi/ZW9EC0F8.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9EAI76" class="fn-song" data-type="song" data-id="ZW9EAI76" data-code="knJmtkmNcbJzWVlymtbHZnTZpSkVuihGa" data-sig="ffb9e90e000416315fc3f7bf83948c3c" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_hotsong_02_listen" href="bai-hat/Chap-Nhan-Hoa-Minzy/ZW9EAI76.html#video-clip#home_hotsong_02_listen" title="Bài hát Chấp Nhận - ">
        <img width="50" alt="Chấp Nhận" src="w94h94_jpeg/cover/b/1/f/d/b1fd458008d15ffad79303adbb1a46c1.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_hotsong_02_listen" href="bai-hat/Chap-Nhan-Hoa-Minzy/ZW9EAI76.html#video-clip#home_hotsong_02_listen" title="Bài hát Chấp Nhận - Hòa Minzy">Chấp Nhận</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Hoa-Minzy" title="Hòa Minzy">Hòa Minzy</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9EAI76" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9EAI76" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EAI76" href="bai-hat/Chap-Nhan-Hoa-Minzy/ZW9EAI76.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9E8U8W" class="fn-song" data-type="song" data-id="ZW9E8U8W" data-code="kHxHTZGNJFaaLFDtHtbGkHykQzLdEEhnN" data-sig="c4e2d68cda3d2bf4ac135441de3b33b0" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_hotsong_03_listen" href="bai-hat/Nguoi-La-Thoang-Qua-Khoi-My/ZW9E8U8W.html#home_hotsong_03_listen" title="Bài hát Người Lạ Thoáng Qua - ">
        <img width="50" alt="Người Lạ Thoáng Qua" src="w94h94_jpeg/cover/4/1/8/b/418b2a3ada550ed8a42f363194a12f45.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_hotsong_03_listen" href="bai-hat/Nguoi-La-Thoang-Qua-Khoi-My/ZW9E8U8W.html#home_hotsong_03_listen" title="Bài hát Người Lạ Thoáng Qua - Khởi My">Người Lạ Thoáng Qua</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Khoi-My" title="Khởi My">Khởi My</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9E8U8W" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9E8U8W" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E8U8W" href="bai-hat/Nguoi-La-Thoang-Qua-Khoi-My/ZW9E8U8W.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9E79F9" class="fn-song" data-type="song" data-id="ZW9E79F9" data-code="ZmJnyLnsxballFptHTDHLntLQzLViRhGs" data-sig="f1d0ab424d31bfd201a687f638cf2958" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_hotsong_04_listen" href="bai-hat/Con-La-Gi-Cua-Nhau-Chau-Khai-Phong/ZW9E79F9.html#video-clip#home_hotsong_04_listen" title="Bài hát Còn Là Gì Của Nhau - ">
        <img width="50" alt="Còn Là Gì Của Nhau" src="w94h94_jpeg/cover/d/2/9/2/d29240bdc7094fb083293a649b733f3d.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_hotsong_04_listen" href="bai-hat/Con-La-Gi-Cua-Nhau-Chau-Khai-Phong/ZW9E79F9.html#video-clip#home_hotsong_04_listen" title="Bài hát Còn Là Gì Của Nhau - Châu Khải Phong">Còn Là Gì Của Nhau</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Chau-Khai-Phong" title="Châu Khải Phong">Châu Khải Phong</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9E79F9" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9E79F9" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E79F9" href="bai-hat/Con-La-Gi-Cua-Nhau-Chau-Khai-Phong/ZW9E79F9.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9E7W88" class="fn-song" data-type="song" data-id="ZW9E7W88" data-code="kHJmyLmacDsbWDmtGtFHLHTkQALdiigHa" data-sig="f44d06b8880c113f344e28b497d7528c" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_hotsong_05_listen" href="bai-hat/Tinh-Ban-Tu-Dua-Tuan-Hung/ZW9E7W88.html#home_hotsong_05_listen" title="Bài hát Tình Bạn - ">
        <img width="50" alt="Tình Bạn" src="w94h94_jpeg/cover/2/a/b/4/2ab4a863bac99a5d5a6eaf86d87cfb35.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_hotsong_05_listen" href="bai-hat/Tinh-Ban-Tu-Dua-Tuan-Hung/ZW9E7W88.html#home_hotsong_05_listen" title="Bài hát Tình Bạn - Tú Dưa, Tuấn Hưng">Tình Bạn</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Tu-Dua.IWZADFC9" title="Tú Dưa">Tú Dưa</a></h4><span class="ft">,</span><h4 class=""><a href="nghe-si/Tuan-Hung" title="Tuấn Hưng">Tuấn Hưng</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9E7W88" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9E7W88" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E7W88" href="bai-hat/Tinh-Ban-Tu-Dua-Tuan-Hung/ZW9E7W88.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9E70OC" class="fn-song" data-type="song" data-id="ZW9E70OC" data-code="LmxGTZmaxDsZudbynybGLnyLpzLdEuhHa" data-sig="a7140bedd25ccb0e2de46302ac7291a5" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_hotsong_06_listen" href="bai-hat/Em-Ngu-Chua-Trinh-Thang-Binh-OSAD/ZW9E70OC.html#video-clip#home_hotsong_06_listen" title="Bài hát Em Ngủ Chưa? - ">
        <img width="50" alt="Em Ngủ Chưa?" src="w94h94_jpeg/cover/c/4/1/e/c41e14bc887ba823d21fd675da19416d.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_hotsong_06_listen" href="bai-hat/Em-Ngu-Chua-Trinh-Thang-Binh-OSAD/ZW9E70OC.html#video-clip#home_hotsong_06_listen" title="Bài hát Em Ngủ Chưa? - Trịnh Thăng Bình, OSAD">Em Ngủ Chưa?</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Trinh-Thang-Binh" title="Trịnh Thăng Bình">Trịnh Thăng Bình</a></h4><span class="ft">,</span><h4 class=""><a href="nghe-si/OSAD" title="OSAD">OSAD</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9E70OC" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9E70OC" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E70OC" href="bai-hat/Em-Ngu-Chua-Trinh-Thang-Binh-OSAD/ZW9E70OC.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9E6908" class="fn-song" data-type="song" data-id="ZW9E6908" data-code="LmJGtZnacbaHncJtmtFmLmyLWzLdiihHN" data-sig="9b58b3232fb7e34e7ecc87041b8dac31" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_hotsong_07_listen" href="bai-hat/Mai-Mai-Se-Het-Vao-Ngay-Mai-Andiez/ZW9E6908.html#video-clip#home_hotsong_07_listen" title="Bài hát Mãi Mãi Sẽ Hết Vào Ngày Mai - ">
        <img width="50" alt="Mãi Mãi Sẽ Hết Vào Ngày Mai" src="w94h94_jpeg/cover/1/3/d/2/13d24973ef7ce6f878ac8454d76956af.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_hotsong_07_listen" href="bai-hat/Mai-Mai-Se-Het-Vao-Ngay-Mai-Andiez/ZW9E6908.html#video-clip#home_hotsong_07_listen" title="Bài hát Mãi Mãi Sẽ Hết Vào Ngày Mai - Andiez">Mãi Mãi Sẽ Hết Vào Ngày Mai</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Andiez" title="Andiez">Andiez</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9E6908" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9E6908" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E6908" href="bai-hat/Mai-Mai-Se-Het-Vao-Ngay-Mai-Andiez/ZW9E6908.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9E6FFW" class="fn-song" data-type="song" data-id="ZW9E6FFW" data-code="knJmyknNJDaZJpJynybHknykplLdRiXGa" data-sig="ca1c5fca1bf05fd613b0ba613ef0aa7b" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_hotsong_08_listen" href="bai-hat/Khau-Lai-Trai-Tim-Em-Ha-Anh/ZW9E6FFW.html#home_hotsong_08_listen" title="Bài hát Khâu Lại Trái Tim Em - ">
        <img width="50" alt="Khâu Lại Trái Tim Em" src="w94h94_jpeg/cover/1/d/d/e/1ddedf9c0afe45e89f501d338545fe07.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_hotsong_08_listen" href="bai-hat/Khau-Lai-Trai-Tim-Em-Ha-Anh/ZW9E6FFW.html#home_hotsong_08_listen" title="Bài hát Khâu Lại Trái Tim Em - Hà Anh">Khâu Lại Trái Tim Em</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Ha-Anh" title="Hà Anh">Hà Anh</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9E6FFW" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9E6FFW" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E6FFW" href="bai-hat/Khau-Lai-Trai-Tim-Em-Ha-Anh/ZW9E6FFW.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9EZ0I7" class="fn-song" data-type="song" data-id="ZW9EZ0I7" data-code="LGxHyLmNxDXdNnBtntbHZmtkQALdiECmN" data-sig="eb1a38feb00456acd5908c136f349669" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_hotsong_09_listen" href="bai-hat/Co-Dau-Xa-Gan-Ai-Phuong/ZW9EZ0I7.html#video-clip#home_hotsong_09_listen" title="Bài hát Có Đâu Xa Gần - ">
        <img width="50" alt="Có Đâu Xa Gần" src="w94h94_jpeg/cover/9/2/e/a/92eaf5a238e08eb4c5175bbc38b8b82b.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_hotsong_09_listen" href="bai-hat/Co-Dau-Xa-Gan-Ai-Phuong/ZW9EZ0I7.html#video-clip#home_hotsong_09_listen" title="Bài hát Có Đâu Xa Gần - Ái Phương">Có Đâu Xa Gần</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Ai-Phuong" title="Ái Phương">Ái Phương</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9EZ0I7" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9EZ0I7" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EZ0I7" href="bai-hat/Co-Dau-Xa-Gan-Ai-Phuong/ZW9EZ0I7.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9EO8WO" class="fn-song" data-type="song" data-id="ZW9EO8WO" data-code="kGJmykHacbWNpaktGybmkHyLQSLBiiCms" data-sig="d650b9a9fcc6d3b5f3eee8ad1c122989" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_hotsong_10_listen" href="bai-hat/Dung-Noi-Toi-Dien-Hien-Ho/ZW9EO8WO.html#video-clip#home_hotsong_10_listen" title="Bài hát Đừng Nói Tôi Điên - ">
        <img width="50" alt="Đừng Nói Tôi Điên" src="w94h94_jpeg/cover/1/2/b/8/12b88922410ad579dce22031b12c05ca.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_hotsong_10_listen" href="bai-hat/Dung-Noi-Toi-Dien-Hien-Ho/ZW9EO8WO.html#video-clip#home_hotsong_10_listen" title="Bài hát Đừng Nói Tôi Điên - Hiền Hồ">Đừng Nói Tôi Điên</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Hien-Ho" title="Hiền Hồ">Hiền Hồ</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9EO8WO" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9EO8WO" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EO8WO" href="bai-hat/Dung-Noi-Toi-Dien-Hien-Ho/ZW9EO8WO.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
</ul>




    

                    </div>
                </div>
                
                
                <div id="viet-new-song" class="col-6 col-border-left">
                    <div class="list-item tool-song-hover style2 tracking-page-session" data-id="5">
                        

<h2 class="title-section">
    <a href="chu-de/nhac-viet-moi/IWZ9Z0ED.html#home_newsong_title" title="Nhạc Việt mới">Nhạc Việt mới <i class="icon-arrow"></i></a>
</h2>

















<ul>
    
    <li id="songhotZW9EB6U8" class="fn-song" data-type="song" data-id="ZW9EB6U8" data-code="ZGxHykHNcbcichzTGyDnLmtLpzkduRhnN" data-sig="166005ce728dca36d4d2d2861a482289" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_newsong_01_listen" href="bai-hat/Khi-Anh-Ben-Em-Sara-Luu/ZW9EB6U8.html#home_newsong_01_listen" title="Bài hát Khi Anh Bên Em - ">
        <img width="50" alt="Khi Anh Bên Em" src="w94h94_jpeg/cover/5/6/d/4/56d47c51b8bbb3a18a3b942e49b8d207.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_newsong_01_listen" href="bai-hat/Khi-Anh-Ben-Em-Sara-Luu/ZW9EB6U8.html#home_newsong_01_listen" title="Bài hát Khi Anh Bên Em - Sara Luu">Khi Anh Bên Em</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Sara-Luu" title="Sara Luu">Sara Luu</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9EB6U8" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9EB6U8" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EB6U8" href="bai-hat/Khi-Anh-Ben-Em-Sara-Luu/ZW9EB6U8.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9EB6U9" class="fn-song" data-type="song" data-id="ZW9EB6U9" data-code="ZmJHtkHscbcucCptnyFHLmyLpSLdEEXGs" data-sig="b880dd4dfe9eea7816de9025313b2c1c" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_newsong_02_listen" href="bai-hat/Duong-Tinh-Chia-Hai-Vy-Oanh/ZW9EB6U9.html#home_newsong_02_listen" title="Bài hát Đường Tình Chia Hai - ">
        <img width="50" alt="Đường Tình Chia Hai" src="w94h94_jpeg/cover/7/5/4/1/7541c6fca87e04dc67e054501c10d6ec.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_newsong_02_listen" href="bai-hat/Duong-Tinh-Chia-Hai-Vy-Oanh/ZW9EB6U9.html#home_newsong_02_listen" title="Bài hát Đường Tình Chia Hai - Vy Oanh">Đường Tình Chia Hai</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Vy-Oanh" title="Vy Oanh">Vy Oanh</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9EB6U9" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9EB6U9" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EB6U9" href="bai-hat/Duong-Tinh-Chia-Hai-Vy-Oanh/ZW9EB6U9.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9E87F7" class="fn-song" data-type="song" data-id="ZW9E87F7" data-code="ZHJHyZmsxbsxmmstGTbHZntZpSZViRCna" data-sig="ede505677d4301984082403a09857cf8" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_newsong_03_listen" href="bai-hat/The-Gioi-Tuyet-Voi-Duong-Edward/ZW9E87F7.html#home_newsong_03_listen" title="Bài hát Thế Giới Tuyệt Vời - ">
        <img width="50" alt="Thế Giới Tuyệt Vời" src="w94h94_jpeg/cover/e/b/4/c/eb4c5f593bf3883a8e08b9977d0688e3.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_newsong_03_listen" href="bai-hat/The-Gioi-Tuyet-Voi-Duong-Edward/ZW9E87F7.html#home_newsong_03_listen" title="Bài hát Thế Giới Tuyệt Vời - Dương Edward">Thế Giới Tuyệt Vời</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Duong-Edward" title="Dương Edward">Dương Edward</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9E87F7" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9E87F7" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E87F7" href="bai-hat/The-Gioi-Tuyet-Voi-Duong-Edward/ZW9E87F7.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9E9O66" class="fn-song" data-type="song" data-id="ZW9E9O66" data-code="LHJHyZHacbJHRVSyntbnLHtkWlZBuEhGN" data-sig="f4dedbc63b08d0e25b85001c59605216" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_newsong_04_listen" href="bai-hat/Mashup-Oi-Tinh-Yeu-Ok-Chia-Tay-Vinh-Thuyen-Kim/ZW9E9O66.html#video-clip#home_newsong_04_listen" title="Bài hát Mashup Ôi Tình Yêu - Ok Chia Tay - ">
        <img width="50" alt="Mashup Ôi Tình Yêu - Ok Chia Tay" src="w94h94_jpeg/cover/f/5/2/1/f5218339da7931f8d3dbe52b8d76ec40.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_newsong_04_listen" href="bai-hat/Mashup-Oi-Tinh-Yeu-Ok-Chia-Tay-Vinh-Thuyen-Kim/ZW9E9O66.html#video-clip#home_newsong_04_listen" title="Bài hát Mashup Ôi Tình Yêu - Ok Chia Tay - Vĩnh Thuyên Kim">Mashup Ôi Tình Yêu - Ok Chia Tay</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Vinh-Thuyen-Kim" title="Vĩnh Thuyên Kim">Vĩnh Thuyên Kim</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9E9O66" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9E9O66" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E9O66" href="bai-hat/Mashup-Oi-Tinh-Yeu-Ok-Chia-Tay-Vinh-Thuyen-Kim/ZW9E9O66.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9E86WE" class="fn-song" data-type="song" data-id="ZW9E86WE" data-code="LHcHTLHNcDssWpmymtvnkmtZpzZBRuCHa" data-sig="4cf30969e5dc3fe2969f82dc984e86c7" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_newsong_05_listen" href="bai-hat/Mua-Nho-Anh-Machiot-Chee/ZW9E86WE.html#home_newsong_05_listen" title="Bài hát Mưa Nhớ Anh - ">
        <img width="50" alt="Mưa Nhớ Anh" src="w94h94_jpeg/cover/9/e/9/c/9e9ca2bfeb4fb8501492adf046a4ed03.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_newsong_05_listen" href="bai-hat/Mua-Nho-Anh-Machiot-Chee/ZW9E86WE.html#home_newsong_05_listen" title="Bài hát Mưa Nhớ Anh - Machiot, Chee">Mưa Nhớ Anh</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Machiot" title="Machiot">Machiot</a></h4><span class="ft">,</span><h4 class=""><a href="nghe-si/Chee" title="Chee">Chee</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9E86WE" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9E86WE" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E86WE" href="bai-hat/Mua-Nho-Anh-Machiot-Chee/ZW9E86WE.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9EUAAC" class="fn-song" data-type="song" data-id="ZW9EUAAC" data-code="LGxnyLnscbhFdZgtmtbnZHykQSkdiihHN" data-sig="bf9237afe1340b12d8b9727a27f380a0" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_newsong_06_listen" href="bai-hat/Yeu-Xa-Song-Luan/ZW9EUAAC.html#home_newsong_06_listen" title="Bài hát Yêu Xa - ">
        <img width="50" alt="Yêu Xa" src="w94h94_jpeg/cover/8/3/1/4/831433dce804b1af0aaef93ed86bb4eb.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_newsong_06_listen" href="bai-hat/Yeu-Xa-Song-Luan/ZW9EUAAC.html#home_newsong_06_listen" title="Bài hát Yêu Xa - Song Luân">Yêu Xa</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Song-Luan" title="Song Luân">Song Luân</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9EUAAC" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9EUAAC" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EUAAC" href="bai-hat/Yeu-Xa-Song-Luan/ZW9EUAAC.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9EUBA9" class="fn-song" data-type="song" data-id="ZW9EUBA9" data-code="ZmxmtZHaJFCvWCiyHyFnLmTZQSLdRihGs" data-sig="345f412bc766156c55e383619802cf87" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_newsong_07_listen" href="bai-hat/Co-Don-Minh-Toi-Sara-Luu-Ivone/ZW9EUBA9.html#home_newsong_07_listen" title="Bài hát Cô Đơn Mình Tôi - ">
        <img width="50" alt="Cô Đơn Mình Tôi" src="w94h94_jpeg/cover/e/4/9/9/e4990fc7abe0510c52fd4954d21520f7.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_newsong_07_listen" href="bai-hat/Co-Don-Minh-Toi-Sara-Luu-Ivone/ZW9EUBA9.html#home_newsong_07_listen" title="Bài hát Cô Đơn Mình Tôi - Sara Luu, Ivone">Cô Đơn Mình Tôi</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Sara-Luu" title="Sara Luu">Sara Luu</a></h4><span class="ft">,</span><h4 class=""><a href="nghe-si/Ivone" title="Ivone">Ivone</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9EUBA9" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9EUBA9" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EUBA9" href="bai-hat/Co-Don-Minh-Toi-Sara-Luu-Ivone/ZW9EUBA9.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9EZOWO" class="fn-song" data-type="song" data-id="ZW9EZOWO" data-code="LHcmyLmNcvhSlcByntFmknTLWzLVEiXHs" data-sig="ea1347313d08760205412d32833c989f" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_newsong_08_listen" href="bai-hat/Mot-Ngay-Nhu-Hom-Nay-Hai-Sam-Khoa-Vu/ZW9EZOWO.html#home_newsong_08_listen" title="Bài hát Một Ngày Như Hôm Nay - ">
        <img width="50" alt="Một Ngày Như Hôm Nay" src="w94h94_jpeg/cover/a/d/2/4/ad246fd59aed28b47391d77fbe335814.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_newsong_08_listen" href="bai-hat/Mot-Ngay-Nhu-Hom-Nay-Hai-Sam-Khoa-Vu/ZW9EZOWO.html#home_newsong_08_listen" title="Bài hát Một Ngày Như Hôm Nay - Hải Sâm, Khoa Vũ">Một Ngày Như Hôm Nay</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Hai-Sam" title="Hải Sâm">Hải Sâm</a></h4><span class="ft">,</span><h4 class=""><a href="nghe-si/Khoa-Vu" title="Khoa Vũ">Khoa Vũ</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9EZOWO" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9EZOWO" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EZOWO" href="bai-hat/Mot-Ngay-Nhu-Hom-Nay-Hai-Sam-Khoa-Vu/ZW9EZOWO.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9EZOI8" class="fn-song" data-type="song" data-id="ZW9EZOI8" data-code="LHJHyZmsJbXzlaFymybHkmTkWzkdERCHN" data-sig="d4e5c54cff2f1dc92d26fb454ee3e27a" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_newsong_09_listen" href="bai-hat/Ban-Hien-Hazard-Clique-Dat-Maniac/ZW9EZOI8.html#video-clip#home_newsong_09_listen" title="Bài hát Bạn Hiền - ">
        <img width="50" alt="Bạn Hiền" src="w94h94_jpeg/cover/2/3/e/f/23efe8cbc495268504322e217811ac65.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_newsong_09_listen" href="bai-hat/Ban-Hien-Hazard-Clique-Dat-Maniac/ZW9EZOI8.html#video-clip#home_newsong_09_listen" title="Bài hát Bạn Hiền - Hazard Clique, Đạt Maniac">Bạn Hiền</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Hazard-Clique" title="Hazard Clique">Hazard Clique</a></h4><span class="ft">,</span><h4 class=""><a href="nghe-si/Đạt Maniac" title="Đạt Maniac">Đạt Maniac</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9EZOI8" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9EZOI8" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9EZOI8" href="bai-hat/Ban-Hien-Hazard-Clique-Dat-Maniac/ZW9EZOI8.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
    <li id="songhotZW9E9AOD" class="fn-song" data-type="song" data-id="ZW9E9AOD" data-code="ZGxmtkHNJvxFhcWyHtbnknyLQAkdRRXms" data-sig="35d247a673a5676529366677441f9e46" data-active="show-tool">
    <a class="thumb pull-left _trackLink track-log" tracking="_frombox=#home_newsong_10_listen" href="bai-hat/Muon-Co-Anh-I-A-I-A-Tia-Hai-Chau/ZW9E9AOD.html#video-clip#home_newsong_10_listen" title="Bài hát Muốn Có Anh (I À Í A) - ">
        <img width="50" alt="Muốn Có Anh (I À Í A)" src="w94h94_jpeg/cover/1/d/b/8/1db85ae08d25415e8aa5abb93a294134.jpg" />
        <span class="icon-circle-play icon-small"></span>
    </a>
    <h3 class="txt-primary">
        <a class="ellipsis list-item-width _trackLink track-log" tracking="_frombox=#home_newsong_10_listen" href="bai-hat/Muon-Co-Anh-I-A-I-A-Tia-Hai-Chau/ZW9E9AOD.html#video-clip#home_newsong_10_listen" title="Bài hát Muốn Có Anh (I À Í A) - Tia Hải Châu">Muốn Có Anh (I À Í A)</a>
    </h3>
    <span class="inblock ellipsis">
        <h4 class=""><a href="nghe-si/Tia-Hai-Chau" title="Tia Hải Châu">Tia Hải Châu</a></h4>      
    </span>
    <div class="tool-song">
        <div class="i25 i-small download"><a title="Download" class="fn-dlsong _trackLink" tracking="_frombox=home_hotsong__download" data-item="#songhotZW9E9AOD" href="#"></a></div>
        <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto _trackLink" tracking="_frombox=home_hotsong__add" data-item="#songhotZW9E9AOD" href="#"></a></div>
        <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#songZW9E9AOD" href="bai-hat/Muon-Co-Anh-I-A-I-A-Tia-Hai-Chau/ZW9E9AOD.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
    </div>
</li>
    
</ul>




    

                    </div>
                </div>
                
            </div>
        </div> 
        <div id="block-artist-hot"></div>
    </div>
    <div class="wrap-sidebar">
        <div id="discover-playlist" class=""></div>
        
        <div id="topic-hot" class="widget widget-cate">
            <h2 class="title-section fs18">Chủ đề hot</h2>
            

<div class="part-cate-inside">
    <ul class="clearfix">
        
        <li>
    <a href="chu-de/nhac-hot/IWZ9Z0C8.html#home_chude_01" title="Nhạc Hot" class="_trackLink" tracking="_frombox=#home_chude_01">
        
        <img src="image/d1c2738deec7efd1942a3027a1c436b0_1499828277.jpg" class="img-responsive" alt="Nhạc Hot" />
        
        <span class="des">
            <span class="sum-pci">Zing MP3 sẽ mang đến các ca khúc đang HOT nhất hiện nay trên thế giới</span>
        </span>
    </a>
</li>
        
        <li>
    <a href="chu-de/The-Gioi-V-Pop/IWZ99FII.html#home_chude_02" title="Thế Giới V-Pop" class="_trackLink" tracking="_frombox=#home_chude_02">
        
        <img src="image/85d991c244de59021815a700d7a24d25.jpg" class="img-responsive" alt="Thế Giới V-Pop" />
        
        <span class="des">
            <span class="sum-pci">Tổng hợp những giọng ca xuất sắc đại diện cho các thế hệ ca sĩ qua từng cột mốc đánh dấu sự trưởng thành của nền âm nhạc Việt Nam</span>
        </span>
    </a>
</li>
        
        <li>
    <a href="chu-de/zing-collection/IWZ9Z0EB.html#home_chude_03" title="Zing Collection" class="_trackLink" tracking="_frombox=#home_chude_03">
        
        <img src="image/55a619ea7a0c39489ddf1f0430e01056.jpg" class="img-responsive" alt="Zing Collection" />
        
        <span class="des">
            <span class="sum-pci">Các playlist đặc biệt từ Zing MP3 thực hiện với nhiều màu sắc âm nhạc đa dạng.</span>
        </span>
    </a>
</li>
        
        <li>
    <a href="chu-de/K-Pop-HIT/IWZ9ZI9I.html#home_chude_04" title="K-Pop HIT" class="_trackLink" tracking="_frombox=#home_chude_04">
        
        <img src="image/d28ef98a1827d390296f2759555cc606_1499827932.jpg" class="img-responsive" alt="K-Pop HIT" />
        
        <span class="des">
            <span class="sum-pci">K-Pop HIT, nơi dành riêng cho các tín đồ yêu thích âm nhạc K-Pop</span>
        </span>
    </a>
</li>
        
        <li>
    <a href="chu-de/EDM/IWZ9Z0DU.html#home_chude_05" title="EDM" class="_trackLink" tracking="_frombox=#home_chude_05">
        
        <img src="image/95488ad8d45bd69ef83e9403c4114375_1499827707.jpg" class="img-responsive" alt="EDM" />
        
        <span class="des">
            <span class="sum-pci">Thả mình vào không gian âm nhạc của những DJ, Producer nổi tiếng cùng EDM.</span>
        </span>
    </a>
</li>
        
    </ul>
</div>



    
            <a class="view-more _trackLink" href="chu-de#home_chude_browser" tracking="_frombox=home_chude_browser">Xem thêm Chủ Đề khác</a>
            <div class="clearfix"></div>
        </div>
                 
        
<div id="widget-chart-song" class="widget widget-tab">
    <h2 class="title-section sz-title-sm fs18">
        <a class="fn-detail_link" href="zing-chart-tuan/Bai-hat-Viet-Nam/IWZ9Z08I.html">#ZingChart Tuần - Bài Hát<i class="icon-arrow"></i></a>
        <a title="Nghe tất cả" href="#" class="icon-play-all pull-right fn-play_link"></a>
    </h2>
    <ul class="tab-nav">
        
        <li id="chart_tab_songIWZ9Z08I"><a title="BXH Bài hát Việt Nam" class="active fn-switch-tab" data-show="#chart_songIWZ9Z08I" data-type="song" data-link="zing-chart-tuan/Bai-hat-Viet-Nam/IWZ9Z08I.html" data-playlistLink="album/zingchart-Tuan-43-2018/ZOFEOU7B.html" data-hide=".chart-song">Việt Nam</a></li>
        
        <li id="chart_tab_songIWZ9Z0BW"><a title="BXH Bài hát US-UK" class=" fn-switch-tab" data-show="#chart_songIWZ9Z0BW" data-type="song" data-link="zing-chart-tuan/Bai-hat-US-UK/IWZ9Z0BW.html" data-playlistLink="album/Bang-Xep-Hang-Bai-Hat-Au-My-Tuan-43-2018/ZU0ZIEDA.html" data-hide=".chart-song">US-UK</a></li>
        
        <li id="chart_tab_songIWZ9Z0BO"><a title="BXH Bài hát KPop" class=" fn-switch-tab" data-show="#chart_songIWZ9Z0BO" data-type="song" data-link="zing-chart-tuan/Bai-hat-KPop/IWZ9Z0BO.html" data-playlistLink="album/Bang-Xep-Hang-Bai-Hat-Han-Quoc-Tuan-44-2018/ZU0C6068.html" data-hide=".chart-song">K-Pop</a></li>
            
    </ul>
    
    <div id="chart_songIWZ9Z08I" class="tab-pane widget-song-countdown chart-song ">
        <div class="widget-content no-padding no-border tracking-page-session" data-id="6">
            












<ul class="fn-list">
    
    <li class="fn-item fn-first first-item fn-song" data-type="song" data-id="ZW9DFW9A" data-code="LnxHTLmsxFdisamymyFHZntLWzkBRihms"  data-active="show-tool" id="chartitemsongZW9DFW9A">
    
    <a class="zthumb fn-link" href="bai-hat/Thang-Dien-JustaTee-Phuong-Ly/ZW9DFW9A.html#video-clip#home_chartsongvietnam_01">
        <img class="fn-thumb" src="banner/8/5/3/d/853daa66d5f6923fc7a8181bde296420.jpg" alt="Bài hát Thằng Điên - JustaTee, Phương Ly">
    </a>
    
    <div class="w260 des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Thang-Dien-JustaTee-Phuong-Ly/ZW9DFW9A.html#video-clip#home_chartsongvietnam_01" title="Thằng Điên" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongvietnam_01">Thằng Điên</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/JustaTee" title="Nghệ sĩ JustaTee">JustaTee</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Phuong-Ly" title="Nghệ sĩ Phương Ly">Phương Ly</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DFW9A" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DFW9A" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DFW9A" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DFW9A" href="bai-hat/Thang-Dien-JustaTee-Phuong-Ly/ZW9DFW9A.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    <span class="item-mask"></span>
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DFW8O" data-code="LHxnyLmNJbdiaANyGtvHZGyLWlLdiECnN"  data-active="show-tool" id="chartitemsongZW9DFW8O">
    
    <div class="w260 ">
        <span class="rank fn-order">02</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Hongkong1-Official-Version-Nguyen-Trong-Tai-San-Ji-Double-X/ZW9DFW8O.html#video-clip#home_chartsongvietnam_02" title="Hongkong1 (Official Version)" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongvietnam_02">Hongkong1 (Official Version)</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Nguyen-Trong-Tai" title="Nghệ sĩ Nguyễn Trọng Tài">Nguyễn Trọng Tài</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Sang-Vo" title="Nghệ sĩ San Ji">San Ji</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Double-X" title="Nghệ sĩ Double X">Double X</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DFW8O" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DFW8O" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DFW8O" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DFW8O" href="bai-hat/Hongkong1-Official-Version-Nguyen-Trong-Tai-San-Ji-Double-X/ZW9DFW8O.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DC99A" data-code="kncmtZnNcvvEDNzymyvHkmyLWzkVEihGN"  data-active="show-tool" id="chartitemsongZW9DC99A">
    
    <div class="w260 ">
        <span class="rank fn-order">03</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Vo-Tinh-Xesi-Hoaprox/ZW9DC99A.html#home_chartsongvietnam_03" title="Vô Tình" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongvietnam_03">Vô Tình</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Xesi" title="Nghệ sĩ Xesi">Xesi</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Hoaprox" title="Nghệ sĩ Hoaprox">Hoaprox</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DC99A" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DC99A" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DC99A" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DC99A" href="bai-hat/Vo-Tinh-Xesi-Hoaprox/ZW9DC99A.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DCEE6" data-code="LmxHykmscFBGCdnynTDHkmTZQAZVRigmN"  data-active="show-tool" id="chartitemsongZW9DCEE6">
    
    <div class="w260 ">
        <span class="rank fn-order">04</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Cang-Niu-Giu-Cang-De-Mat-Mr-Siro/ZW9DCEE6.html#video-clip#home_chartsongvietnam_04" title="Càng Níu Giữ Càng Dễ Mất" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongvietnam_04">Càng Níu Giữ Càng Dễ Mất</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Mr-Siro" title="Nghệ sĩ Mr Siro">Mr Siro</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DCEE6" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DCEE6" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DCEE6" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DCEE6" href="bai-hat/Cang-Niu-Giu-Cang-De-Mat-Mr-Siro/ZW9DCEE6.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DAB0O" data-code="LHJGykHscFbLSzdymtDHkmtZplLdiihms"  data-active="show-tool" id="chartitemsongZW9DAB0O">
    
    <div class="w260 ">
        <span class="rank fn-order">05</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Chuyen-Tinh-Toi-Kay-Tran-Nguyen-Khoa-Kass/ZW9DAB0O.html#video-clip#home_chartsongvietnam_05" title="Chuyện Tình Tôi" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongvietnam_05">Chuyện Tình Tôi</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Kay-Tran" title="Nghệ sĩ Kay Trần">Kay Trần</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/nguyenkhoa" title="Nghệ sĩ Nguyễn Khoa">Nguyễn Khoa</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Kass" title="Nghệ sĩ Kass">Kass</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DAB0O" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DAB0O" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DAB0O" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DAB0O" href="bai-hat/Chuyen-Tinh-Toi-Kay-Tran-Nguyen-Khoa-Kass/ZW9DAB0O.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9EO8WO" data-code="kmxmyZmNcvpNpsktHyFmkmykplZVRRgns"  data-active="show-tool" id="chartitemsongZW9EO8WO">
    
    <div class="w260 ">
        <span class="rank fn-order">06</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Dung-Noi-Toi-Dien-Hien-Ho/ZW9EO8WO.html#video-clip#home_chartsongvietnam_06" title="Đừng Nói Tôi Điên" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongvietnam_06">Đừng Nói Tôi Điên</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Hien-Ho" title="Nghệ sĩ Hiền Hồ">Hiền Hồ</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9EO8WO" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9EO8WO" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9EO8WO" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9EO8WO" href="bai-hat/Dung-Noi-Toi-Dien-Hien-Ho/ZW9EO8WO.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DODFI" data-code="kmxGykGaJLRdpFkymyvnLHtkQAZBREhmN"  data-active="show-tool" id="chartitemsongZW9DODFI">
    
    <div class="w260 ">
        <span class="rank fn-order">07</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Tan-Cung-Noi-Nho-Will/ZW9DODFI.html#video-clip#home_chartsongvietnam_07" title="Tận Cùng Nỗi Nhớ" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongvietnam_07">Tận Cùng Nỗi Nhớ</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Will-365DaBand" title="Nghệ sĩ Will">Will</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DODFI" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DODFI" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DODFI" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DODFI" href="bai-hat/Tan-Cung-Noi-Nho-Will/ZW9DODFI.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DB8D6" data-code="kGcmyLHscFbAuxbyntDHZmTLWzLBRRgHa"  data-active="show-tool" id="chartitemsongZW9DB8D6">
    
    <div class="w260 ">
        <span class="rank fn-order">08</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Con-Yeu-Dau-Ai-Roi-Di-Duc-Phuc/ZW9DB8D6.html#video-clip#home_chartsongvietnam_08" title="Còn Yêu, Đâu Ai Rời Đi" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongvietnam_08">Còn Yêu, Đâu Ai Rời Đi</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Duc-Phuc" title="Nghệ sĩ Đức Phúc">Đức Phúc</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DB8D6" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DB8D6" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DB8D6" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DB8D6" href="bai-hat/Con-Yeu-Dau-Ai-Roi-Di-Duc-Phuc/ZW9DB8D6.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DIEUI" data-code="LGcmyZHacLcWzniyHyDGZmtZWSLBRRCmN"  data-active="show-tool" id="chartitemsongZW9DIEUI">
    
    <div class="w260 ">
        <span class="rank fn-order">09</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Buon-Khong-Em-Dat-G/ZW9DIEUI.html#video-clip#home_chartsongvietnam_09" title="Buồn Không Em" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongvietnam_09">Buồn Không Em</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Dat-G" title="Nghệ sĩ Đạt G">Đạt G</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9DIEUI" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DIEUI" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DIEUI" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DIEUI" href="bai-hat/Buon-Khong-Em-Dat-G/ZW9DIEUI.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9E0BC0" data-code="ZHJHykmNxDSXvmJtmyFmZmykWlLdiiXmN"  data-active="show-tool" id="chartitemsongZW9E0BC0">
    
    <div class="w260 ">
        <span class="rank fn-order">10</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Yeu-Don-Phuong-OnlyC-Karik/ZW9E0BC0.html#video-clip#home_chartsongvietnam_10" title="Yêu Đơn Phương" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongvietnam_10">Yêu Đơn Phương</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/OnlyC" title="Nghệ sĩ OnlyC">OnlyC</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Karik" title="Nghệ sĩ Karik">Karik</a></h4>
            
        </div>        
        
        <i id="song-score-ZW9E0BC0" class="txt-info pull-right view-stas fn-score"></i>
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9E0BC0" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9E0BC0" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9E0BC0" href="bai-hat/Yeu-Don-Phuong-OnlyC-Karik/ZW9E0BC0.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
</ul>






    
   
        </div>
    </div>
    
    <div id="chart_songIWZ9Z0BW" class="tab-pane widget-song-countdown chart-song none">
        <div class="widget-content no-padding no-border tracking-page-session" data-id="6">
            












<ul class="fn-list">
    
    <li class="fn-item fn-first first-item fn-song" data-type="song" data-id="ZW9C6C8W" data-code="ZnxHyZHNxkBiimhTHyFnLmyLpSLBRiCGa"  data-active="show-tool" id="chartitemsongZW9C6C8W">
    
    <a class="zthumb fn-link" href="bai-hat/Girls-Like-You-Maroon-5-Cardi-B/ZW9C6C8W.html#video-clip#home_chartsongaumy_01">
        <img class="fn-thumb" src="banner/c/7/6/5/c7658ec705f570353c4f349f96fc1f6b.jpg" alt="Bài hát Girls Like You - Maroon 5, Cardi B">
    </a>
    
    <div class="w260 des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Girls-Like-You-Maroon-5-Cardi-B/ZW9C6C8W.html#video-clip#home_chartsongaumy_01" title="Girls Like You" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongaumy_01">Girls Like You</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Maroon-5" title="Nghệ sĩ Maroon 5">Maroon 5</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Cardi-B" title="Nghệ sĩ Cardi B">Cardi B</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9C6C8W" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9C6C8W" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9C6C8W" href="bai-hat/Girls-Like-You-Maroon-5-Cardi-B/ZW9C6C8W.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    <span class="item-mask"></span>
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DWC9C" data-code="LmJHTkmaxZJRHcSyHyvmZHtZpSkduECns"  data-active="show-tool" id="chartitemsongZW9DWC9C">
    
    <div class="w260 ">
        <span class="rank fn-order">02</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/SICKO-MODE-Travis-Scott/ZW9DWC9C.html#home_chartsongaumy_02" title="SICKO MODE" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongaumy_02">SICKO MODE</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Travis-Scott" title="Nghệ sĩ Travis Scott">Travis Scott</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DWC9C" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DWC9C" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DWC9C" href="bai-hat/SICKO-MODE-Travis-Scott/ZW9DWC9C.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9CIF69" data-code="ZHJHtkmNcZbnLhEymyFGLmyZWAkBiuhma"  data-active="show-tool" id="chartitemsongZW9CIF69">
    
    <div class="w260 ">
        <span class="rank fn-order">03</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Lucid-Dreams-Juice-Wrld/ZW9CIF69.html#home_chartsongaumy_03" title="Lucid Dreams" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongaumy_03">Lucid Dreams</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Juice Wrld" title="Nghệ sĩ Juice Wrld">Juice Wrld</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9CIF69" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9CIF69" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9CIF69" href="bai-hat/Lucid-Dreams-Juice-Wrld/ZW9CIF69.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DZOOB" data-code="LHxnyZGaxLiJuaZTHtbGkntZpSZdiuhms"  data-active="show-tool" id="chartitemsongZW9DZOOB">
    
    <div class="w260 ">
        <span class="rank fn-order">04</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Happier-Marshmello-Bastille/ZW9DZOOB.html#video-clip#home_chartsongaumy_04" title="Happier" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongaumy_04">Happier</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Marshmello" title="Nghệ sĩ Marshmello">Marshmello</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Bastille" title="Nghệ sĩ Bastille">Bastille</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DZOOB" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DZOOB" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DZOOB" href="bai-hat/Happier-Marshmello-Bastille/ZW9DZOOB.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9C07C6" data-code="kmcnykGsxkZlLLxtHyFGZHtLQAkBiigHs"  data-active="show-tool" id="chartitemsongZW9C07C6">
    
    <div class="w260 ">
        <span class="rank fn-order">05</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Better-Now-Post-Malone/ZW9C07C6.html#home_chartsongaumy_05" title="Better Now" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongaumy_05">Better Now</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Post-Malone" title="Nghệ sĩ Post Malone">Post Malone</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9C07C6" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9C07C6" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9C07C6" href="bai-hat/Better-Now-Post-Malone/ZW9C07C6.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9EWB6Z" data-code="kHcGtLHscFQAdnETHtFnkHtLQzkduRXms"  data-active="show-tool" id="chartitemsongZW9EWB6Z">
    
    <div class="w260 ">
        <span class="rank fn-order">06</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/ZEZE-Kodak-Black-Travis-Scott-Offset/ZW9EWB6Z.html#home_chartsongaumy_06" title="ZEZE" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongaumy_06">ZEZE</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Kodak-Black" title="Nghệ sĩ Kodak Black">Kodak Black</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Travis-Scott" title="Nghệ sĩ Travis Scott">Travis Scott</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Offset" title="Nghệ sĩ Offset">Offset</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9EWB6Z" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9EWB6Z" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9EWB6Z" href="bai-hat/ZEZE-Kodak-Black-Travis-Scott-Offset/ZW9EWB6Z.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9BC7C0" data-code="kGJnyLGNJnRaNDxyHTFGLmtZpSZdiuXns"  data-active="show-tool" id="chartitemsongZW9BC7C0">
    
    <div class="w260 ">
        <span class="rank fn-order">07</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Youngblood-5-Seconds-Of-Summer/ZW9BC7C0.html#video-clip#home_chartsongaumy_07" title="Youngblood" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongaumy_07">Youngblood</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/5-Seconds-Of-Summer" title="Nghệ sĩ 5 Seconds Of Summer">5 Seconds Of Summer</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9BC7C0" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9BC7C0" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9BC7C0" href="bai-hat/Youngblood-5-Seconds-Of-Summer/ZW9BC7C0.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DAD6D" data-code="kmcmyLHscDbvmhLyHTFGLHykQzZVEugGN"  data-active="show-tool" id="chartitemsongZW9DAD6D">
    
    <div class="w260 ">
        <span class="rank fn-order">08</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Drip-Too-Hard-Lil-Baby-Gunna/ZW9DAD6D.html#home_chartsongaumy_08" title="Drip Too Hard" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongaumy_08">Drip Too Hard</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Lil-Baby" title="Nghệ sĩ Lil Baby">Lil Baby</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Gunna" title="Nghệ sĩ Gunna">Gunna</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DAD6D" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DAD6D" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DAD6D" href="bai-hat/Drip-Too-Hard-Lil-Baby-Gunna/ZW9DAD6D.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9EZIZ7" data-code="kHcGyZnNcbhzmbdymtvGZmtLplLBiuCHa"  data-active="show-tool" id="chartitemsongZW9EZIZ7">
    
    <div class="w260 ">
        <span class="rank fn-order">09</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Sunflower-Spider-Man-Into-The-Spider-Verse-Post-Malone-Swae-Lee/ZW9EZIZ7.html#home_chartsongaumy_09" title="Sunflower (Spider-Man: Into The Spider-Verse)" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongaumy_09">Sunflower (Spider-Man: Into The Spider-Verse)</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Post-Malone" title="Nghệ sĩ Post Malone">Post Malone</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Swae-Lee" title="Nghệ sĩ Swae Lee">Swae Lee</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9EZIZ7" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9EZIZ7" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9EZIZ7" href="bai-hat/Sunflower-Spider-Man-Into-The-Spider-Verse-Post-Malone-Swae-Lee/ZW9EZIZ7.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9BW0DA" data-code="ZmcHTkmNxmpWGmbtHtFmZHtZpAkdEugHa"  data-active="show-tool" id="chartitemsongZW9BW0DA">
    
    <div class="w260 ">
        <span class="rank fn-order">10</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Love-Lies-Khalid-Normani/ZW9BW0DA.html#video-clip#home_chartsongaumy_10" title="Love Lies" class="txt-primary _trackLink" tracking="_frombox=#home_chartsongaumy_10">Love Lies</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Khalid" title="Nghệ sĩ Khalid">Khalid</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Normani" title="Nghệ sĩ Normani">Normani</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9BW0DA" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9BW0DA" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9BW0DA" href="bai-hat/Love-Lies-Khalid-Normani/ZW9BW0DA.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
</ul>






    
   
        </div>
    </div>
    
    <div id="chart_songIWZ9Z0BO" class="tab-pane widget-song-countdown chart-song none">
        <div class="widget-content no-padding no-border tracking-page-session" data-id="6">
            












<ul class="fn-list">
    
    <li class="fn-item fn-first first-item fn-song" data-type="song" data-id="ZW9E0E88" data-code="ZmJHykHsJDSXubnyntvGkHykQzLBEuhma"  data-active="show-tool" id="chartitemsongZW9E0E88">
    
    <a class="zthumb fn-link" href="bai-hat/BBIBBI-IU/ZW9E0E88.html#video-clip#home_chartsonghanquoc_01">
        <img class="fn-thumb" src="banner/3/7/5/9/375962472a65a370194941b4c9257e33.jpg" alt="Bài hát BBIBBI - IU">
    </a>
    
    <div class="w260 des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/BBIBBI-IU/ZW9E0E88.html#video-clip#home_chartsonghanquoc_01" title="BBIBBI" class="txt-primary _trackLink" tracking="_frombox=#home_chartsonghanquoc_01">BBIBBI</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/IU" title="Nghệ sĩ IU">IU</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9E0E88" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9E0E88" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9E0E88" href="bai-hat/BBIBBI-IU/ZW9E0E88.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    <span class="item-mask"></span>
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DCI9E" data-code="LmJHtkmNxFFNbBHyHyFHkmykWSLBRRhna"  data-active="show-tool" id="chartitemsongZW9DCI9E">
    
    <div class="w260 ">
        <span class="rank fn-order">02</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Fall-In-Fall-Vibe/ZW9DCI9E.html#home_chartsonghanquoc_02" title="Fall In Fall" class="txt-primary _trackLink" tracking="_frombox=#home_chartsonghanquoc_02">Fall In Fall</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Vibe" title="Nghệ sĩ Vibe">Vibe</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DCI9E" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DCI9E" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DCI9E" href="bai-hat/Fall-In-Fall-Vibe/ZW9DCI9E.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9EOOZF" data-code="kmJmyknNxFWCBpZymyvHLmtLQSZVERgma"  data-active="show-tool" id="chartitemsongZW9EOOZF">
    
    <div class="w260 ">
        <span class="rank fn-order">03</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Sorry-Yang-Da-Il/ZW9EOOZF.html#video-clip#home_chartsonghanquoc_03" title="Sorry" class="txt-primary _trackLink" tracking="_frombox=#home_chartsonghanquoc_03">Sorry</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Yang-Da-Il" title="Nghệ sĩ Yang Da Il">Yang Da Il</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9EOOZF" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9EOOZF" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9EOOZF" href="bai-hat/Sorry-Yang-Da-Il/ZW9EOOZF.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9EOABW" data-code="ZmxnTkmaJbWxbbhtmtvHLntLpSZdRuhma"  data-active="show-tool" id="chartitemsongZW9EOABW">
    
    <div class="w260 ">
        <span class="rank fn-order">04</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Hello-Tutorial-Zion-T-Seulgi/ZW9EOABW.html#home_chartsonghanquoc_04" title="Hello Tutorial" class="txt-primary _trackLink" tracking="_frombox=#home_chartsonghanquoc_04">Hello Tutorial</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Zion-T" title="Nghệ sĩ Zion.T">Zion.T</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Seulgi" title="Nghệ sĩ Seulgi">Seulgi</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9EOABW" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9EOABW" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9EOABW" href="bai-hat/Hello-Tutorial-Zion-T-Seulgi/ZW9EOABW.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DD00D" data-code="LncHtkHscFBGRFWTGyFGZHyZWALduiCHs"  data-active="show-tool" id="chartitemsongZW9DD00D">
    
    <div class="w260 ">
        <span class="rank fn-order">05</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/There-Has-Never-Been-a-Day-I-Haven-t-Loved-You-Lim-Chang-Jung/ZW9DD00D.html#video-clip#home_chartsonghanquoc_05" title="There Has Never Been a Day I Haven't Loved You" class="txt-primary _trackLink" tracking="_frombox=#home_chartsonghanquoc_05">There Has Never Been a Day I Haven't Loved You</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Lim-Chang-Jung" title="Nghệ sĩ Lim Chang Jung">Lim Chang Jung</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DD00D" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DD00D" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DD00D" href="bai-hat/There-Has-Never-Been-a-Day-I-Haven-t-Loved-You-Lim-Chang-Jung/ZW9DD00D.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9E096O" data-code="ZnJHyLmaJFSphHVTHTDnLGyLWSkdiRgmN"  data-active="show-tool" id="chartitemsongZW9E096O">
    
    <div class="w260 ">
        <span class="rank fn-order">06</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Good-Day-pH-1-Kid-Milli-Loopy/ZW9E096O.html#home_chartsonghanquoc_06" title="Good Day" class="txt-primary _trackLink" tracking="_frombox=#home_chartsonghanquoc_06">Good Day</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/pH-1" title="Nghệ sĩ pH-1">pH-1</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Kid-Milli" title="Nghệ sĩ Kid Milli">Kid Milli</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Loopy" title="Nghệ sĩ Loopy">Loopy</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9E096O" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9E096O" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9E096O" href="bai-hat/Good-Day-pH-1-Kid-Milli-Loopy/ZW9E096O.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9E09O0" data-code="kncHtkHNcFzQWQFtGtvmLnyZQzLdiECHs"  data-active="show-tool" id="chartitemsongZW9E09O0">
    
    <div class="w260 ">
        <span class="rank fn-order">07</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/It-Takes-Time-Loco-Colde/ZW9E09O0.html#video-clip#home_chartsonghanquoc_07" title="It Takes Time" class="txt-primary _trackLink" tracking="_frombox=#home_chartsonghanquoc_07">It Takes Time</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Loco" title="Nghệ sĩ Loco">Loco</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Colde" title="Nghệ sĩ Colde">Colde</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9E09O0" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9E09O0" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9E09O0" href="bai-hat/It-Takes-Time-Loco-Colde/ZW9E09O0.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9B8UID" data-code="ZHJmyZHscGJmSkBTHTvGknykpzZBRECHN"  data-active="show-tool" id="chartitemsongZW9B8UID">
    
    <div class="w260 ">
        <span class="rank fn-order">08</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Every-day-Every-Moment-Paul-Kim/ZW9B8UID.html#home_chartsonghanquoc_08" title="Every day, Every Moment" class="txt-primary _trackLink" tracking="_frombox=#home_chartsonghanquoc_08">Every day, Every Moment</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Paul-Kim-Kpop" title="Nghệ sĩ Paul Kim">Paul Kim</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9B8UID" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9B8UID" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9B8UID" href="bai-hat/Every-day-Every-Moment-Paul-Kim/ZW9B8UID.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9DBEO8" data-code="ZHJmyLHNJFFhdCHymTbmkHyLQlZdRRCHa"  data-active="show-tool" id="chartitemsongZW9DBEO8">
    
    <div class="w260 ">
        <span class="rank fn-order">09</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/The-Hardest-Part-Roy-Kim/ZW9DBEO8.html#video-clip#home_chartsonghanquoc_09" title="The Hardest Part" class="txt-primary _trackLink" tracking="_frombox=#home_chartsonghanquoc_09">The Hardest Part</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Roy-Kim" title="Nghệ sĩ Roy Kim">Roy Kim</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9DBEO8" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9DBEO8" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9DBEO8" href="bai-hat/The-Hardest-Part-Roy-Kim/ZW9DBEO8.html#video-clip%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
    <li class="fn-item fn-song" data-type="song" data-id="ZW9CBCWE" data-code="LmJmyZmsckgHdnbyHtbmkmyZQlZdiEhmN"  data-active="show-tool" id="chartitemsongZW9CBCWE">
    
    <div class="w260 ">
        <span class="rank fn-order">10</span>
        <h3 class="song-name ellipsis">
            <a href="bai-hat/Way-Back-Home-Shaun/ZW9CBCWE.html#home_chartsonghanquoc_10" title="Way Back Home" class="txt-primary _trackLink" tracking="_frombox=#home_chartsonghanquoc_10">Way Back Home</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Shaun -  The Koxx" title="Nghệ sĩ Shaun">Shaun</a></h4>
            
        </div>        
              
        <div class="tool-song">
            <div class="i25 i-small download"><a title="Tải về" class="fn-dlsong" data-item="#chartitemsongZW9CBCWE" href="#"></a></div>
            <div class="i25 i-small addlist"><a title="Thêm vào" class="fn-addto" data-item="#chartitemsongZW9CBCWE" href="#"></a></div>
            <div class="i25 i-small share"><a title="Chia sẻ" class="fn-share" data-item="#chartitemsongZW9CBCWE" href="bai-hat/Way-Back-Home-Shaun/ZW9CBCWE.html%3Futm_source%3Ddesktop%26utm_medium%3Dfacebook%26utm_campaign%3Dshare"></a></div>
        </div>   
    </div>
    
</li>
    
</ul>






    
   
        </div>
    </div>
        
</div>



<div id="widget-chart-video" class="widget widget-tab ">
    <h2 class="title-section sz-title-sm fs18">
        <a class="fn-detail_link" href="zing-chart-tuan/MV-Viet-Nam/IWZ9Z08W.html">#ZingChart Tuần - MV<i class="icon-arrow"></i></a>
        <a title="Nghe tất cả" href="#" class="icon-play-all pull-right fn-play_link"></a>
    </h2>
    <ul class="tab-nav">        
        
        <li><a title="BXH MV Việt Nam" id="chart_tab_videoIWZ9Z08W" class="active fn-switch-tab" data-show="#chart_videoIWZ9Z08W" data-id="IWZ9Z08W" data-type="video" data-link="zing-chart-tuan/MV-Viet-Nam/IWZ9Z08W.html" data-hide=".chart-video">Việt Nam</a></li>
        
        <li><a title="BXH MV US-UK" id="chart_tab_videoIWZ9Z0BU" class=" fn-switch-tab" data-show="#chart_videoIWZ9Z0BU" data-id="IWZ9Z0BU" data-type="video" data-link="zing-chart-tuan/MV-US-UK/IWZ9Z0BU.html" data-hide=".chart-video">US-UK</a></li>
        
        <li><a title="BXH MV KPop" id="chart_tab_videoIWZ9Z0BZ" class=" fn-switch-tab" data-show="#chart_videoIWZ9Z0BZ" data-id="IWZ9Z0BZ" data-type="video" data-link="zing-chart-tuan/MV-KPop/IWZ9Z0BZ.html" data-hide=".chart-video">K-Pop</a></li>
            
    </ul>
    
    <div id="chart_videoIWZ9Z08W" class="tab-pane widget-thumb-countdown widget-mv-countdown chart-video ">
        <div class="widget-content no-padding no-border tracking-page-session" data-id="12">
            







<ul>
    
    
<li class="fn-first first-item fn-item chart-video-sidebar">
    <a class="zthumb fn-link" href="video-clip/Thang-Dien-JustaTee-Phuong-Ly/ZW9DFW9A.html#home_chartvideovietnam_01">
        <img class="fn-thumb" src="banner/0/a/a/b/0aab409863b8c20af651006cb1346e58.jpg" alt="Bài hát Thằng Điên - JustaTee, Phương Ly">
    </a>
    <div class="des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="video-clip/Thang-Dien-JustaTee-Phuong-Ly/ZW9DFW9A.html" title="Thằng Điên" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideovietnam_01">Thằng Điên</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/JustaTee" title="Nghệ sĩ JustaTee">JustaTee</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Phuong-Ly" title="Nghệ sĩ Phương Ly">Phương Ly</a></h4>
            
        </div>
        
        <i id="video-score-ZW9DFW9A" class="txt-info pull-right view-stas fn-score"></i>
        
    </div><!-- /.des -->
    <span class="item-mask"></span>
</li>


    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/Yeu-Don-Phuong-OnlyC-Karik/ZW9E0BC0.html#home_chartvideovietnam_02">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/a/8/3/6/a83606b0e9477205f940c1a3d975fdef.jpg" alt="Bài hát Yêu Đơn Phương - OnlyC, Karik" />
        <span class="rank fn-order">02</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/Yeu-Don-Phuong-OnlyC-Karik/ZW9E0BC0.html#home_chartvideovietnam_02" title="Yêu Đơn Phương" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideovietnam_02">Yêu Đơn Phương</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/OnlyC" title="Nghệ sĩ OnlyC">OnlyC</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Karik" title="Nghệ sĩ Karik">Karik</a></h4>
        
    </div>
    
    <h5 id="video-score-ZW9E0BC0" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/Anh-Co-Tai-Ma-Xuan-Nghi/ZW9E0BBD.html#home_chartvideovietnam_03">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/4/0/9/2/40929cf438e32f1bb8e4bfe12ae16b0e.jpg" alt="Bài hát Anh Có Tài Mà - Xuân Nghị" />
        <span class="rank fn-order">03</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/Anh-Co-Tai-Ma-Xuan-Nghi/ZW9E0BBD.html#home_chartvideovietnam_03" title="Anh Có Tài Mà" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideovietnam_03">Anh Có Tài Mà</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Do-Xuan-Nghi" title="Nghệ sĩ Xuân Nghị">Xuân Nghị</a></h4>
        
    </div>
    
    <h5 id="video-score-ZW9E0BBD" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/Hongkong1-Official-Version-Nguyen-Trong-Tai-San-Ji-Double-X/ZW9DFW8O.html#home_chartvideovietnam_04">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/1/6/7/0/1670a4e793eeb0f5ddd84cd6f2a88a61.jpg" alt="Bài hát Hongkong1 (Official Version) - Nguyễn Trọng Tài, San Ji, Double X" />
        <span class="rank fn-order">04</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/Hongkong1-Official-Version-Nguyen-Trong-Tai-San-Ji-Double-X/ZW9DFW8O.html#home_chartvideovietnam_04" title="Hongkong1 (Official Version)" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideovietnam_04">Hongkong1 (Official Version)</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Nguyen-Trong-Tai" title="Nghệ sĩ Nguyễn Trọng Tài">Nguyễn Trọng Tài</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Sang-Vo" title="Nghệ sĩ San Ji">San Ji</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Double-X" title="Nghệ sĩ Double X">Double X</a></h4>
        
    </div>
    
    <h5 id="video-score-ZW9DFW8O" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/Co-Dau-Xa-Gan-Ai-Phuong/ZW9EZ0I7.html#home_chartvideovietnam_05">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/9/2/5/f/925f0b4685c0ffe3277071086cde280d.jpg" alt="Bài hát Có Đâu Xa Gần - Ái Phương" />
        <span class="rank fn-order">05</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/Co-Dau-Xa-Gan-Ai-Phuong/ZW9EZ0I7.html#home_chartvideovietnam_05" title="Có Đâu Xa Gần" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideovietnam_05">Có Đâu Xa Gần</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Ai-Phuong" title="Nghệ sĩ Ái Phương">Ái Phương</a></h4>
        
    </div>
    
    <h5 id="video-score-ZW9EZ0I7" class="txt-info z-point fn-score"></h5>
    
</li>

    
</ul>


    
   
        </div>
    </div>
    
    <div id="chart_videoIWZ9Z0BU" class="tab-pane widget-thumb-countdown widget-mv-countdown chart-video none">
        <div class="widget-content no-padding no-border tracking-page-session" data-id="12">
            







<ul>
    
    
<li class="fn-first first-item fn-item chart-video-sidebar">
    <a class="zthumb fn-link" href="video-clip/Taki-Taki-DJ-Snake-Selena-Gomez-Ozuna-Cardi-B/ZW9DD9D0.html#home_chartvideoaumy_01">
        <img class="fn-thumb" src="banner/c/c/5/e/cc5ece1a04d7e53577409e3f70c4052f.jpg" alt="Bài hát Taki Taki - DJ Snake, Selena Gomez, Ozuna, Cardi B">
    </a>
    <div class="des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="video-clip/Taki-Taki-DJ-Snake-Selena-Gomez-Ozuna-Cardi-B/ZW9DD9D0.html" title="Taki Taki" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideoaumy_01">Taki Taki</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/DJ-Snake" title="Nghệ sĩ Nhiều nghệ sĩ">Nhiều nghệ sĩ</a></h4>
            
        </div>
        
    </div><!-- /.des -->
    <span class="item-mask"></span>
</li>


    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/Girls-Like-You-Maroon-5-Cardi-B/ZW9C6C8W.html#home_chartvideoaumy_02">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/e/f/3/9/ef39edf6d8a7a9e09a212de6dddd49e6.jpg" alt="Bài hát Girls Like You - Maroon 5, Cardi B" />
        <span class="rank fn-order">02</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/Girls-Like-You-Maroon-5-Cardi-B/ZW9C6C8W.html#home_chartvideoaumy_02" title="Girls Like You" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideoaumy_02">Girls Like You</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Maroon-5" title="Nghệ sĩ Maroon 5">Maroon 5</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Cardi-B" title="Nghệ sĩ Cardi B">Cardi B</a></h4>
        
    </div>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/Venom-OST-Eminem/ZW9DCC7B.html#home_chartvideoaumy_03">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/c/5/4/2/c54215ea44847d5b41f5b1b985c848b0.jpg" alt="Bài hát Venom (OST) - Eminem" />
        <span class="rank fn-order">03</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/Venom-OST-Eminem/ZW9DCC7B.html#home_chartvideoaumy_03" title="Venom (OST)" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideoaumy_03">Venom (OST)</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Eminem" title="Nghệ sĩ Eminem">Eminem</a></h4>
        
    </div>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/FEFE-6ix9ine-Nicki-Minaj-Murda-Beatz/ZW9D0ABB.html#home_chartvideoaumy_04">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/3/7/4/1/3741d40ba940e85ae44207cd6d68d1a6.jpg" alt="Bài hát FEFE - 6ix9ine, Nicki Minaj, Murda Beatz" />
        <span class="rank fn-order">04</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/FEFE-6ix9ine-Nicki-Minaj-Murda-Beatz/ZW9D0ABB.html#home_chartvideoaumy_04" title="FEFE" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideoaumy_04">FEFE</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/6ix9ine" title="Nghệ sĩ 6ix9ine">6ix9ine</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Nicki-Minaj" title="Nghệ sĩ Nicki Minaj">Nicki Minaj</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Murda-Beatz" title="Nghệ sĩ Murda Beatz">Murda Beatz</a></h4>
        
    </div>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/MIA-Bad-Bunny-Drake/ZW9EICIW.html#home_chartvideoaumy_05">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/1/4/8/9/14895c13768ebf7b54d5e0bde869ea24.jpg" alt="Bài hát MIA - Bad Bunny, Drake" />
        <span class="rank fn-order">05</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/MIA-Bad-Bunny-Drake/ZW9EICIW.html#home_chartvideoaumy_05" title="MIA" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideoaumy_05">MIA</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Bad-Bunny" title="Nghệ sĩ Bad Bunny">Bad Bunny</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Drake" title="Nghệ sĩ Drake">Drake</a></h4>
        
    </div>
    
</li>

    
</ul>


    
   
        </div>
    </div>
    
    <div id="chart_videoIWZ9Z0BZ" class="tab-pane widget-thumb-countdown widget-mv-countdown chart-video none">
        <div class="widget-content no-padding no-border tracking-page-session" data-id="12">
            







<ul>
    
    
<li class="fn-first first-item fn-item chart-video-sidebar">
    <a class="zthumb fn-link" href="video-clip/The-First-Night-Kim-Won-Joo/ZW9DIBU9.html#home_chartvideohanquoc_01">
        <img class="fn-thumb" src="banner/0/8/4/2/08423c3669a786e5f392224fc9c211c3.jpg" alt="Bài hát The First Night - Kim Won Joo">
    </a>
    <div class="des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="video-clip/The-First-Night-Kim-Won-Joo/ZW9DIBU9.html" title="The First Night" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideohanquoc_01">The First Night</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Kim-Won-Joo" title="Nghệ sĩ Kim Won Joo">Kim Won Joo</a></h4>
            
        </div>
        
    </div><!-- /.des -->
    <span class="item-mask"></span>
</li>


    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/BBIBBI-IU/ZW9E0E88.html#home_chartvideohanquoc_02">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/3/f/b/7/3fb7826959e91a641deeafa4135400df.jpg" alt="Bài hát BBIBBI - IU" />
        <span class="rank fn-order">02</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/BBIBBI-IU/ZW9E0E88.html#home_chartvideohanquoc_02" title="BBIBBI" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideohanquoc_02">BBIBBI</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/IU" title="Nghệ sĩ IU">IU</a></h4>
        
    </div>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/Not-A-Love-Vibe/ZW9EIOFE.html#home_chartvideohanquoc_03">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/5/9/1/9/5919cbd4f7f08859ae1bc6574cd2a5c6.jpg" alt="Bài hát Not A Love - Vibe" />
        <span class="rank fn-order">03</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/Not-A-Love-Vibe/ZW9EIOFE.html#home_chartvideohanquoc_03" title="Not A Love" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideohanquoc_03">Not A Love</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Vibe" title="Nghệ sĩ Vibe">Vibe</a></h4>
        
    </div>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/Woman-BoA/ZW9E7FD8.html#home_chartvideohanquoc_04">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/f/b/3/4/fb344d5e1fcf15e905a7adf10d553753.jpg" alt="Bài hát Woman - BoA" />
        <span class="rank fn-order">04</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/Woman-BoA/ZW9E7FD8.html#home_chartvideohanquoc_04" title="Woman" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideohanquoc_04">Woman</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/BoA" title="Nghệ sĩ BoA">BoA</a></h4>
        
    </div>
    
</li>

    
    

<li class="fn-item chart-video-sidebar">
    <a class="thumb pull-left fn-link" href="video-clip/IDOL-BTS/ZW9D6C89.html#home_chartvideohanquoc_05">
        <img width="110" class="fn-thumb" src="w240h135_jpeg/thumb_video/3/0/7/c/307c65403a36b8086f537d2ac1f53232.jpg" alt="Bài hát IDOL - BTS" />
        <span class="rank fn-order">05</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="video-clip/IDOL-BTS/ZW9D6C89.html#home_chartvideohanquoc_05" title="IDOL" class="txt-primary _trackLink" tracking="_frombox=#home_chartvideohanquoc_05">IDOL</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/BTS" title="Nghệ sĩ BTS">BTS</a></h4>
        
    </div>
    
</li>

    
</ul>


    
   
        </div>
    </div>
        
</div>



<div id="widget-chart-album" class="widget widget-tab">
    <h2 class="title-section sz-title-sm fs18">
        <a class="fn-detail_link" href="zing-chart-tuan/Album-Viet-Nam/IWZ9Z08O.html">#ZingChart Tuần - Album<i class="icon-arrow"></i></a>
        <a title="Nghe tất cả" href="#" class="none icon-play-all pull-right fn-play_link"></a>
    </h2>
    <ul class="tab-nav">
         
        <li><a title="BXH Album Việt Nam" class="active fn-switch-tab" data-show="#chart_albumIWZ9Z08O" data-type="album" data-link="zing-chart-tuan/Album-Viet-Nam/IWZ9Z08O.html"  data-hide=".chart-album">Việt Nam</a></li>
        
        <li><a title="BXH Album US-UK" class=" fn-switch-tab" data-show="#chart_albumIWZ9Z0B6" data-type="album" data-link="zing-chart-tuan/Album-US-UK/IWZ9Z0B6.html"  data-hide=".chart-album">US-UK</a></li>
        
        <li><a title="BXH Album KPop" class=" fn-switch-tab" data-show="#chart_albumIWZ9Z0B7" data-type="album" data-link="zing-chart-tuan/Album-KPop/IWZ9Z0B7.html"  data-hide=".chart-album">K-Pop</a></li>
            
    </ul>
    
    <div class="tab-pane widget-thumb-countdown">
        <div id="chart_albumIWZ9Z08O" class="widget-content no-padding no-border chart-album  tracking-page-session" data-id="18">
            






<ul>
    
    
<li class="fn-first first-item fn-item">
    <a class="zthumb fn-link" href="album/Mot-Minh-Co-Sao-Dau-Dam-Vinh-Hung/ZOEB9UCD.html#home_chartalbumvietnam_01">
        <img class="fn-thumb" src="banner/c/5/e/b/c5ebb542972d24b4331466f5d8526831.jpg" alt="Album Một Mình Có Sao Đâu! - Đàm Vĩnh Hưng">
    </a>
    <div class="des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="album/Mot-Minh-Co-Sao-Dau-Dam-Vinh-Hung/ZOEB9UCD.html" title="Một Mình Có Sao Đâu! - Đàm Vĩnh Hưng" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_01">Một Mình Có Sao Đâu!</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Dam-Vinh-Hung" title="Nghệ sĩ Đàm Vĩnh Hưng">Đàm Vĩnh Hưng</a></h4>
            
        </div>
        
        <i id="album-score-ZOEB9UCD" class="txt-info pull-right view-stas fn-score"></i>
        
    </div><!-- /.des -->
    <span class="item-mask"></span>
</li>


    
    

<li class="fn-item">
    <a href="album/Lien-Khuc-Cha-Cha-Cha-Thanh-Ngan-Gia-Tien/ZOEDD8AU.html#home_chartalbumvietnam_02" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/5/6/e/2/56e2fb01c0f48f5269a8be7db1705735.jpg" alt="Bài hát Liên Khúc Cha Cha Cha - Thanh Ngân, Gia Tiến" />
        <span class="rank fn-order">02</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Lien-Khuc-Cha-Cha-Cha-Thanh-Ngan-Gia-Tien/ZOEDD8AU.html#home_chartalbumvietnam_02" title="Liên Khúc Cha Cha Cha" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_02">Liên Khúc Cha Cha Cha</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Thanh-Ngan" title="Nghệ sĩ Thanh Ngân">Thanh Ngân</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Gia-Tien" title="Nghệ sĩ Gia Tiến">Gia Tiến</a></h4>
        
    </div>
    
    <h5 id="album-score-ZOEDD8AU" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item">
    <a href="album/Thanh-Pho-Buon-Luu-Anh-Loan/ZOD8I6UC.html#home_chartalbumvietnam_03" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/c/b/d/9/cbd9f2f0cc6d9efc73b99ef1e8f20393.jpg" alt="Bài hát Thành Phố Buồn - Lưu Ánh Loan" />
        <span class="rank fn-order">03</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Thanh-Pho-Buon-Luu-Anh-Loan/ZOD8I6UC.html#home_chartalbumvietnam_03" title="Thành Phố Buồn" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_03">Thành Phố Buồn</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Luu-Anh-Loan" title="Nghệ sĩ Lưu Ánh Loan">Lưu Ánh Loan</a></h4>
        
    </div>
    
    <h5 id="album-score-ZOD8I6UC" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item">
    <a href="album/Tinh-Lua-Duyen-Trang-Quach-Thanh-Danh-Duong-Hong-Loan/ZOEDID9U.html#home_chartalbumvietnam_04" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/4/4/5/a/445a17761b0ba5950808597576bad203.jpg" alt="Bài hát Tình Lúa Duyên Trăng - Quách Thành Danh, Dương Hồng Loan" />
        <span class="rank fn-order">04</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Tinh-Lua-Duyen-Trang-Quach-Thanh-Danh-Duong-Hong-Loan/ZOEDID9U.html#home_chartalbumvietnam_04" title="Tình Lúa Duyên Trăng" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_04">Tình Lúa Duyên Trăng</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Quach-Thanh-Danh" title="Nghệ sĩ Quách Thành Danh">Quách Thành Danh</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Duong-Hong-Loan" title="Nghệ sĩ Dương Hồng Loan">Dương Hồng Loan</a></h4>
        
    </div>
    
    <h5 id="album-score-ZOEDID9U" class="txt-info z-point fn-score"></h5>
    
</li>

    
    

<li class="fn-item">
    <a href="album/Em-A-Minh-Chia-Tay-Nhe-EP-Le-Anh-Khoi/ZOF00EW6.html#home_chartalbumvietnam_05" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/e/a/4/f/ea4f83b2c3eea45e2882b3c10dece9bf.jpg" alt="Bài hát Em À Mình Chia Tay Nhé (EP) - Lê Anh Khôi" />
        <span class="rank fn-order">05</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Em-A-Minh-Chia-Tay-Nhe-EP-Le-Anh-Khoi/ZOF00EW6.html#home_chartalbumvietnam_05" title="Em À Mình Chia Tay Nhé (EP)" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_05">Em À Mình Chia Tay Nhé (EP)</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Le-Anh-Khoi" title="Nghệ sĩ Lê Anh Khôi">Lê Anh Khôi</a></h4>
        
    </div>
    
    <h5 id="album-score-ZOF00EW6" class="txt-info z-point fn-score"></h5>
    
</li>

    
</ul>




   
        </div>
    </div>
    
    <div class="tab-pane widget-thumb-countdown">
        <div id="chart_albumIWZ9Z0B6" class="widget-content no-padding no-border chart-album none tracking-page-session" data-id="18">
            






<ul>
    
    
<li class="fn-first first-item fn-item">
    <a class="zthumb fn-link" href="album/A-Star-Is-Born-Soundtrack-Lady-Gaga-Bradley-Cooper/ZOECO0EA.html#home_chartalbumvietnam_01">
        <img class="fn-thumb" src="banner/a/e/f/1/aef1e1f25826168b2f02dcfd0711e31d.jpg" alt="Album A Star Is Born Soundtrack - Lady Gaga, Bradley Cooper">
    </a>
    <div class="des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="album/A-Star-Is-Born-Soundtrack-Lady-Gaga-Bradley-Cooper/ZOECO0EA.html" title="A Star Is Born Soundtrack - Lady Gaga, Bradley Cooper" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_01">A Star Is Born Soundtrack</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Lady-Gaga" title="Nghệ sĩ Lady Gaga">Lady Gaga</a></h4><span class="ft">, </span>
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/Bradley Cooper" title="Nghệ sĩ Bradley Cooper">Bradley Cooper</a></h4>
            
        </div>
        
    </div><!-- /.des -->
    <span class="item-mask"></span>
</li>


    
    

<li class="fn-item">
    <a href="album/Future-Juice-WRLD-Present-WRLD-ON-DRUGS-Future-Juice-Wrld/ZOEFFUAC.html#home_chartalbumvietnam_02" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/4/c/e/a/4cea411d6ba9284f0ab491703faf31ca.jpg" alt="Bài hát Future & Juice WRLD Present... WRLD ON DRUGS - Future, Juice Wrld" />
        <span class="rank fn-order">02</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Future-Juice-WRLD-Present-WRLD-ON-DRUGS-Future-Juice-Wrld/ZOEFFUAC.html#home_chartalbumvietnam_02" title="Future & Juice WRLD Present... WRLD ON DRUGS" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_02">Future & Juice WRLD Present... WRLD ON DRUGS</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Future" title="Nghệ sĩ Future">Future</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Juice Wrld" title="Nghệ sĩ Juice Wrld">Juice Wrld</a></h4>
        
    </div>
    
</li>

    
    

<li class="fn-item">
    <a href="album/Anthem-Of-The-Peaceful-Army-Greta-Van-Fleet/ZOEFEZDZ.html#home_chartalbumvietnam_03" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/7/3/5/0/73501a569426bf2dc6f75ad01331d9c5.jpg" alt="Bài hát Anthem Of The Peaceful Army - Greta Van Fleet" />
        <span class="rank fn-order">03</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Anthem-Of-The-Peaceful-Army-Greta-Van-Fleet/ZOEFEZDZ.html#home_chartalbumvietnam_03" title="Anthem Of The Peaceful Army" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_03">Anthem Of The Peaceful Army</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Greta Van Fleet" title="Nghệ sĩ Greta Van Fleet">Greta Van Fleet</a></h4>
        
    </div>
    
</li>

    
    

<li class="fn-item">
    <a href="album/Tha-Carter-V-Lil-Wayne/ZOEA9UC0.html#home_chartalbumvietnam_04" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/2/2/8/2/2282c71e12f3c226b2f216bf3b622697.jpg" alt="Bài hát Tha Carter V - Lil Wayne" />
        <span class="rank fn-order">04</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Tha-Carter-V-Lil-Wayne/ZOEA9UC0.html#home_chartalbumvietnam_04" title="Tha Carter V" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_04">Tha Carter V</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Lil-Wayne" title="Nghệ sĩ Lil Wayne">Lil Wayne</a></h4>
        
    </div>
    
</li>

    
    

<li class="fn-item">
    <a href="album/Drip-Harder-Lil-Baby-Gunna/ZOECOI0E.html#home_chartalbumvietnam_05" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/6/2/6/3/6263a20d11f9f453f803d2c11b146bdb.jpg" alt="Bài hát Drip Harder - Lil Baby, Gunna" />
        <span class="rank fn-order">05</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Drip-Harder-Lil-Baby-Gunna/ZOECOI0E.html#home_chartalbumvietnam_05" title="Drip Harder" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_05">Drip Harder</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Lil-Baby" title="Nghệ sĩ Lil Baby">Lil Baby</a></h4><span class="ft">, </span>
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Gunna" title="Nghệ sĩ Gunna">Gunna</a></h4>
        
    </div>
    
</li>

    
</ul>




   
        </div>
    </div>
    
    <div class="tab-pane widget-thumb-countdown">
        <div id="chart_albumIWZ9Z0B7" class="widget-content no-padding no-border chart-album none tracking-page-session" data-id="18">
            






<ul>
    
    
<li class="fn-first first-item fn-item">
    <a class="zthumb fn-link" href="album/LOVE-YOURSELF-Answer-REPACKAGE-BTS/ZOEIZCOI.html#home_chartalbumvietnam_01">
        <img class="fn-thumb" src="banner/0/0/d/b/00db11bd651541e3faf69b570cb00ae1.jpg" alt="Album LOVE YOURSELF 'Answer' (REPACKAGE) - BTS">
    </a>
    <div class="des">
        <span class="rank fn-order">01</span>
        <h3 class="song-name ellipsis">
            <a href="album/LOVE-YOURSELF-Answer-REPACKAGE-BTS/ZOEIZCOI.html" title="LOVE YOURSELF 'Answer' (REPACKAGE) - BTS" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_01">LOVE YOURSELF 'Answer' (REPACKAGE)</a>
        </h3>
        <div class="inblock singer-name ellipsis">
            
            <h4 class="title-sd-item txt-info"><a href="nghe-si/BTS" title="Nghệ sĩ BTS">BTS</a></h4>
            
        </div>
        
    </div><!-- /.des -->
    <span class="item-mask"></span>
</li>


    
    

<li class="fn-item">
    <a href="album/Show-Me-The-Money-777-Episode-1-Various-Artists/ZOEDOIIU.html#home_chartalbumvietnam_02" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/d/f/6/5/df65fbe86a13c70e27c03291ca86c33f.jpg" alt="Bài hát Show Me The Money 777 Episode 1 - Various Artists" />
        <span class="rank fn-order">02</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Show-Me-The-Money-777-Episode-1-Various-Artists/ZOEDOIIU.html#home_chartalbumvietnam_02" title="Show Me The Money 777 Episode 1" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_02">Show Me The Money 777 Episode 1</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
    </div>
    
</li>

    
    

<li class="fn-item">
    <a href="album/Show-Me-The-Money-777-Episode-3-Various-Artists/ZOFII8IO.html#home_chartalbumvietnam_03" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/b/2/3/8/b238d05b8a15ea456d26e881ba9fc048.jpg" alt="Bài hát Show Me The Money 777 Episode 3 - Various Artists" />
        <span class="rank fn-order">03</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/Show-Me-The-Money-777-Episode-3-Various-Artists/ZOFII8IO.html#home_chartalbumvietnam_03" title="Show Me The Money 777 Episode 3" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_03">Show Me The Money 777 Episode 3</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
    </div>
    
</li>

    
    

<li class="fn-item">
    <a href="album/BBIBBI-Single-IU/ZOEDA6A9.html#home_chartalbumvietnam_04" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/c/0/b/d/c0bddfbc7e6f4d5f3ed9c9b27cd62155.jpg" alt="Bài hát BBIBBI (Single) - IU" />
        <span class="rank fn-order">04</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/BBIBBI-Single-IU/ZOEDA6A9.html#home_chartalbumvietnam_04" title="BBIBBI (Single)" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_04">BBIBBI (Single)</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/IU" title="Nghệ sĩ IU">IU</a></h4>
        
    </div>
    
</li>

    
    

<li class="fn-item">
    <a href="album/ZZZ-EP-Zion-T/ZOEFWBU7.html#home_chartalbumvietnam_05" class="thumb pull-left fn-link">
        <img width="110" class="fn-thumb" src="w240h240_jpeg/cover/3/0/2/6/30265c59e62b5c873fe6662afe044472.jpg" alt="Bài hát ZZZ (EP) - Zion.T" />
        <span class="rank fn-order">05</span>
        <span class="item-mask"></span>
        <span class="icon-circle-play otr icon-small"></span>
    </a>
    <h3 class="song-name ellipsis">
        <a href="album/ZZZ-EP-Zion-T/ZOEFWBU7.html#home_chartalbumvietnam_05" title="ZZZ (EP)" class="txt-primary _trackLink" tracking="_frombox=#home_chartalbumvietnam_05">ZZZ (EP)</a>
    </h3>
    <div class="inblock singer-name ellipsis">
        
        <h4 class="title-sd-item txt-info"><a href="nghe-si/Zion-T" title="Nghệ sĩ Zion.T">Zion.T</a></h4>
        
    </div>
    
</li>

    
</ul>
        </div>
    </div>
        
</div>

        <div id="block-zing-news"></div>
    </div>
    <div class="clearfix"></div>
    <div class="partner-box">
    <div class="container">
        <div class="row mb0">
            <div class="col-12">
                <span class="ztlabel">ĐỐI TÁC</span>
                <ul class="zpartner">
                    <li><img src="style/images/doi-tac/universal.jpeg" alt="Universal" /></li>
                    <li><img src="style/images/doi-tac/sony.png" alt="Sony Music" /></li>
                    <li><img src="style/images/doi-tac/thuy-nga.png" alt="Thúy Nga" /></li>
                    <li><img src="style/images/doi-tac/vcpmc.jpg" alt="VCPMC" /></li>
                    <li><img src="style/images/doi-tac/riav.jpg" alt="RIAV" /></li>
                    <li><img src="style/images/doi-tac/kim-loi.png" alt="Kim Lợi" /></li>
                    <li><img src="style/images/doi-tac/phuong-nam.jpg" alt="Phương Nam" /></li>
                    <li><img src="style/images/doi-tac/rang-dong.jpg" alt="Rạng Đông" /></li>
                    <li><img src="style/images/doi-tac/vafaco.jpg" alt="Vafaco" /></li>
                    <li><img src="style/images/doi-tac/ben-thanh.jpg" alt="Bến Thành" /></li>
                </ul>
            </div>
        </div>
    </div>
</div>
    <div class="clearfix"></div>
</div>            
        </div>
<?php  include 'include/footer.php'; ?>        